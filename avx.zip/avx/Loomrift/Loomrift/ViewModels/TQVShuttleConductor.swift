import SwiftUI
import Combine
import Foundation

final class TQVShuttleConductor: ObservableObject {
    @Published var puzzle: TQVPuzzle
    @Published var board: TQVDualWeave
    @Published var moveHistory: [TQVShuttleMove] = []
    @Published var currentSide: TQVLoomSide = .warp
    @Published var isComplete = false
    @Published var isPaused = false
    @Published var hintsRemaining: Int
    @Published var hintedMove: TQVShuttleMove?
    @Published var elapsed: Double = 0
    @Published var wrongMove: TQVShuttleMove?

    @Published var selectedMode: TQVWeaveMode = .tandem
    @Published var selectedTier: TQVWeaveTier = .easy

    @Published var ledger: TQVSpoolLedger
    @Published var isDailyPuzzle = false
    @Published var gotNewBestMoves = false
    @Published var gotNewBestTime = false

    private var timer: Timer?
    private var seedCounter: UInt64 = 1

    var moveCount: Int { moveHistory.count }
    var optimalMoves: Int { puzzle.solution.count }

    var matchedCellCount: Int {
        var count = 0
        for r in 0..<board.rows {
            for c in 0..<board.cols {
                if board.warp[r, c] == puzzle.warpTarget[r, c] { count += 1 }
                if board.weft[r, c] == puzzle.weftTarget[r, c] { count += 1 }
            }
        }
        return count
    }

    var totalCellCount: Int { board.rows * board.cols * 2 }

    var matchProgress: Double {
        guard totalCellCount > 0 else { return 0 }
        return Double(matchedCellCount) / Double(totalCellCount)
    }

    var starRating: Int {
        guard moveCount > 0 else { return 0 }
        if moveCount <= optimalMoves { return 3 }
        let threshold = optimalMoves + optimalMoves / 2
        if moveCount <= threshold { return 2 }
        return 1
    }

    var currentBestMoves: Int? {
        let key = "\(selectedMode.rawValue)_\(selectedTier.rawValue)"
        return ledger.bestMoves[key]
    }

    var currentBestTime: Double? {
        let key = "\(selectedMode.rawValue)_\(selectedTier.rawValue)"
        return ledger.bestTime[key]
    }

    var isDailyAvailable: Bool {
        !TQVWeavePersist.isDailyCompleted()
    }

    init() {
        let mode = TQVWeaveMode.tandem
        let tier = TQVWeaveTier.easy
        let p = TQVShuttleForge.compose(mode: mode, tier: tier, seed: 1)
        self.puzzle = p
        self.board = p.board
        self.hintsRemaining = tier.hintBudget
        self.ledger = TQVWeavePersist.loadLedger()

        if let saved = TQVWeavePersist.loadGame() {
            self.puzzle = saved.puzzle
            self.board = saved.puzzle.board
            self.moveHistory = saved.moveHistory
            self.elapsed = saved.elapsed
            self.hintsRemaining = saved.puzzle.tier.hintBudget - saved.hintsUsed
            self.selectedMode = saved.puzzle.mode
            self.selectedTier = saved.puzzle.tier

            var replay = saved.puzzle.board
            for m in saved.moveHistory { replay.apply(m) }
            self.board = replay
            self.currentSide = saved.moveHistory.last.map { $0.side.opposite } ?? .warp
        }
    }

    func newGame(mode: TQVWeaveMode, tier: TQVWeaveTier) {
        selectedMode = mode
        selectedTier = tier
        seedCounter += 1
        isDailyPuzzle = false
        gotNewBestMoves = false
        gotNewBestTime = false
        let p = TQVShuttleForge.compose(mode: mode, tier: tier, seed: seedCounter)
        puzzle = p
        board = p.board
        moveHistory = []
        currentSide = .warp
        isComplete = false
        isPaused = false
        hintsRemaining = tier.hintBudget
        hintedMove = nil
        wrongMove = nil
        elapsed = 0
        TQVReedTrace.reveal(p.solution)
        startTimer()
        save()
    }

    func newDailyGame() {
        let mode = TQVShuttleForge.dailyMode
        let tier = TQVShuttleForge.dailyTier
        let seed = TQVShuttleForge.dailySeed()
        selectedMode = mode
        selectedTier = tier
        isDailyPuzzle = true
        gotNewBestMoves = false
        gotNewBestTime = false
        let p = TQVShuttleForge.compose(mode: mode, tier: tier, seed: seed)
        puzzle = p
        board = p.board
        moveHistory = []
        currentSide = .warp
        isComplete = false
        isPaused = false
        hintsRemaining = tier.hintBudget
        hintedMove = nil
        wrongMove = nil
        elapsed = 0
        TQVReedTrace.reveal(p.solution)
        startTimer()
    }

    func tapCell(side: TQVLoomSide, row: Int, col: Int) {
        guard !isComplete, !isPaused else { return }
        guard side == currentSide else {
            wrongMove = TQVShuttleMove(side: side, row: row, col: col)
            TQVLoomHaptics.error()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                self.wrongMove = nil
            }
            return
        }

        let move = TQVShuttleMove(side: side, row: row, col: col)
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
            board.apply(move)
            moveHistory.append(move)
            currentSide = side.opposite
            hintedMove = nil
        }
        TQVLoomHaptics.tap()

        if board.isComplete(warpTarget: puzzle.warpTarget, weftTarget: puzzle.weftTarget) {
            completeGame()
        } else {
            save()
        }
    }

    func undo() {
        guard !isComplete, !isPaused, !moveHistory.isEmpty else { return }
        let lastMove = moveHistory.removeLast()
        let reverseMove = TQVShuttleMove(
            side: lastMove.side, row: lastMove.row, col: lastMove.col
        )
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
            switch reverseMove.side {
            case .warp:
                board.warp.cycle(r: reverseMove.row, c: reverseMove.col, delta: -1)
                board.weft.cycle(r: reverseMove.row, c: reverseMove.col, delta: 1)
            case .weft:
                board.weft.cycle(r: reverseMove.row, c: reverseMove.col, delta: -1)
                board.warp.cycle(r: reverseMove.row, c: reverseMove.col, delta: 1)
            }
            currentSide = lastMove.side
            hintedMove = nil
        }
        TQVLoomHaptics.selection()
        save()
    }

    func useHint() {
        guard !isComplete, !isPaused, hintsRemaining > 0 else { return }
        if hintedMove != nil { return }
        guard let nextMove = TQVWeaveOracle.hintFromCurrentState(
            board: board,
            warpTarget: puzzle.warpTarget,
            weftTarget: puzzle.weftTarget,
            currentSide: currentSide
        ) else { return }
        hintsRemaining -= 1
        withAnimation(.easeInOut(duration: 0.5)) {
            hintedMove = nextMove
        }
        TQVLoomHaptics.selection()
    }

    func togglePause() {
        isPaused.toggle()
        if isPaused {
            stopTimer()
        } else {
            startTimer()
        }
    }

    func replay() {
        newGame(mode: selectedMode, tier: selectedTier)
    }

    private func completeGame() {
        isComplete = true
        stopTimer()
        TQVLoomHaptics.success()

        let key = "\(selectedMode.rawValue)_\(selectedTier.rawValue)"
        gotNewBestMoves = (ledger.bestMoves[key] == nil || moveCount < ledger.bestMoves[key]!)
        gotNewBestTime = (ledger.bestTime[key] == nil || elapsed < ledger.bestTime[key]!)

        let usedNoHint = hintsRemaining == puzzle.tier.hintBudget
        let isOptimal = moveCount <= optimalMoves
        ledger.recordWin(mode: selectedMode, tier: selectedTier,
                         moves: moveCount, time: elapsed)
        if usedNoHint { ledger.achievements.insert("no_hint") }
        if isOptimal { ledger.achievements.insert("optimal_path") }

        if isDailyPuzzle {
            ledger.dailyWins += 1
            TQVWeavePersist.markDailyCompleted()
        }

        TQVWeavePersist.saveLedger(ledger)
        TQVWeavePersist.clearGame()

        TQVReedTrace.line("result", "WIN moves=\(moveCount) time=\(String(format: "%.1f", elapsed))s")
    }

    private func save() {
        let saved = TQVSavedGame(
            puzzle: puzzle,
            moveHistory: moveHistory,
            elapsed: elapsed,
            hintsUsed: puzzle.tier.hintBudget - hintsRemaining
        )
        TQVWeavePersist.saveGame(saved)
    }

    private func startTimer() {
        stopTimer()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            self?.elapsed += 0.1
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    func shareText() -> String {
        let stars = String(repeating: "\u{2B50}", count: starRating)
        return "\(TQVLoomConfig.appName) — \(selectedMode.rawValue.capitalized) \(selectedTier.rawValue.capitalized) \(stars) solved in \(moveCount) moves (\(optimalMoves) optimal)"
    }

    var hasSavedGame: Bool {
        TQVWeavePersist.loadGame() != nil
    }

    func resumeSaved() {
        guard let saved = TQVWeavePersist.loadGame() else { return }
        puzzle = saved.puzzle
        selectedMode = saved.puzzle.mode
        selectedTier = saved.puzzle.tier
        moveHistory = saved.moveHistory
        elapsed = saved.elapsed
        hintsRemaining = saved.puzzle.tier.hintBudget - saved.hintsUsed
        isDailyPuzzle = false
        gotNewBestMoves = false
        gotNewBestTime = false

        var replay = saved.puzzle.board
        for m in saved.moveHistory { replay.apply(m) }
        board = replay
        currentSide = saved.moveHistory.last.map { $0.side.opposite } ?? .warp
        isComplete = false
        isPaused = false
        hintedMove = nil
        wrongMove = nil
        TQVReedTrace.reveal(puzzle.solution)
        startTimer()
    }

    func isWarpCellMatched(row: Int, col: Int) -> Bool {
        board.warp[row, col] == puzzle.warpTarget[row, col]
    }

    func isWeftCellMatched(row: Int, col: Int) -> Bool {
        board.weft[row, col] == puzzle.weftTarget[row, col]
    }
}

#if DEBUG
extension TQVShuttleConductor {
    func runUnattended(mode: TQVWeaveMode, tier: TQVWeaveTier) {
        newGame(mode: mode, tier: tier)
        guard let path = TQVWeaveOracle.solve(puzzle) else {
            TQVReedTrace.line("autoplay", "no path")
            return
        }
        TQVReedTrace.line("autoplay", "path length=\(path.count)")
        var step = 0
        Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] timer in
            guard let self = self else { timer.invalidate(); return }
            guard step < path.count else {
                timer.invalidate()
                let won = self.isComplete
                TQVReedTrace.line("autoplay", won ? "WIN" : "LOSE")
                return
            }
            let move = path[step]
            self.tapCell(side: move.side, row: move.row, col: move.col)
            step += 1
        }
    }
}
#endif
