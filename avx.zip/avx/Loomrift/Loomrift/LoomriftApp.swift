import SwiftUI

@main
struct LoomriftApp: App {
    @StateObject private var conductor = TQVShuttleConductor()
    @AppStorage("tqv_haptics") private var hapticsOn = true

    var body: some Scene {
        WindowGroup {
            rootView
                .onAppear {
                    TQVLoomHaptics.setEnabled(hapticsOn)
                }
        }
    }

    @ViewBuilder
    private var rootView: some View {
        #if DEBUG
        if CommandLine.arguments.contains("-TQVRehearse") {
            TQVRehearsalStage()
        } else if CommandLine.arguments.contains("-TQVUnattended") {
            autoplayRoot
        } else {
            TQVRootRouter(conductor: conductor)
        }
        #else
        TQVRootRouter(conductor: conductor)
        #endif
    }

    #if DEBUG
    private var autoplayRoot: some View {
        Color.black
            .ignoresSafeArea()
            .onAppear {
                let modeArg = CommandLine.arguments.firstAfter("-TQVMode") ?? "tandem"
                let tierArg = CommandLine.arguments.firstAfter("-TQVTier") ?? "easy"
                let mode = TQVWeaveMode(rawValue: modeArg) ?? .tandem
                let tier = TQVWeaveTier(rawValue: tierArg) ?? .easy
                conductor.runUnattended(mode: mode, tier: tier)
            }
    }
    #endif
}

extension Array where Element == String {
    func firstAfter(_ flag: String) -> String? {
        guard let idx = firstIndex(of: flag), idx + 1 < count else { return nil }
        return self[idx + 1]
    }
}
