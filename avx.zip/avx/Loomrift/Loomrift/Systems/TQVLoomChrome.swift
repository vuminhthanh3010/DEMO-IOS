import SwiftUI
import UIKit

struct TQVGlassPlate: View {
    var radius: CGFloat
    var style: UIBlurEffect.Style = .systemThinMaterialDark
    var tint: Color = Color.black.opacity(0.28)

    var body: some View {
        ZStack {
            TQVGlassPane(style: style)
            tint
        }
        .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: radius, style: .continuous)
                .strokeBorder(style: StrokeStyle(lineWidth: 1.2, dash: [5, 3.5]))
                .foregroundColor(Color.white.opacity(0.18))
        )
    }
}

struct TQVLoomMark: View {
    let size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.18)
                .fill(TQVFiberPalette.accent.opacity(0.18))
                .frame(width: size * 0.78, height: size * 0.92)
                .rotationEffect(.degrees(-11))
                .shadow(color: TQVFiberPalette.accent.opacity(0.35), radius: size * 0.08, y: size * 0.04)

            RoundedRectangle(cornerRadius: size * 0.18)
                .fill(TQVFiberPalette.accentSecondary.opacity(0.18))
                .frame(width: size * 0.78, height: size * 0.92)
                .rotationEffect(.degrees(11))
                .shadow(color: TQVFiberPalette.accentSecondary.opacity(0.28), radius: size * 0.08, y: size * 0.04)

            RoundedRectangle(cornerRadius: size * 0.12)
                .stroke(Color.white.opacity(0.35), lineWidth: max(1, size * 0.03))
                .frame(width: size * 0.42, height: size * 0.52)

            VStack(spacing: size * 0.06) {
                HStack(spacing: size * 0.06) {
                    TQVDot(tone: .indigo, size: size * 0.11)
                    TQVDot(tone: .saffron, size: size * 0.11)
                }
                HStack(spacing: size * 0.06) {
                    TQVDot(tone: .jade, size: size * 0.11)
                    TQVDot(tone: .indigo, size: size * 0.11)
                }
            }
        }
        .frame(width: size, height: size)
    }
}

struct TQVDot: View {
    let tone: TQVStrandTone
    let size: CGFloat

    var body: some View {
        Circle()
            .fill(TQVFiberPalette.strandColor(tone))
            .frame(width: size, height: size)
            .shadow(color: TQVFiberPalette.strandColor(tone).opacity(0.7), radius: size * 0.35)
    }
}

struct TQVFacetButton: View {
    let icon: String
    let size: CGFloat
    var dimmed: Bool = false

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.18)
                .fill(Color.white.opacity(dimmed ? 0.04 : 0.10))
                .rotationEffect(.degrees(45))
                .frame(width: size * 0.68, height: size * 0.68)
                .shadow(color: TQVFiberPalette.accent.opacity(dimmed ? 0 : 0.25),
                        radius: 8, y: 3)
            Image(systemName: icon)
                .font(.system(size: size * 0.32, weight: .semibold))
                .foregroundColor(dimmed ? Color.white.opacity(0.22) : Color.white.opacity(0.9))
        }
        .frame(width: size, height: size)
    }
}

struct TQVWeaveCTA: View {
    let title: String
    let icon: String
    let side: CGFloat
    var compact: Bool = false

    var body: some View {
        HStack(spacing: side * 0.018) {
            Image(systemName: icon)
            Text(title)
        }
        .font(.system(size: side * (compact ? 0.034 : 0.04), weight: .bold, design: .rounded))
        .foregroundColor(.white)
        .frame(maxWidth: .infinity)
        .padding(.vertical, side * (compact ? 0.022 : 0.028))
        .background(
            ZStack {
                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [
                                TQVFiberPalette.accent,
                                TQVFiberPalette.accent.opacity(0.72),
                                TQVFiberPalette.accentSecondary.opacity(0.85)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: TQVFiberPalette.accent.opacity(0.45), radius: 16, y: 8)

                HStack {
                    Capsule()
                        .fill(Color.white.opacity(0.28))
                        .frame(width: side * 0.018, height: side * (compact ? 0.05 : 0.062))
                    Spacer()
                    Capsule()
                        .fill(Color.white.opacity(0.28))
                        .frame(width: side * 0.018, height: side * (compact ? 0.05 : 0.062))
                }
                .padding(.horizontal, side * 0.022)
            }
        )
        .overlay(
            Capsule()
                .stroke(Color.white.opacity(0.22), lineWidth: 1)
        )
    }
}

struct TQVGhostCTA: View {
    let title: String
    let icon: String
    let side: CGFloat

    var body: some View {
        HStack(spacing: side * 0.014) {
            Image(systemName: icon)
            Text(title)
        }
        .font(.system(size: side * 0.032, weight: .bold, design: .rounded))
        .foregroundColor(.white.opacity(0.85))
        .frame(maxWidth: .infinity)
        .padding(.vertical, side * 0.02)
        .background(
            Capsule()
                .fill(Color.white.opacity(0.08))
                .overlay(Capsule().stroke(Color.white.opacity(0.14), lineWidth: 1))
        )
    }
}

struct TQVThreadBar: View {
    let side: CGFloat

    var body: some View {
        HStack(spacing: side * 0.012) {
            Capsule().fill(TQVFiberPalette.strandColor(.indigo).opacity(0.55))
            Capsule().fill(TQVFiberPalette.strandColor(.saffron).opacity(0.55))
            Capsule().fill(TQVFiberPalette.strandColor(.jade).opacity(0.55))
        }
        .frame(height: 3)
        .padding(.horizontal, side * 0.22)
    }
}
