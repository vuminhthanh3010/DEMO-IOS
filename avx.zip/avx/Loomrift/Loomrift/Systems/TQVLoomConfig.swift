import Foundation

enum TQVLoomConfig {
    static let storeID = "000000000"
    static let appName = "Loomrift"
    static let reviewURL = "https://apps.apple.com/app/id\(storeID)?action=write-review"
}
