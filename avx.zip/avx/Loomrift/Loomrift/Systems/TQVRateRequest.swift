import StoreKit
import UIKit

enum TQVRateRequest {
    static func prompt() {
        guard let scene = UIApplication.shared.windows.first?.windowScene else { return }
        SKStoreReviewController.requestReview(in: scene)
    }

    static func openStorePage() {
        guard let url = URL(string: TQVLoomConfig.reviewURL) else { return }
        UIApplication.shared.open(url)
    }
}
