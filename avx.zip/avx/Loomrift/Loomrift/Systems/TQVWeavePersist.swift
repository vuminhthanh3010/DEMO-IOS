import Foundation

enum TQVWeavePersist {
    private static let ledgerKey = "tqv_spool_ledger"
    private static let savedGameKey = "tqv_saved_game"

    static func loadLedger() -> TQVSpoolLedger {
        guard let data = UserDefaults.standard.data(forKey: ledgerKey),
              let ledger = try? JSONDecoder().decode(TQVSpoolLedger.self, from: data)
        else { return TQVSpoolLedger() }
        return ledger
    }

    static func saveLedger(_ ledger: TQVSpoolLedger) {
        guard let data = try? JSONEncoder().encode(ledger) else { return }
        UserDefaults.standard.set(data, forKey: ledgerKey)
    }

    static func loadGame() -> TQVSavedGame? {
        guard let data = UserDefaults.standard.data(forKey: savedGameKey),
              let game = try? JSONDecoder().decode(TQVSavedGame.self, from: data)
        else { return nil }
        return game
    }

    static func saveGame(_ game: TQVSavedGame) {
        guard let data = try? JSONEncoder().encode(game) else { return }
        UserDefaults.standard.set(data, forKey: savedGameKey)
    }

    static func clearGame() {
        UserDefaults.standard.removeObject(forKey: savedGameKey)
    }

    static func clearAll() {
        UserDefaults.standard.removeObject(forKey: ledgerKey)
        UserDefaults.standard.removeObject(forKey: savedGameKey)
    }

    private static func dailyDateKey() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: Date())
    }

    static func isDailyCompleted() -> Bool {
        UserDefaults.standard.bool(forKey: "tqv_daily_\(dailyDateKey())")
    }

    static func markDailyCompleted() {
        UserDefaults.standard.set(true, forKey: "tqv_daily_\(dailyDateKey())")
    }
}

struct TQVSavedGame: Codable {
    let puzzle: TQVPuzzle
    let moveHistory: [TQVShuttleMove]
    let elapsed: Double
    let hintsUsed: Int
}
