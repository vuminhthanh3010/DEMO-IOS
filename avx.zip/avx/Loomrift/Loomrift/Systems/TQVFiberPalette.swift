import SwiftUI

enum TQVStageTone: CaseIterable {
    case unwind
    case spindle
    case loom
    case tapestry
    case heddle
    case bobbin
}

enum TQVColorTheme: String, CaseIterable, Codable {
    case ruby
    case sapphire
    case onyx
}

enum TQVFontLevel {
    case caption, body, title, headline, giant
}

enum TQVFiberPalette {

    static var currentTheme: TQVColorTheme {
        TQVColorTheme(rawValue: UserDefaults.standard.string(forKey: "tqv_color_theme") ?? "ruby") ?? .ruby
    }

    static func strandColor(_ tone: TQVStrandTone) -> Color {
        let t = currentTheme
        switch (t, tone) {
        case (.ruby, .indigo):    return Color(red: 0.88, green: 0.22, blue: 0.27)
        case (.ruby, .saffron):   return Color(red: 0.94, green: 0.74, blue: 0.16)
        case (.ruby, .jade):      return Color(red: 0.52, green: 0.28, blue: 0.80)

        case (.sapphire, .indigo):  return Color(red: 0.24, green: 0.50, blue: 0.88)
        case (.sapphire, .saffron): return Color(red: 0.10, green: 0.76, blue: 0.68)
        case (.sapphire, .jade):    return Color(red: 0.30, green: 0.82, blue: 0.44)

        case (.onyx, .indigo):    return Color(red: 0.74, green: 0.52, blue: 0.90)
        case (.onyx, .saffron):   return Color(red: 0.90, green: 0.64, blue: 0.22)
        case (.onyx, .jade):      return Color(red: 0.32, green: 0.80, blue: 0.80)
        }
    }

    static var accent: Color {
        switch currentTheme {
        case .ruby:     return Color(red: 0.92, green: 0.35, blue: 0.40)
        case .sapphire: return Color(red: 0.30, green: 0.60, blue: 0.95)
        case .onyx:     return Color(red: 0.70, green: 0.55, blue: 0.90)
        }
    }

    static var accentSecondary: Color {
        switch currentTheme {
        case .ruby:     return Color(red: 0.94, green: 0.68, blue: 0.20)
        case .sapphire: return Color(red: 0.15, green: 0.78, blue: 0.72)
        case .onyx:     return Color(red: 0.88, green: 0.62, blue: 0.24)
        }
    }

    static func gradientPair(for tone: TQVStageTone, dark: Bool) -> [Color] {
        let t = currentTheme
        if dark { return darkPair(for: tone, theme: t) }
        return lightPair(for: tone, theme: t)
    }

    private static func lightPair(for tone: TQVStageTone, theme: TQVColorTheme) -> [Color] {
        switch (theme, tone) {
        case (.ruby, .unwind):   return [Color(red: 0.42, green: 0.14, blue: 0.28),
                                         Color(red: 0.28, green: 0.08, blue: 0.20)]
        case (.ruby, .spindle):  return [Color(red: 0.26, green: 0.10, blue: 0.22),
                                         Color(red: 0.18, green: 0.06, blue: 0.16)]
        case (.ruby, .loom):     return [Color(red: 0.12, green: 0.10, blue: 0.18),
                                         Color(red: 0.08, green: 0.06, blue: 0.14)]
        case (.ruby, .tapestry): return [Color(red: 0.14, green: 0.22, blue: 0.18),
                                         Color(red: 0.08, green: 0.16, blue: 0.12)]
        case (.ruby, .heddle):   return [Color(red: 0.16, green: 0.10, blue: 0.20),
                                         Color(red: 0.10, green: 0.06, blue: 0.14)]
        case (.ruby, .bobbin):   return [Color(red: 0.30, green: 0.14, blue: 0.36),
                                         Color(red: 0.20, green: 0.08, blue: 0.26)]

        case (.sapphire, .unwind):   return [Color(red: 0.08, green: 0.20, blue: 0.40),
                                             Color(red: 0.04, green: 0.12, blue: 0.30)]
        case (.sapphire, .spindle):  return [Color(red: 0.06, green: 0.16, blue: 0.34),
                                             Color(red: 0.04, green: 0.10, blue: 0.26)]
        case (.sapphire, .loom):     return [Color(red: 0.06, green: 0.10, blue: 0.20),
                                             Color(red: 0.04, green: 0.08, blue: 0.16)]
        case (.sapphire, .tapestry): return [Color(red: 0.06, green: 0.22, blue: 0.22),
                                             Color(red: 0.04, green: 0.16, blue: 0.16)]
        case (.sapphire, .heddle):   return [Color(red: 0.06, green: 0.12, blue: 0.24),
                                             Color(red: 0.04, green: 0.08, blue: 0.18)]
        case (.sapphire, .bobbin):   return [Color(red: 0.08, green: 0.14, blue: 0.34),
                                             Color(red: 0.04, green: 0.10, blue: 0.24)]

        case (.onyx, .unwind):   return [Color(red: 0.18, green: 0.12, blue: 0.26),
                                         Color(red: 0.10, green: 0.06, blue: 0.18)]
        case (.onyx, .spindle):  return [Color(red: 0.12, green: 0.10, blue: 0.18),
                                         Color(red: 0.08, green: 0.06, blue: 0.12)]
        case (.onyx, .loom):     return [Color(red: 0.08, green: 0.08, blue: 0.10),
                                         Color(red: 0.05, green: 0.05, blue: 0.08)]
        case (.onyx, .tapestry): return [Color(red: 0.08, green: 0.14, blue: 0.12),
                                         Color(red: 0.05, green: 0.10, blue: 0.08)]
        case (.onyx, .heddle):   return [Color(red: 0.10, green: 0.08, blue: 0.14),
                                         Color(red: 0.06, green: 0.05, blue: 0.10)]
        case (.onyx, .bobbin):   return [Color(red: 0.14, green: 0.10, blue: 0.22),
                                         Color(red: 0.08, green: 0.06, blue: 0.16)]
        }
    }

    private static func darkPair(for tone: TQVStageTone, theme: TQVColorTheme) -> [Color] {
        switch (theme, tone) {
        case (.ruby, .unwind):   return [Color(red: 0.22, green: 0.06, blue: 0.14),
                                         Color(red: 0.12, green: 0.02, blue: 0.08)]
        case (.ruby, .spindle):  return [Color(red: 0.16, green: 0.04, blue: 0.12),
                                         Color(red: 0.08, green: 0.02, blue: 0.06)]
        case (.ruby, .loom):     return [Color(red: 0.07, green: 0.05, blue: 0.10),
                                         Color(red: 0.04, green: 0.03, blue: 0.07)]
        case (.ruby, .tapestry): return [Color(red: 0.06, green: 0.12, blue: 0.08),
                                         Color(red: 0.03, green: 0.08, blue: 0.05)]
        case (.ruby, .heddle):   return [Color(red: 0.10, green: 0.05, blue: 0.12),
                                         Color(red: 0.06, green: 0.03, blue: 0.08)]
        case (.ruby, .bobbin):   return [Color(red: 0.16, green: 0.06, blue: 0.20),
                                         Color(red: 0.10, green: 0.03, blue: 0.14)]

        case (.sapphire, .unwind):   return [Color(red: 0.04, green: 0.10, blue: 0.24),
                                             Color(red: 0.02, green: 0.06, blue: 0.16)]
        case (.sapphire, .spindle):  return [Color(red: 0.03, green: 0.08, blue: 0.20),
                                             Color(red: 0.02, green: 0.05, blue: 0.14)]
        case (.sapphire, .loom):     return [Color(red: 0.03, green: 0.06, blue: 0.12),
                                             Color(red: 0.02, green: 0.04, blue: 0.09)]
        case (.sapphire, .tapestry): return [Color(red: 0.03, green: 0.14, blue: 0.14),
                                             Color(red: 0.02, green: 0.08, blue: 0.08)]
        case (.sapphire, .heddle):   return [Color(red: 0.03, green: 0.07, blue: 0.16),
                                             Color(red: 0.02, green: 0.04, blue: 0.10)]
        case (.sapphire, .bobbin):   return [Color(red: 0.04, green: 0.08, blue: 0.20),
                                             Color(red: 0.02, green: 0.05, blue: 0.14)]

        case (.onyx, .unwind):   return [Color(red: 0.12, green: 0.06, blue: 0.16),
                                         Color(red: 0.06, green: 0.03, blue: 0.10)]
        case (.onyx, .spindle):  return [Color(red: 0.08, green: 0.06, blue: 0.12),
                                         Color(red: 0.04, green: 0.03, blue: 0.07)]
        case (.onyx, .loom):     return [Color(red: 0.05, green: 0.05, blue: 0.07),
                                         Color(red: 0.03, green: 0.03, blue: 0.05)]
        case (.onyx, .tapestry): return [Color(red: 0.05, green: 0.09, blue: 0.07),
                                         Color(red: 0.03, green: 0.06, blue: 0.04)]
        case (.onyx, .heddle):   return [Color(red: 0.06, green: 0.05, blue: 0.09),
                                         Color(red: 0.03, green: 0.03, blue: 0.06)]
        case (.onyx, .bobbin):   return [Color(red: 0.09, green: 0.06, blue: 0.14),
                                         Color(red: 0.05, green: 0.03, blue: 0.09)]
        }
    }

    static func fontSize(_ level: TQVFontLevel, side: CGFloat) -> CGFloat {
        let base = side * 0.042
        switch level {
        case .caption:  return base * 0.75
        case .body:     return base
        case .title:    return base * 1.45
        case .headline: return base * 1.9
        case .giant:    return base * 2.8
        }
    }
}
