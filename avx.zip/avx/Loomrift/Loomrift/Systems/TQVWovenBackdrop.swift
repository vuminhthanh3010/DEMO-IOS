import SwiftUI

struct TQVWovenBackdrop: View {
    let tone: TQVStageTone
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let colors = TQVFiberPalette.gradientPair(for: tone, dark: scheme == .dark)
        ZStack {
            LinearGradient(colors: colors + [colors.last ?? colors[0]],
                           startPoint: gradStart,
                           endPoint: gradEnd)

            RadialGradient(
                colors: [glowColor.opacity(0.38), Color.clear],
                center: glowAnchor,
                startRadius: 8,
                endRadius: 380
            )
            .blur(radius: 18)

            RadialGradient(
                colors: [TQVFiberPalette.accentSecondary.opacity(0.18), Color.clear],
                center: secondaryGlow,
                startRadius: 4,
                endRadius: 260
            )
            .blur(radius: 12)

            GeometryReader { geo in
                weaveMesh(w: geo.size.width, h: geo.size.height)
                decorations(w: geo.size.width, h: geo.size.height)
            }
        }
        .ignoresSafeArea()
    }

    private var gradStart: UnitPoint {
        switch tone {
        case .unwind:   return .topLeading
        case .spindle:  return .top
        case .loom:     return .topLeading
        case .tapestry: return .bottomLeading
        case .heddle:   return .leading
        case .bobbin:   return .topTrailing
        }
    }

    private var gradEnd: UnitPoint {
        switch tone {
        case .unwind:   return .bottomTrailing
        case .spindle:  return .bottomTrailing
        case .loom:     return .bottomTrailing
        case .tapestry: return .topTrailing
        case .heddle:   return .trailing
        case .bobbin:   return .bottomLeading
        }
    }

    private var glowColor: Color {
        switch tone {
        case .unwind:   return TQVFiberPalette.accent
        case .spindle:  return TQVFiberPalette.strandColor(.indigo)
        case .loom:     return TQVFiberPalette.strandColor(.jade)
        case .tapestry: return TQVFiberPalette.accentSecondary
        case .heddle:   return Color.white
        case .bobbin:   return TQVFiberPalette.strandColor(.saffron)
        }
    }

    private var glowAnchor: UnitPoint {
        switch tone {
        case .unwind:   return .center
        case .spindle:  return .topTrailing
        case .loom:     return .center
        case .tapestry: return .top
        case .heddle:   return .bottomLeading
        case .bobbin:   return .bottomTrailing
        }
    }

    private var secondaryGlow: UnitPoint {
        switch tone {
        case .unwind:   return .bottomTrailing
        case .spindle:  return .bottomLeading
        case .loom:     return .topTrailing
        case .tapestry: return .bottom
        case .heddle:   return .topTrailing
        case .bobbin:   return .topLeading
        }
    }

    private var meshTones: [Color] {
        [TQVFiberPalette.strandColor(.indigo),
         TQVFiberPalette.strandColor(.saffron),
         TQVFiberPalette.strandColor(.jade)]
    }

    private func weaveMesh(w: CGFloat, h: CGFloat) -> some View {
        ZStack {
            ForEach(0..<7, id: \.self) { i in
                Path { p in
                    let x = w * (0.08 + CGFloat(i) * 0.14)
                    p.move(to: CGPoint(x: x, y: 0))
                    p.addLine(to: CGPoint(x: x + w * 0.08, y: h))
                }
                .stroke(meshTones[i % 3].opacity(0.05), lineWidth: 1.4)
            }
            ForEach(0..<9, id: \.self) { i in
                Path { p in
                    let y = h * (0.06 + CGFloat(i) * 0.11)
                    p.move(to: CGPoint(x: 0, y: y))
                    p.addLine(to: CGPoint(x: w, y: y + 8))
                }
                .stroke(meshTones[(i + 1) % 3].opacity(0.035), lineWidth: 1.2)
            }
        }
        .allowsHitTesting(false)
    }

    @ViewBuilder
    private func decorations(w: CGFloat, h: CGFloat) -> some View {
        switch tone {
        case .unwind:
            unwindDeco(w: w, h: h)
        case .spindle:
            spindleDeco(w: w, h: h)
        case .loom:
            loomDeco(w: w, h: h)
        case .tapestry:
            tapestryDeco(w: w, h: h)
        case .heddle:
            heddleDeco(w: w, h: h)
        case .bobbin:
            bobbinDeco(w: w, h: h)
        }
    }

    private func unwindDeco(w: CGFloat, h: CGFloat) -> some View {
        ZStack {
            Circle()
                .stroke(TQVFiberPalette.accent.opacity(0.16), lineWidth: 18)
                .blur(radius: 10)
                .frame(width: w * 0.72, height: w * 0.72)
                .position(x: w * 0.5, y: h * 0.4)
            Circle()
                .stroke(Color.white.opacity(0.06), lineWidth: 1.5)
                .frame(width: w * 0.95, height: w * 0.95)
                .position(x: w * 0.5, y: h * 0.4)
            Circle()
                .fill(TQVFiberPalette.accentSecondary.opacity(0.08))
                .frame(width: w * 0.38, height: w * 0.38)
                .position(x: w * 0.22, y: h * 0.72)
        }
    }

    private func spindleDeco(w: CGFloat, h: CGFloat) -> some View {
        ZStack {
            Circle()
                .fill(TQVFiberPalette.strandColor(.indigo).opacity(0.16))
                .blur(radius: 8)
                .frame(width: w * 0.78, height: w * 0.78)
                .position(x: w * 0.92, y: h * 0.04)
            Circle()
                .fill(TQVFiberPalette.strandColor(.jade).opacity(0.10))
                .frame(width: w * 0.52, height: w * 0.52)
                .position(x: w * 0.02, y: h * 0.62)
            RoundedRectangle(cornerRadius: 200)
                .fill(Color.white.opacity(0.035))
                .frame(width: w * 1.5, height: w * 0.16)
                .rotationEffect(.degrees(-28))
                .position(x: w * 0.45, y: h * 0.28)
        }
    }

    private func loomDeco(w: CGFloat, h: CGFloat) -> some View {
        ZStack {
            Circle()
                .fill(TQVFiberPalette.strandColor(.jade).opacity(0.10))
                .frame(width: w * 0.9, height: w * 0.9)
                .position(x: w * 0.5, y: h * 0.42)
            ForEach(0..<3, id: \.self) { i in
                Rectangle()
                    .fill(Color.white.opacity(0.03))
                    .frame(width: 1.2, height: h)
                    .position(x: w * (0.22 + CGFloat(i) * 0.28), y: h * 0.5)
            }
        }
    }

    private func tapestryDeco(w: CGFloat, h: CGFloat) -> some View {
        ZStack {
            Circle()
                .fill(TQVFiberPalette.accentSecondary.opacity(0.18))
                .blur(radius: 6)
                .frame(width: w * 0.56, height: w * 0.56)
                .position(x: w * 0.5, y: h * 0.2)
            Circle()
                .stroke(Color.white.opacity(0.06), lineWidth: 2)
                .frame(width: w * 1.05, height: w * 1.05)
                .position(x: w * 0.5, y: h * 0.26)
        }
    }

    private func heddleDeco(w: CGFloat, h: CGFloat) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 200)
                .fill(Color.white.opacity(0.035))
                .frame(width: w * 1.7, height: w * 0.22)
                .rotationEffect(.degrees(-38))
                .position(x: w * 0.42, y: h * 0.22)
            Circle()
                .fill(TQVFiberPalette.accent.opacity(0.08))
                .frame(width: w * 0.46, height: w * 0.46)
                .position(x: w * 0.9, y: h * 0.78)
        }
    }

    private func bobbinDeco(w: CGFloat, h: CGFloat) -> some View {
        ZStack {
            Circle()
                .fill(TQVFiberPalette.strandColor(.indigo).opacity(0.14))
                .frame(width: w * 0.6, height: w * 0.6)
                .position(x: w * 0.94, y: h * 0.06)
            Circle()
                .fill(TQVFiberPalette.strandColor(.saffron).opacity(0.10))
                .frame(width: w * 0.5, height: w * 0.5)
                .position(x: w * 0.06, y: h * 0.88)
        }
    }
}
