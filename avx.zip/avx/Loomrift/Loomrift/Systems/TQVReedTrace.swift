import Foundation

enum TQVReedTrace {
    static func line(_ tag: String, _ msg: String) {
        #if DEBUG
        print("[\(tag)] \(msg)")
        fflush(stdout)
        #endif
    }

    static func reveal(_ solution: [TQVShuttleMove]) {
        #if DEBUG
        let desc = solution.map { m in
            let s = m.side == .warp ? "W" : "E"
            return "\(s)(\(m.row),\(m.col))"
        }.joined(separator: " → ")
        print("[board] solution: \(desc)")
        fflush(stdout)
        #endif
    }
}
