import Foundation

struct TQVSpoolLedger: Codable, Equatable {
    var totalPlayed: Int = 0
    var totalWon: Int = 0
    var currentStreak: Int = 0
    var bestStreak: Int = 0
    var bestMoves: [String: Int] = [:]
    var bestTime: [String: Double] = [:]
    var achievements: Set<String> = []
    var dailyWins: Int = 0

    static let achievementKeys = [
        "first_weave", "five_weaves", "twenty_weaves",
        "optimal_path", "no_hint", "all_tiers",
        "speed_demon", "streak_master", "centurion", "all_modes"
    ]

    var winRate: Double {
        guard totalPlayed > 0 else { return 0 }
        return Double(totalWon) / Double(totalPlayed) * 100
    }

    mutating func recordWin(mode: TQVWeaveMode, tier: TQVWeaveTier,
                            moves: Int, time: Double) {
        totalPlayed += 1
        totalWon += 1
        currentStreak += 1
        if currentStreak > bestStreak { bestStreak = currentStreak }

        let key = "\(mode.rawValue)_\(tier.rawValue)"
        if let prev = bestMoves[key] {
            if moves < prev { bestMoves[key] = moves }
        } else {
            bestMoves[key] = moves
        }
        if let prev = bestTime[key] {
            if time < prev { bestTime[key] = time }
        } else {
            bestTime[key] = time
        }

        updateAchievements(mode: mode, tier: tier, moves: moves, time: time)
    }

    mutating func recordLoss() {
        totalPlayed += 1
        currentStreak = 0
    }

    mutating func reset() {
        self = TQVSpoolLedger()
    }

    private mutating func updateAchievements(mode: TQVWeaveMode, tier: TQVWeaveTier,
                                             moves: Int, time: Double) {
        if totalWon >= 1 { achievements.insert("first_weave") }
        if totalWon >= 5 { achievements.insert("five_weaves") }
        if totalWon >= 20 { achievements.insert("twenty_weaves") }
        if totalWon >= 100 { achievements.insert("centurion") }
        if currentStreak >= 10 { achievements.insert("streak_master") }
        if time <= 30.0 { achievements.insert("speed_demon") }

        let allTiers = TQVWeaveTier.allCases.allSatisfy { t in
            bestMoves["\(mode.rawValue)_\(t.rawValue)"] != nil
        }
        if allTiers { achievements.insert("all_tiers") }

        let tandemWon = TQVWeaveTier.allCases.contains { t in
            bestMoves["tandem_\(t.rawValue)"] != nil
        }
        let echoWon = TQVWeaveTier.allCases.contains { t in
            bestMoves["echo_\(t.rawValue)"] != nil
        }
        if tandemWon && echoWon { achievements.insert("all_modes") }
    }
}
