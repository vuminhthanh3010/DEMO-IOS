import Foundation

enum TQVStrandTone: Int, CaseIterable, Codable, Equatable {
    case indigo = 0
    case saffron = 1
    case jade = 2

    func advanced(by delta: Int) -> TQVStrandTone {
        let raw = ((self.rawValue + delta) % 3 + 3) % 3
        return TQVStrandTone(rawValue: raw)!
    }

    var next: TQVStrandTone { advanced(by: 1) }
    var prev: TQVStrandTone { advanced(by: -1) }
}
