import Foundation

struct TQVPuzzle: Codable {
    let mode: TQVWeaveMode
    let tier: TQVWeaveTier
    var board: TQVDualWeave
    let warpTarget: TQVWarpField
    let weftTarget: TQVWarpField
    let solution: [TQVShuttleMove]
}

enum TQVShuttleForge {

    static func compose(mode: TQVWeaveMode, tier: TQVWeaveTier, seed: UInt64) -> TQVPuzzle {
        var rng = TQVSeededRNG(seed: seed)
        let rows = tier.gridRows
        let cols = tier.gridCols

        let warpTarget = TQVWarpField.random(rows: rows, cols: cols, rng: &rng)
        let weftTarget: TQVWarpField
        switch mode {
        case .tandem:
            weftTarget = TQVWarpField.random(rows: rows, cols: cols, rng: &rng)
        case .echo:
            weftTarget = echoTarget(warp: warpTarget, rows: rows, cols: cols)
        }

        var board = TQVDualWeave(warp: warpTarget, weft: weftTarget)
        let scrambleCount = tier.scrambleRange.lowerBound +
            rng.nextInt(below: tier.scrambleRange.upperBound - tier.scrambleRange.lowerBound + 1)

        var forwardMoves: [TQVShuttleMove] = []
        var currentSide: TQVLoomSide = (scrambleCount % 2 == 0) ? .warp : .weft

        for _ in 0..<scrambleCount {
            let r = rng.nextInt(below: rows)
            let c = rng.nextInt(below: cols)
            let move = TQVShuttleMove(side: currentSide, row: r, col: c)
            board.apply(move)
            forwardMoves.append(move)
            currentSide = currentSide.opposite
        }

        let solution = inversePath(forwardMoves)

        return TQVPuzzle(
            mode: mode, tier: tier,
            board: board,
            warpTarget: warpTarget, weftTarget: weftTarget,
            solution: solution
        )
    }

    private static func inversePath(_ forward: [TQVShuttleMove]) -> [TQVShuttleMove] {
        forward.reversed().map { move in
            TQVShuttleMove(side: move.side.opposite, row: move.row, col: move.col)
        }
    }

    static func dailySeed() -> UInt64 {
        let cal = Calendar.current
        let comps = cal.dateComponents([.year, .month, .day], from: Date())
        return UInt64((comps.year ?? 2026) * 10000 + (comps.month ?? 1) * 100 + (comps.day ?? 1))
    }

    static var dailyMode: TQVWeaveMode {
        let day = Calendar.current.component(.day, from: Date())
        return day % 2 == 0 ? .tandem : .echo
    }

    static var dailyTier: TQVWeaveTier { .normal }

    private static func echoTarget(warp: TQVWarpField, rows: Int, cols: Int) -> TQVWarpField {
        return warp
    }
}
