import Foundation

enum TQVWeaveOracle {

    static func solve(_ puzzle: TQVPuzzle) -> [TQVShuttleMove]? {
        return puzzle.solution
    }

    static func hint(puzzle: TQVPuzzle, movesDone: Int) -> TQVShuttleMove? {
        guard movesDone < puzzle.solution.count else { return nil }
        return puzzle.solution[movesDone]
    }

    static func hintFromCurrentState(
        board: TQVDualWeave,
        warpTarget: TQVWarpField,
        weftTarget: TQVWarpField,
        currentSide: TQVLoomSide
    ) -> TQVShuttleMove? {
        var warpNeeded: [(Int, Int)] = []
        var weftNeeded: [(Int, Int)] = []

        for r in 0..<board.rows {
            for c in 0..<board.cols {
                let dw = (warpTarget[r, c].rawValue - board.warp[r, c].rawValue + 3) % 3
                switch dw {
                case 1: warpNeeded.append((r, c))
                case 2: weftNeeded.append((r, c))
                default: break
                }
            }
        }

        switch currentSide {
        case .warp:
            if let first = warpNeeded.first {
                return TQVShuttleMove(side: .warp, row: first.0, col: first.1)
            }
            if let pass = weftNeeded.first {
                return TQVShuttleMove(side: .warp, row: pass.0, col: pass.1)
            }
        case .weft:
            if let first = weftNeeded.first {
                return TQVShuttleMove(side: .weft, row: first.0, col: first.1)
            }
            if let pass = warpNeeded.first {
                return TQVShuttleMove(side: .weft, row: pass.0, col: pass.1)
            }
        }

        return nil
    }

    static func verify(_ puzzle: TQVPuzzle) -> Bool {
        var board = puzzle.board
        for move in puzzle.solution {
            board.apply(move)
        }
        return board.isComplete(
            warpTarget: puzzle.warpTarget,
            weftTarget: puzzle.weftTarget
        )
    }
}
