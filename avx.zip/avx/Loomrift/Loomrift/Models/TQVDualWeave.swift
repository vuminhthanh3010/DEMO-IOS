import Foundation

enum TQVLoomSide: Int, CaseIterable, Codable {
    case warp = 0
    case weft = 1

    var opposite: TQVLoomSide { self == .warp ? .weft : .warp }
}

struct TQVShuttleMove: Equatable, Codable {
    let side: TQVLoomSide
    let row: Int
    let col: Int
}

enum TQVWeaveMode: String, CaseIterable, Codable {
    case tandem
    case echo
}

enum TQVWeaveTier: String, CaseIterable, Codable {
    case easy
    case normal
    case hard

    var gridRows: Int {
        switch self {
        case .easy: return 2
        case .normal: return 3
        case .hard: return 3
        }
    }

    var gridCols: Int {
        switch self {
        case .easy: return 3
        case .normal: return 3
        case .hard: return 4
        }
    }

    var scrambleRange: ClosedRange<Int> {
        switch self {
        case .easy: return 4...6
        case .normal: return 8...12
        case .hard: return 14...20
        }
    }

    var hintBudget: Int {
        switch self {
        case .easy: return 3
        case .normal: return 2
        case .hard: return 1
        }
    }
}

struct TQVDualWeave: Equatable, Codable {
    var warp: TQVWarpField
    var weft: TQVWarpField

    var rows: Int { warp.rows }
    var cols: Int { warp.cols }

    mutating func apply(_ move: TQVShuttleMove) {
        switch move.side {
        case .warp:
            warp.cycle(r: move.row, c: move.col, delta: 1)
            weft.cycle(r: move.row, c: move.col, delta: -1)
        case .weft:
            weft.cycle(r: move.row, c: move.col, delta: 1)
            warp.cycle(r: move.row, c: move.col, delta: -1)
        }
    }

    func isComplete(warpTarget: TQVWarpField, weftTarget: TQVWarpField) -> Bool {
        warp.matches(warpTarget) && weft.matches(weftTarget)
    }
}
