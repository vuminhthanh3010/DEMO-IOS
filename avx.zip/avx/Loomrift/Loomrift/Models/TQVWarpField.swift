import Foundation

struct TQVWarpField: Equatable, Codable {
    let rows: Int
    let cols: Int
    private(set) var cells: [TQVStrandTone]

    init(rows: Int, cols: Int, fill: TQVStrandTone = .indigo) {
        self.rows = rows
        self.cols = cols
        self.cells = Array(repeating: fill, count: rows * cols)
    }

    init(rows: Int, cols: Int, cells: [TQVStrandTone]) {
        self.rows = rows
        self.cols = cols
        assert(cells.count == rows * cols)
        self.cells = cells
    }

    var count: Int { rows * cols }

    subscript(r: Int, c: Int) -> TQVStrandTone {
        get { cells[r * cols + c] }
        set { cells[r * cols + c] = newValue }
    }

    func index(r: Int, c: Int) -> Int { r * cols + c }

    mutating func cycle(r: Int, c: Int, delta: Int) {
        let i = index(r: r, c: c)
        cells[i] = cells[i].advanced(by: delta)
    }

    func matches(_ target: TQVWarpField) -> Bool {
        cells == target.cells
    }

    func matchCount(against target: TQVWarpField) -> Int {
        zip(cells, target.cells).filter { $0 == $1 }.count
    }

    static func random(rows: Int, cols: Int, rng: inout TQVSeededRNG) -> TQVWarpField {
        let cells = (0..<rows * cols).map { _ in
            TQVStrandTone.allCases[Int(rng.next() % 3)]
        }
        return TQVWarpField(rows: rows, cols: cols, cells: cells)
    }
}
