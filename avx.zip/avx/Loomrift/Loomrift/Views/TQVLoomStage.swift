import SwiftUI

struct TQVLoomStage: View {
    @ObservedObject var conductor: TQVShuttleConductor
    let onHome: () -> Void
    @State private var showShare = false
    @AppStorage("tqv_hints_enabled") private var hintsEnabled = true

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                TQVWovenBackdrop(tone: .loom)
                if conductor.isPaused {
                    pauseOverlay(side: side)
                } else {
                    playLayout(side: side, geo: geo)
                }
            }
        }
        .sheet(isPresented: $showShare) {
            TQVRelayCard(payload: [conductor.shareText()])
        }
    }

    private func playLayout(side: CGFloat, geo: GeometryProxy) -> some View {
        ZStack {
            VStack(spacing: side * 0.014) {
                header(side: side)
                progress(side: side)
            }
            .padding(.horizontal, side * 0.035)
            .padding(.top, side * 0.006)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

            VStack(spacing: side * 0.03) {
                boards(side: side)
                TQVTurnBeacon(currentSide: conductor.currentSide, side: side)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)

            controls(side: side)
                .padding(.horizontal, side * 0.035)
                .padding(.bottom, max(geo.safeAreaInsets.bottom * 0.4, side * 0.02))
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
        }
    }

    private func header(side: CGFloat) -> some View {
        HStack(spacing: side * 0.018) {
            Button(action: onHome) {
                TQVFacetButton(icon: "chevron.left", size: side * 0.09)
            }

            statPill(icon: "arrow.left.arrow.right",
                     text: "\(conductor.moveCount)",
                     color: moveColor, side: side)
            statPill(icon: "clock",
                     text: formatTime(conductor.elapsed),
                     color: .white.opacity(0.78), side: side)

            if conductor.isDailyPuzzle {
                Image(systemName: "sun.max.fill")
                    .font(.system(size: side * 0.024))
                    .foregroundColor(TQVFiberPalette.accentSecondary)
            }

            Spacer(minLength: 0)

            Button(action: { conductor.togglePause() }) {
                TQVFacetButton(icon: "pause.fill", size: side * 0.09)
            }
        }
        .padding(.top, side * 0.006)
    }

    private func statPill(icon: String, text: String, color: Color, side: CGFloat) -> some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: side * 0.018, weight: .semibold))
            Text(text)
                .font(.system(size: side * 0.026, weight: .bold, design: .rounded))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .foregroundColor(color)
        .padding(.horizontal, side * 0.018)
        .padding(.vertical, side * 0.01)
        .background(TQVGlassPlate(radius: 20, tint: Color.black.opacity(0.22)))
    }

    private func progress(side: CGFloat) -> some View {
        GeometryReader { bar in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.08))
                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [TQVFiberPalette.accent, TQVFiberPalette.accentSecondary],
                            startPoint: .leading, endPoint: .trailing
                        )
                    )
                    .frame(width: max(6, bar.size.width * CGFloat(conductor.matchProgress)))
                    .shadow(color: TQVFiberPalette.accent.opacity(0.45), radius: 4)
                    .animation(.easeInOut(duration: 0.28), value: conductor.matchProgress)
            }
        }
        .frame(height: 5)
        .padding(.horizontal, side * 0.01)
    }

    private var moveColor: Color {
        guard conductor.optimalMoves > 0 else { return .white }
        let ratio = Double(conductor.moveCount) / Double(conductor.optimalMoves)
        if ratio <= 1.0 { return TQVFiberPalette.strandColor(.jade) }
        if ratio <= 1.5 { return TQVFiberPalette.accentSecondary }
        if ratio <= 2.0 { return TQVFiberPalette.strandColor(.saffron) }
        return TQVFiberPalette.strandColor(.indigo)
    }

    private func boards(side: CGFloat) -> some View {
        let gridSide = side * 0.40
        return HStack(alignment: .top, spacing: side * 0.03) {
            boardColumn(side: .warp, gridSide: gridSide, canvas: side)
            boardColumn(side: .weft, gridSide: gridSide, canvas: side)
        }
    }

    private func boardColumn(side loom: TQVLoomSide, gridSide: CGFloat, canvas: CGFloat) -> some View {
        let target = loom == .warp ? conductor.puzzle.warpTarget : conductor.puzzle.weftTarget
        let field = loom == .warp ? conductor.board.warp : conductor.board.weft
        let active = conductor.currentSide == loom
        return VStack(spacing: canvas * 0.012) {
            TQVTargetThumb(field: target, thumbSide: canvas * 0.15)
            Text("GOAL")
                .font(.system(size: canvas * 0.016, weight: .bold, design: .rounded))
                .tracking(1.4)
                .foregroundColor(.white.opacity(0.28))

            TQVFieldGrid(
                field: field,
                target: target,
                side: loom,
                isActive: active,
                hintedMove: conductor.hintedMove,
                wrongMove: conductor.wrongMove,
                gridSide: gridSide
            ) { r, c in
                conductor.tapCell(side: loom, row: r, col: c)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private func controls(side: CGFloat) -> some View {
        HStack(spacing: side * 0.04) {
            ctrl("arrow.uturn.backward", "Undo", conductor.moveHistory.isEmpty, side) {
                conductor.undo()
            }
            if hintsEnabled && conductor.hintsRemaining > 0 {
                ZStack(alignment: .topTrailing) {
                    ctrl("lightbulb.fill", "Hint", false, side) { conductor.useHint() }
                    Text("\(conductor.hintsRemaining)")
                        .font(.system(size: side * 0.016, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .frame(width: side * 0.036, height: side * 0.036)
                        .background(Circle().fill(TQVFiberPalette.accent))
                        .offset(x: 4, y: -2)
                }
            }
            ctrl("arrow.clockwise", "New", false, side) { conductor.replay() }
        }
        .padding(.vertical, side * 0.016)
        .padding(.horizontal, side * 0.04)
        .frame(maxWidth: .infinity)
        .background(TQVGlassPlate(radius: side * 0.045, style: .systemThickMaterialDark,
                                  tint: Color.black.opacity(0.28)))
    }

    private func ctrl(_ icon: String, _ label: String, _ off: Bool,
                      _ side: CGFloat, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: side * 0.006) {
                TQVFacetButton(icon: icon, size: side * 0.1, dimmed: off)
                Text(label)
                    .font(.system(size: side * 0.018, weight: .medium, design: .rounded))
                    .foregroundColor(off ? .white.opacity(0.18) : .white.opacity(0.5))
            }
        }
        .disabled(off)
        .frame(maxWidth: .infinity)
    }

    private func pauseOverlay(side: CGFloat) -> some View {
        VStack(spacing: side * 0.03) {
            Spacer()
            TQVFacetButton(icon: "pause.fill", size: side * 0.22)
            Text("Warp Held")
                .font(.system(size: TQVFiberPalette.fontSize(.headline, side: side),
                              weight: .bold, design: .rounded))
                .foregroundColor(.white)
            HStack(spacing: side * 0.05) {
                pauseStat("\(conductor.moveCount)", "Moves", side)
                pauseStat(formatTime(conductor.elapsed), "Time", side)
            }
            Text("\(conductor.selectedMode.rawValue.capitalized)  ·  \(conductor.selectedTier.rawValue.capitalized)")
                .font(.system(size: side * 0.026, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.38))
            Button(action: { conductor.togglePause() }) {
                TQVWeaveCTA(title: "Resume", icon: "play.fill", side: side)
            }
            .padding(.horizontal, side * 0.12)
            Spacer()
        }
        .padding(.horizontal, side * 0.08)
    }

    private func pauseStat(_ value: String, _ label: String, _ side: CGFloat) -> some View {
        VStack(spacing: 3) {
            Text(value)
                .font(.system(size: side * 0.05, weight: .bold, design: .rounded))
                .foregroundColor(.white)
            Text(label)
                .font(.system(size: side * 0.022, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.35))
        }
        .padding(.horizontal, side * 0.03)
        .padding(.vertical, side * 0.016)
        .background(TQVGlassPlate(radius: side * 0.025, tint: Color.white.opacity(0.05)))
    }

    private func formatTime(_ t: Double) -> String {
        let m = Int(t) / 60; let s = Int(t) % 60
        return String(format: "%d:%02d", m, s)
    }
}
