import SwiftUI

struct TQVTapestryStage: View {
    @ObservedObject var conductor: TQVShuttleConductor
    let onHome: () -> Void
    let onReplay: () -> Void
    @State private var showShare = false
    @State private var appear = false

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                TQVWovenBackdrop(tone: .tapestry)
                TQVCelebrationView()
                TQVExpandingRings()

                VStack(spacing: 0) {
                    Spacer(minLength: side * 0.04)
                    headline(side: side)
                    Spacer().frame(height: side * 0.03)
                    scorePair(side: side)
                    newBests(side: side)
                    badges(side: side)
                    Spacer()
                    footer(side: side, inset: geo.safeAreaInsets.bottom)
                }
            }
            .onAppear {
                withAnimation(.spring(response: 0.55, dampingFraction: 0.62)) { appear = true }
            }
        }
        .sheet(isPresented: $showShare) {
            TQVRelayCard(payload: [conductor.shareText()])
        }
    }

    private func headline(side: CGFloat) -> some View {
        VStack(spacing: side * 0.02) {
            HStack(spacing: side * 0.035) {
                ForEach(1..<4, id: \.self) { i in
                    let filled = i <= conductor.starRating
                    Image(systemName: filled ? "star.fill" : "star")
                        .font(.system(size: side * 0.11))
                        .foregroundColor(filled ? TQVFiberPalette.accentSecondary : .white.opacity(0.12))
                        .shadow(color: filled ? TQVFiberPalette.accentSecondary.opacity(0.55) : .clear, radius: 12)
                        .rotationEffect(.degrees(filled && appear ? Double(i - 2) * 8 : 0))
                        .scaleEffect(appear ? 1 : 0.15)
                        .animation(.spring(response: 0.5, dampingFraction: 0.52).delay(Double(i) * 0.1),
                                   value: appear)
                }
            }
            Text(starLabel)
                .font(.system(size: TQVFiberPalette.fontSize(.headline, side: side),
                              weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .opacity(appear ? 1 : 0)
            if conductor.isDailyPuzzle {
                Text("Daily warp complete")
                    .font(.system(size: side * 0.024, weight: .semibold, design: .rounded))
                    .foregroundColor(TQVFiberPalette.accentSecondary)
                    .padding(.horizontal, side * 0.024)
                    .padding(.vertical, side * 0.008)
                    .background(Capsule().fill(TQVFiberPalette.accentSecondary.opacity(0.14)))
            }
        }
    }

    private var starLabel: String {
        switch conductor.starRating {
        case 3:  return "Perfect Path"
        case 2:  return "Clean Weave"
        default: return "Pattern Locked"
        }
    }

    private func scorePair(side: CGFloat) -> some View {
        HStack(spacing: side * 0.02) {
            scoreCard("Moves", "\(conductor.moveCount)",
                      "of \(conductor.optimalMoves)", side, tilt: -2)
            scoreCard("Time", formatTime(conductor.elapsed),
                      conductor.selectedMode.rawValue.capitalized, side, tilt: 2)
        }
        .padding(.horizontal, side * 0.06)
    }

    private func scoreCard(_ title: String, _ value: String,
                           _ sub: String, _ side: CGFloat, tilt: Double) -> some View {
        VStack(spacing: side * 0.008) {
            Text(title.uppercased())
                .font(.system(size: side * 0.018, weight: .bold, design: .rounded))
                .tracking(1.2)
                .foregroundColor(.white.opacity(0.35))
            Text(value)
                .font(.system(size: side * 0.07, weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(sub)
                .font(.system(size: side * 0.022, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.4))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, side * 0.028)
        .background(TQVGlassPlate(radius: side * 0.03, tint: Color.white.opacity(0.05)))
        .rotationEffect(.degrees(tilt))
        .offset(y: tilt > 0 ? 6 : 0)
    }

    private func newBests(side: CGFloat) -> some View {
        VStack(spacing: 6) {
            if conductor.gotNewBestMoves { bestChip("New best moves", side) }
            if conductor.gotNewBestTime { bestChip("New best time", side) }
        }
        .padding(.top, side * 0.02)
        .padding(.horizontal, side * 0.08)
    }

    private func bestChip(_ label: String, _ side: CGFloat) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "crown.fill")
            Text(label)
                .font(.system(size: side * 0.024, weight: .bold, design: .rounded))
        }
        .foregroundColor(TQVFiberPalette.accentSecondary)
        .padding(.vertical, side * 0.01)
        .frame(maxWidth: .infinity)
        .background(
            Capsule().fill(TQVFiberPalette.accentSecondary.opacity(0.12))
        )
    }

    private func badges(side: CGFloat) -> some View {
        let recent = conductor.ledger.achievements.sorted()
        return Group {
            if !recent.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: side * 0.012) {
                        ForEach(recent, id: \.self) { key in
                            HStack(spacing: 5) {
                                Image(systemName: achievementIcon(key))
                                    .font(.system(size: side * 0.018))
                                Text(achievementLabel(key))
                                    .font(.system(size: side * 0.02, weight: .semibold, design: .rounded))
                                    .lineLimit(1)
                            }
                            .foregroundColor(TQVFiberPalette.accent)
                            .padding(.horizontal, side * 0.018)
                            .padding(.vertical, side * 0.01)
                            .background(TQVGlassPlate(radius: 14, tint: TQVFiberPalette.accent.opacity(0.1)))
                        }
                    }
                    .padding(.horizontal, side * 0.06)
                }
                .padding(.top, side * 0.018)
            }
        }
    }

    private func footer(side: CGFloat, inset: CGFloat) -> some View {
        VStack(spacing: side * 0.012) {
            Button(action: onReplay) {
                TQVWeaveCTA(title: "New Weave", icon: "arrow.clockwise", side: side)
            }
            HStack(spacing: side * 0.014) {
                Button(action: onHome) {
                    TQVGhostCTA(title: "Home", icon: "house.fill", side: side)
                }
                Button(action: { showShare = true }) {
                    TQVFacetButton(icon: "square.and.arrow.up", size: side * 0.12)
                }
            }
            Spacer().frame(height: max(inset, side * 0.012))
        }
        .padding(.horizontal, side * 0.06)
    }

    private func achievementLabel(_ key: String) -> String {
        switch key {
        case "first_weave":   return "First Win"
        case "five_weaves":   return "Apprentice"
        case "twenty_weaves": return "Artisan"
        case "optimal_path":  return "Perfect Path"
        case "no_hint":       return "Unaided"
        case "all_tiers":     return "All Tiers"
        case "speed_demon":   return "Speed Demon"
        case "streak_master": return "Streak Master"
        case "centurion":     return "Centurion"
        case "all_modes":     return "Both Modes"
        default:              return key
        }
    }

    private func achievementIcon(_ key: String) -> String {
        switch key {
        case "first_weave":   return "flag.fill"
        case "five_weaves":   return "5.circle.fill"
        case "twenty_weaves": return "20.circle"
        case "optimal_path":  return "checkmark.circle"
        case "no_hint":       return "eye.slash"
        case "all_tiers":     return "chart.bar.fill"
        case "speed_demon":   return "bolt.fill"
        case "streak_master": return "flame.fill"
        case "centurion":     return "star.circle.fill"
        case "all_modes":     return "arrow.left.arrow.right"
        default:              return "star"
        }
    }

    private func formatTime(_ t: Double) -> String {
        let m = Int(t) / 60; let s = Int(t) % 60
        return String(format: "%d:%02d", m, s)
    }
}
