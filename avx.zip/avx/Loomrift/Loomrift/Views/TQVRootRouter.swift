import SwiftUI

struct TQVRootRouter: View {
    @ObservedObject var conductor: TQVShuttleConductor
    @State private var screen: TQVScreen = .splash
    @State private var showMenu = false
    @State private var showGuide = false
    @AppStorage("tqv_default_tier") private var defaultTier = "easy"
    @AppStorage("tqv_hints_enabled") private var hintsEnabled = true
    @AppStorage("tqv_color_theme") private var colorTheme = "ruby"

    enum TQVScreen {
        case splash, home, game, result
    }

    var body: some View {
        ZStack {
            let _ = colorTheme
            switch screen {
            case .splash:
                TQVUnwindStage {
                    withAnimation(.easeInOut(duration: 0.4)) { screen = .home }
                }
                .transition(.opacity)

            case .home:
                TQVSpindleStage(
                    conductor: conductor,
                    showMenu: $showMenu,
                    showGuide: $showGuide,
                    onPlay: {
                        conductor.newGame(mode: conductor.selectedMode,
                                          tier: conductor.selectedTier)
                        withAnimation(.easeInOut(duration: 0.3)) { screen = .game }
                    },
                    onResume: {
                        conductor.resumeSaved()
                        withAnimation(.easeInOut(duration: 0.3)) { screen = .game }
                    },
                    onDaily: {
                        withAnimation(.easeInOut(duration: 0.3)) { screen = .game }
                    }
                )
                .transition(.opacity)

            case .game:
                TQVLoomStage(conductor: conductor) {
                    withAnimation(.easeInOut(duration: 0.3)) { screen = .home }
                }
                .transition(.asymmetric(
                    insertion: .scale(scale: 0.95).combined(with: .opacity),
                    removal: .opacity
                ))
                .onChange(of: conductor.isComplete) { done in
                    if done {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                            withAnimation(.easeInOut(duration: 0.4)) { screen = .result }
                        }
                    }
                }

            case .result:
                TQVTapestryStage(
                    conductor: conductor,
                    onHome: {
                        withAnimation(.easeInOut(duration: 0.3)) { screen = .home }
                    },
                    onReplay: {
                        conductor.replay()
                        withAnimation(.easeInOut(duration: 0.3)) { screen = .game }
                    }
                )
                .transition(.scale(scale: 0.9).combined(with: .opacity))
            }

            if showMenu {
                TQVHeddleStage(isPresented: $showMenu) {
                    conductor.ledger.reset()
                    TQVWeavePersist.clearAll()
                    conductor.ledger = TQVSpoolLedger()
                }
                .transition(.move(edge: .trailing))
                .zIndex(10)
            }

            if showGuide {
                TQVBobbinStage {
                    withAnimation(.spring()) { showGuide = false }
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .zIndex(11)
            }
        }
    }
}
