import SwiftUI

struct TQVUnwindStage: View {
    @State private var phase = 0
    @State private var spin: Double = 0
    let onFinish: () -> Void

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                TQVWovenBackdrop(tone: .unwind)

                VStack(spacing: side * 0.04) {
                    Spacer()

                    ZStack {
                        ForEach(0..<4, id: \.self) { i in
                            Capsule()
                                .fill(ringColor(i).opacity(0.18))
                                .frame(width: side * 0.62, height: side * 0.035)
                                .rotationEffect(.degrees(Double(i) * 45 + spin * 0.15))
                                .opacity(phase >= 1 ? 1 : 0)
                        }

                        TQVLoomMark(size: side * 0.38)
                            .scaleEffect(phase >= 1 ? 1 : 0.2)
                            .rotationEffect(.degrees(spin * 0.08))
                    }
                    .frame(height: side * 0.5)

                    Text("Loomrift")
                        .font(.system(size: TQVFiberPalette.fontSize(.giant, side: side),
                                      weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .shadow(color: TQVFiberPalette.accent.opacity(0.45),
                                radius: side * 0.03, y: 4)
                        .opacity(phase >= 2 ? 1 : 0)
                        .offset(y: phase >= 2 ? 0 : side * 0.04)

                    TQVThreadBar(side: side)
                        .opacity(phase >= 2 ? 1 : 0)

                    Text("TWO GRIDS  ·  ONE TRADE-OFF")
                        .font(.system(size: side * 0.028, weight: .semibold, design: .rounded))
                        .tracking(side * 0.004)
                        .foregroundColor(TQVFiberPalette.accentSecondary.opacity(0.85))
                        .opacity(phase >= 3 ? 1 : 0)

                    Spacer()
                    Spacer()
                }
            }
            .onAppear {
                withAnimation(.spring(response: 0.7, dampingFraction: 0.72)) { phase = 1 }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    withAnimation(.easeOut(duration: 0.45)) { phase = 2 }
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) {
                    withAnimation(.easeOut(duration: 0.45)) { phase = 3 }
                }
                withAnimation(Animation.linear(duration: 16).repeatForever(autoreverses: false)) {
                    spin = 360
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { onFinish() }
            }
        }
    }

    private func ringColor(_ index: Int) -> Color {
        switch index % 3 {
        case 0:  return TQVFiberPalette.accent
        case 1:  return TQVFiberPalette.accentSecondary
        default: return TQVFiberPalette.strandColor(.jade)
        }
    }
}
