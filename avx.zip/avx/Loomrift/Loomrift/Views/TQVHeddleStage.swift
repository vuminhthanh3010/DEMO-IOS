import SwiftUI

struct TQVHeddleStage: View {
    @Binding var isPresented: Bool
    @AppStorage("tqv_haptics") private var hapticsOn = true
    @AppStorage("tqv_hints_enabled") private var hintsEnabled = true
    @AppStorage("tqv_default_tier") private var defaultTier = "easy"
    @AppStorage("tqv_color_theme") private var colorTheme = "ruby"
    @State private var showClearAlert = false
    @State private var showGuide = false
    var onClear: () -> Void

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack(alignment: .trailing) {
                Color.black.opacity(0.48)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.spring()) { isPresented = false }
                    }

                rail(side: side)
                    .frame(width: geo.size.width * 0.86)
                    .transition(.move(edge: .trailing))
            }
            .alert(isPresented: $showClearAlert) {
                Alert(
                    title: Text("Clear Progress"),
                    message: Text("All stats and achievements will be reset."),
                    primaryButton: .destructive(Text("Clear")) { onClear() },
                    secondaryButton: .cancel()
                )
            }
        }
    }

    private func rail(side: CGFloat) -> some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Heddle")
                        .font(.system(size: TQVFiberPalette.fontSize(.title, side: side),
                                      weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    Text("Tune the loom")
                        .font(.system(size: side * 0.022, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.4))
                }
                Spacer()
                Button(action: { withAnimation(.spring()) { isPresented = false } }) {
                    TQVFacetButton(icon: "xmark", size: side * 0.09)
                }
            }
            .padding(.horizontal, side * 0.045)
            .padding(.top, side * 0.05)
            .padding(.bottom, side * 0.02)

            TQVThreadBar(side: side)
                .padding(.bottom, side * 0.02)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: side * 0.022) {
                    section("Gameplay", side: side) {
                        toggleRow("Haptic Feedback", "waveform", $hapticsOn, side)
                            .onChange(of: hapticsOn) { val in TQVLoomHaptics.setEnabled(val) }
                        toggleRow("Show Hints", "lightbulb", $hintsEnabled, side)
                        tierPicker(side: side)
                    }
                    section("Appearance", side: side) {
                        themePicker(side: side)
                    }
                    section("Support", side: side) {
                        Button(action: { TQVRateRequest.prompt() }) {
                            row("star.fill", "Rate Loomrift", .white, side)
                        }
                        Button(action: { TQVRateRequest.openStorePage() }) {
                            row("arrow.up.right.square", "Write a Review", .white, side)
                        }
                        Button(action: { showGuide = true }) {
                            row("questionmark.circle", "How to Play", .white, side)
                        }
                        .fullScreenCover(isPresented: $showGuide) {
                            TQVBobbinStage { showGuide = false }
                        }
                    }
                    section("Data", side: side) {
                        Button(action: { showClearAlert = true }) {
                            row("trash", "Clear Progress", Color.red.opacity(0.85), side)
                        }
                    }
                    VStack(spacing: 4) {
                        Text("Loomrift")
                            .font(.system(size: side * 0.028, weight: .bold, design: .rounded))
                            .foregroundColor(TQVFiberPalette.accent.opacity(0.45))
                        Text("Version 1.0")
                            .font(.system(size: side * 0.02, weight: .medium, design: .rounded))
                            .foregroundColor(.white.opacity(0.22))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, side * 0.02)
                }
                .padding(.horizontal, side * 0.04)
                .padding(.bottom, side * 0.08)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            ZStack {
                TQVWovenBackdrop(tone: .heddle)
                Color.black.opacity(0.25)
            }
        )
        .clipShape(RoundedRectangle(cornerRadius: side * 0.04))
        .overlay(
            RoundedRectangle(cornerRadius: side * 0.04)
                .stroke(Color.white.opacity(0.1), lineWidth: 1)
        )
        .padding(.vertical, 10)
        .padding(.trailing, 8)
    }

    private func section<Content: View>(_ title: String, side: CGFloat,
                                        @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: side * 0.012) {
            Text(title.uppercased())
                .font(.system(size: side * 0.022, weight: .bold, design: .rounded))
                .tracking(1.4)
                .foregroundColor(TQVFiberPalette.accent.opacity(0.65))
            VStack(alignment: .leading, spacing: side * 0.01) {
                content()
            }
            .padding(side * 0.022)
            .background(TQVGlassPlate(radius: side * 0.028, tint: Color.white.opacity(0.05)))
        }
    }

    private func toggleRow(_ label: String, _ icon: String,
                           _ isOn: Binding<Bool>, _ side: CGFloat) -> some View {
        Toggle(isOn: isOn) {
            HStack(spacing: side * 0.018) {
                Image(systemName: icon)
                    .font(.system(size: side * 0.028))
                    .foregroundColor(TQVFiberPalette.accent.opacity(0.7))
                    .frame(width: side * 0.038)
                Text(label)
                    .font(.system(size: TQVFiberPalette.fontSize(.body, side: side),
                                  weight: .medium, design: .rounded))
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
        }
        .toggleStyle(SwitchToggleStyle(tint: TQVFiberPalette.accent))
    }

    private func row(_ icon: String, _ label: String, _ color: Color, _ side: CGFloat) -> some View {
        HStack(spacing: side * 0.018) {
            Image(systemName: icon)
                .font(.system(size: side * 0.028))
                .foregroundColor(color.opacity(0.7))
                .frame(width: side * 0.038)
            Text(label)
                .font(.system(size: TQVFiberPalette.fontSize(.body, side: side),
                              weight: .medium, design: .rounded))
                .foregroundColor(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: side * 0.02, weight: .semibold))
                .foregroundColor(color.opacity(0.28))
        }
        .padding(.vertical, side * 0.008)
    }

    private func tierPicker(side: CGFloat) -> some View {
        VStack(alignment: .leading, spacing: side * 0.01) {
            Text("Default Tier")
                .font(.system(size: TQVFiberPalette.fontSize(.body, side: side),
                              weight: .medium, design: .rounded))
                .foregroundColor(.white)
            HStack(spacing: side * 0.01) {
                ForEach(TQVWeaveTier.allCases, id: \.self) { tier in
                    let sel = defaultTier == tier.rawValue
                    VStack(spacing: 2) {
                        Text(tier.rawValue.capitalized)
                            .font(.system(size: TQVFiberPalette.fontSize(.caption, side: side),
                                          weight: .bold, design: .rounded))
                        Text("\(tier.gridRows)\u{00D7}\(tier.gridCols)")
                            .font(.system(size: side * 0.018, weight: .medium, design: .rounded))
                            .foregroundColor(sel ? .white.opacity(0.5) : .white.opacity(0.2))
                    }
                    .foregroundColor(sel ? .white : .white.opacity(0.38))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, side * 0.012)
                    .background(
                        RoundedRectangle(cornerRadius: side * 0.016)
                            .fill(sel ? TQVFiberPalette.accent.opacity(0.28) : Color.white.opacity(0.05))
                    )
                    .onTapGesture { defaultTier = tier.rawValue }
                }
            }
        }
    }

    private func themePicker(side: CGFloat) -> some View {
        HStack(spacing: side * 0.02) {
            ForEach(TQVColorTheme.allCases, id: \.self) { theme in
                let sel = colorTheme == theme.rawValue
                VStack(spacing: 6) {
                    ZStack {
                        RoundedRectangle(cornerRadius: side * 0.018)
                            .fill(LinearGradient(colors: themeGradient(theme),
                                                 startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: side * 0.13, height: side * 0.075)
                        HStack(spacing: 3) {
                            ForEach(TQVStrandTone.allCases, id: \.self) { t in
                                Circle()
                                    .fill(strandColorForTheme(theme, tone: t))
                                    .frame(width: side * 0.02, height: side * 0.02)
                            }
                        }
                        if sel {
                            Image(systemName: "checkmark")
                                .font(.system(size: side * 0.022, weight: .bold))
                                .foregroundColor(.white)
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: side * 0.018)
                            .stroke(sel ? accentForTheme(theme) : Color.clear, lineWidth: 2)
                    )
                    Text(theme.rawValue.capitalized)
                        .font(.system(size: side * 0.02, weight: .semibold, design: .rounded))
                        .foregroundColor(sel ? .white : .white.opacity(0.4))
                }
                .onTapGesture { colorTheme = theme.rawValue }
            }
        }
    }

    private func themeGradient(_ theme: TQVColorTheme) -> [Color] {
        switch theme {
        case .ruby:
            return [Color(red: 0.72, green: 0.22, blue: 0.28), Color(red: 0.55, green: 0.15, blue: 0.22)]
        case .sapphire:
            return [Color(red: 0.22, green: 0.38, blue: 0.68), Color(red: 0.15, green: 0.28, blue: 0.55)]
        case .onyx:
            return [Color(red: 0.32, green: 0.30, blue: 0.35), Color(red: 0.20, green: 0.18, blue: 0.22)]
        }
    }

    private func strandColorForTheme(_ theme: TQVColorTheme, tone: TQVStrandTone) -> Color {
        switch (theme, tone) {
        case (.ruby, .indigo):      return Color(red: 0.88, green: 0.22, blue: 0.27)
        case (.ruby, .saffron):     return Color(red: 0.94, green: 0.74, blue: 0.16)
        case (.ruby, .jade):        return Color(red: 0.52, green: 0.28, blue: 0.80)
        case (.sapphire, .indigo):  return Color(red: 0.24, green: 0.50, blue: 0.88)
        case (.sapphire, .saffron): return Color(red: 0.10, green: 0.76, blue: 0.68)
        case (.sapphire, .jade):    return Color(red: 0.30, green: 0.82, blue: 0.44)
        case (.onyx, .indigo):      return Color(red: 0.74, green: 0.52, blue: 0.90)
        case (.onyx, .saffron):     return Color(red: 0.90, green: 0.64, blue: 0.22)
        case (.onyx, .jade):        return Color(red: 0.32, green: 0.80, blue: 0.80)
        }
    }

    private func accentForTheme(_ theme: TQVColorTheme) -> Color {
        switch theme {
        case .ruby:     return Color(red: 0.92, green: 0.35, blue: 0.40)
        case .sapphire: return Color(red: 0.30, green: 0.60, blue: 0.95)
        case .onyx:     return Color(red: 0.70, green: 0.55, blue: 0.90)
        }
    }
}
