#if DEBUG
import SwiftUI

struct TQVRehearsalStage: View {
    struct TQVFrameSpec: Identifiable {
        let id: String, w: CGFloat, h: CGFloat
    }
    private static let specs = [
        TQVFrameSpec(id: "SE 375x667",  w: 375, h: 667),
        TQVFrameSpec(id: "Std 393x852", w: 393, h: 852),
        TQVFrameSpec(id: "Max 440x956", w: 440, h: 956)
    ]
    private static let stages = ["Splash", "Home", "Game", "Result", "Settings", "Guide"]

    @State private var spec = 0
    @State private var stage = 1
    @StateObject private var conductor = TQVShuttleConductor()

    var body: some View {
        VStack(spacing: 8) {
            picker(Self.specs.map(\.id), selection: $spec)
            picker(Self.stages, selection: $stage)

            GeometryReader { outer in
                let s = Self.specs[spec]
                let k = min(outer.size.width / s.w, outer.size.height / s.h) * 0.96
                content(for: stage)
                    .frame(width: s.w, height: s.h)
                    .clipped()
                    .border(Color.red.opacity(0.6))
                    .scaleEffect(k, anchor: .center)
                    .frame(width: s.w * k, height: s.h * k)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .padding(8)
        .onAppear {
            conductor.newGame(mode: .tandem, tier: .normal)
        }
    }

    private func picker(_ items: [String], selection: Binding<Int>) -> some View {
        HStack(spacing: 6) {
            ForEach(items.indices, id: \.self) { i in
                Button(items[i]) { selection.wrappedValue = i }
                    .font(.system(size: 11, weight: .semibold))
                    .padding(.horizontal, 8).padding(.vertical, 5)
                    .background(selection.wrappedValue == i ? Color.accentColor : Color.gray.opacity(0.25))
                    .foregroundColor(selection.wrappedValue == i ? .white : .primary)
                    .cornerRadius(6)
            }
        }
    }

    @ViewBuilder private func content(for index: Int) -> some View {
        switch index {
        case 0: TQVUnwindStage(onFinish: {})
        case 1: TQVSpindleStage(conductor: conductor,
                                showMenu: .constant(false),
                                showGuide: .constant(false),
                                onPlay: {}, onResume: {}, onDaily: {})
        case 2: TQVLoomStage(conductor: conductor, onHome: {})
        case 3: TQVTapestryStage(conductor: conductor, onHome: {}, onReplay: {})
        case 4: TQVHeddleStage(isPresented: .constant(true), onClear: {})
        default: TQVBobbinStage(dismiss: {})
        }
    }
}
#endif
