import SwiftUI

struct TQVCelebrationView: View {

    @State private var launched = false

    private let count = 24
    private let tones: [TQVStrandTone] = [.indigo, .saffron, .jade]

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            ForEach(0..<count, id: \.self) { i in
                let tone = tones[i % 3]
                let size = CGFloat(4 + (i % 5))
                let xFrac = xFraction(for: i)
                let yStart = h * 0.55 + CGFloat(i % 6) * h * 0.03
                let yEnd = h * 0.05 + CGFloat(i % 4) * h * 0.06

                Circle()
                    .fill(TQVFiberPalette.strandColor(tone))
                    .frame(width: size, height: size)
                    .opacity(launched ? 0.0 : 0.9)
                    .position(
                        x: w * xFrac,
                        y: launched ? yEnd : yStart
                    )
                    .animation(
                        Animation.easeOut(duration: 1.5)
                            .delay(Double(i) * 0.04),
                        value: launched
                    )
            }
        }
        .allowsHitTesting(false)
        .onAppear { launched = true }
    }

    private func xFraction(for index: Int) -> CGFloat {
        let base: CGFloat = 0.12
        let span: CGFloat = 0.76
        let step = span / CGFloat(count - 1)
        let offset: CGFloat = (index % 2 == 0) ? 0.01 : -0.01
        return base + CGFloat(index) * step + offset
    }
}

// MARK: - Expanding Rings

struct TQVExpandingRings: View {

    @State private var expand = false

    private let ringTones: [TQVStrandTone] = [.indigo, .saffron, .jade]

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            let cx = geo.size.width * 0.5
            let cy = geo.size.height * 0.5

            ForEach(0..<3, id: \.self) { i in
                let tone = ringTones[i]
                let target = side * (0.6 + CGFloat(i) * 0.15)
                let start: CGFloat = side * 0.05

                Circle()
                    .stroke(
                        TQVFiberPalette.strandColor(tone),
                        lineWidth: 2
                    )
                    .frame(
                        width: expand ? target : start,
                        height: expand ? target : start
                    )
                    .opacity(expand ? 0.0 : 0.7)
                    .position(x: cx, y: cy)
                    .animation(
                        Animation.easeOut(duration: 1.2)
                            .delay(Double(i) * 0.15),
                        value: expand
                    )
            }
        }
        .allowsHitTesting(false)
        .onAppear { expand = true }
    }
}
