import SwiftUI

struct TQVStitchGlyph: Shape {
    let tone: TQVStrandTone

    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width, h = rect.height
        func pt(_ x: CGFloat, _ y: CGFloat) -> CGPoint {
            CGPoint(x: rect.minX + x * w, y: rect.minY + y * h)
        }

        switch tone {
        case .saffron:
            // Cross-stitch: two crossing diagonal threads
            p.move(to: pt(0.22, 0.22)); p.addLine(to: pt(0.78, 0.78))
            p.move(to: pt(0.78, 0.22)); p.addLine(to: pt(0.22, 0.78))

        case .indigo:
            // Knot: two interlocked loops
            let r: CGFloat = 0.2
            p.addEllipse(in: CGRect(x: rect.minX + (0.30 - r) * w, y: rect.minY + (0.5 - r) * h,
                                     width: r * 2 * w, height: r * 2 * h))
            p.addEllipse(in: CGRect(x: rect.minX + (0.64 - r) * w, y: rect.minY + (0.5 - r) * h,
                                     width: r * 2 * w, height: r * 2 * h))

        case .jade:
            // Herringbone: stacked chevrons
            for row in 0..<3 {
                let y = 0.24 + CGFloat(row) * 0.24
                p.move(to: pt(0.20, y))
                p.addLine(to: pt(0.5, y + 0.14))
                p.addLine(to: pt(0.80, y))
            }
        }
        return p
    }
}

struct TQVStrandCell: View {
    let tone: TQVStrandTone
    let isTarget: Bool
    let isHinted: Bool
    let isWrong: Bool
    let isMatched: Bool
    let cellSize: CGFloat

    @State private var hintPulse = false

    private var shape: RoundedRectangle {
        RoundedRectangle(cornerRadius: cellSize * 0.3, style: .continuous)
    }

    var body: some View {
        ZStack {
            shape
                .fill(
                    LinearGradient(
                        colors: [TQVFiberPalette.strandColor(tone).opacity(0.95),
                                 TQVFiberPalette.strandColor(tone).opacity(0.7)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    )
                )
                .shadow(color: TQVFiberPalette.strandColor(tone).opacity(isHinted ? 0.65 : 0.3),
                        radius: isHinted ? 10 : 4, y: 2)

            weaveHatch
                .clipShape(shape)

            TQVStitchGlyph(tone: tone)
                .stroke(Color.white.opacity(0.92),
                        style: StrokeStyle(lineWidth: max(1.5, cellSize * 0.075),
                                           lineCap: .round, lineJoin: .round))
                .frame(width: cellSize * 0.56, height: cellSize * 0.56)

            if isHinted {
                shape
                    .stroke(Color.yellow, lineWidth: 3)
                    .scaleEffect(hintPulse ? 1.3 : 1.0)
                    .opacity(hintPulse ? 0 : 0.7)

                shape
                    .stroke(Color.yellow, lineWidth: 2.5)
                    .opacity(0.9)
            }

            if isMatched && !isHinted {
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Image(systemName: "checkmark")
                            .font(.system(size: cellSize * 0.16, weight: .heavy))
                            .foregroundColor(.white)
                            .padding(cellSize * 0.06)
                            .background(
                                Circle()
                                    .fill(Color.green.opacity(0.7))
                                    .frame(width: cellSize * 0.28, height: cellSize * 0.28)
                            )
                    }
                }
                .frame(width: cellSize, height: cellSize)
            }
        }
        .frame(width: cellSize, height: cellSize)
        .scaleEffect(isHinted ? 1.1 : (isWrong ? 0.85 : 1.0))
        .rotationEffect(isWrong ? .degrees(6) : .zero)
        .animation(.spring(response: 0.25, dampingFraction: 0.5), value: isWrong)
        .animation(.easeInOut(duration: 0.3), value: tone)
        .onAppear {
            if isHinted {
                withAnimation(.easeOut(duration: 0.9).repeatForever(autoreverses: false)) {
                    hintPulse = true
                }
            }
        }
        .onChange(of: isHinted) { newVal in
            if newVal {
                hintPulse = false
                DispatchQueue.main.async {
                    withAnimation(.easeOut(duration: 0.9).repeatForever(autoreverses: false)) {
                        hintPulse = true
                    }
                }
            } else {
                withAnimation(.default) { hintPulse = false }
            }
        }
    }

    private var weaveHatch: some View {
        ZStack {
            ForEach(0..<4, id: \.self) { i in
                Rectangle()
                    .fill(Color.white.opacity(0.06))
                    .frame(width: cellSize * 1.6, height: 1)
                    .rotationEffect(.degrees(45))
                    .offset(y: CGFloat(i - 2) * cellSize * 0.22)
            }
        }
    }
}

struct TQVTargetCell: View {
    let tone: TQVStrandTone
    let cellSize: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cellSize * 0.28, style: .continuous)
                .fill(TQVFiberPalette.strandColor(tone).opacity(0.75))

            TQVStitchGlyph(tone: tone)
                .stroke(Color.white.opacity(0.85),
                        style: StrokeStyle(lineWidth: max(1, cellSize * 0.08),
                                           lineCap: .round, lineJoin: .round))
                .frame(width: cellSize * 0.56, height: cellSize * 0.56)
        }
        .frame(width: cellSize, height: cellSize)
    }
}
