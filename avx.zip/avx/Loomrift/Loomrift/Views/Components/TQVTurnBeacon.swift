import SwiftUI

struct TQVTurnBeacon: View {
    let currentSide: TQVLoomSide
    let side: CGFloat

    var body: some View {
        HStack(spacing: side * 0.02) {
            Text("WARP")
                .font(.system(size: side * 0.02, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundColor(currentSide == .warp
                                 ? TQVFiberPalette.accent : .white.opacity(0.22))

            ZStack {
                Capsule()
                    .fill(Color.white.opacity(0.08))
                    .frame(width: side * 0.28, height: side * 0.046)
                HStack {
                    if currentSide == .weft { Spacer() }
                    Circle()
                        .fill(TQVFiberPalette.accent)
                        .frame(width: side * 0.034, height: side * 0.034)
                        .shadow(color: TQVFiberPalette.accent.opacity(0.7), radius: 6)
                        .padding(.horizontal, side * 0.008)
                    if currentSide == .warp { Spacer() }
                }
                .frame(width: side * 0.28)
                .animation(.spring(response: 0.35, dampingFraction: 0.7), value: currentSide)
            }

            Text("WEFT")
                .font(.system(size: side * 0.02, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundColor(currentSide == .weft
                                 ? TQVFiberPalette.accent : .white.opacity(0.22))
        }
        .padding(.vertical, side * 0.008)
    }
}
