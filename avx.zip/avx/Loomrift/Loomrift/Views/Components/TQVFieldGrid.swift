import SwiftUI

struct TQVFieldGrid: View {
    let field: TQVWarpField
    let target: TQVWarpField
    let side: TQVLoomSide
    let isActive: Bool
    let hintedMove: TQVShuttleMove?
    let wrongMove: TQVShuttleMove?
    let gridSide: CGFloat
    let onTap: (Int, Int) -> Void

    private var cellSize: CGFloat {
        let maxDim = max(field.rows, field.cols)
        return (gridSide - CGFloat(maxDim + 1) * spacing) / CGFloat(maxDim)
    }

    private var spacing: CGFloat { gridSide * 0.04 }

    var body: some View {
        VStack(spacing: gridSide * 0.02) {
            Text(side == .warp ? "WARP" : "WEFT")
                .font(.system(size: gridSide * 0.055, weight: .bold, design: .rounded))
                .tracking(1.8)
                .foregroundColor(isActive
                                 ? TQVFiberPalette.accent
                                 : .white.opacity(0.28))

            VStack(spacing: spacing) {
                ForEach(0..<field.rows, id: \.self) { r in
                    HStack(spacing: spacing) {
                        ForEach(0..<field.cols, id: \.self) { c in
                            let isHinted = hintedMove.map {
                                $0.side == side && $0.row == r && $0.col == c
                            } ?? false
                            let isWrong = wrongMove.map {
                                $0.side == side && $0.row == r && $0.col == c
                            } ?? false
                            let isMatched = field[r, c] == target[r, c]

                            TQVStrandCell(
                                tone: field[r, c],
                                isTarget: false,
                                isHinted: isHinted,
                                isWrong: isWrong,
                                isMatched: isMatched,
                                cellSize: cellSize
                            )
                            .onTapGesture { onTap(r, c) }
                        }
                    }
                }
            }
            .padding(spacing * 1.3)
            .background(
                ZStack {
                    TQVGlassPlate(
                        radius: gridSide * 0.1,
                        tint: isActive
                            ? TQVFiberPalette.accent.opacity(0.12)
                            : Color.white.opacity(0.04)
                    )
                    RoundedRectangle(cornerRadius: gridSide * 0.1)
                        .stroke(
                            isActive
                                ? TQVFiberPalette.accent.opacity(0.5)
                                : Color.white.opacity(0.08),
                            lineWidth: isActive ? 1.6 : 1
                        )
                        .shadow(color: isActive ? TQVFiberPalette.accent.opacity(0.35) : .clear,
                                radius: isActive ? 10 : 0)
                }
            )

            Capsule()
                .fill(isActive ? TQVFiberPalette.accent : Color.white.opacity(0.08))
                .frame(width: isActive ? gridSide * 0.28 : gridSide * 0.1, height: 3)
                .animation(.easeInOut(duration: 0.25), value: isActive)
        }
    }
}

struct TQVTargetThumb: View {
    let field: TQVWarpField
    let thumbSide: CGFloat

    private var cellSize: CGFloat {
        let maxDim = max(field.rows, field.cols)
        return (thumbSide - CGFloat(maxDim + 1) * 2) / CGFloat(maxDim)
    }

    var body: some View {
        VStack(spacing: 2) {
            ForEach(0..<field.rows, id: \.self) { r in
                HStack(spacing: 2) {
                    ForEach(0..<field.cols, id: \.self) { c in
                        TQVTargetCell(tone: field[r, c], cellSize: cellSize)
                    }
                }
            }
        }
        .padding(5)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.black.opacity(0.32))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(TQVFiberPalette.accent.opacity(0.22), lineWidth: 1)
                )
        )
        .shadow(color: TQVFiberPalette.accent.opacity(0.18), radius: 6, y: 2)
    }
}
