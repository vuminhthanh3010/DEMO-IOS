import SwiftUI

struct TQVModeCard: View {
    let mode: TQVWeaveMode
    let isSelected: Bool
    let side: CGFloat

    private var icon: String { mode == .tandem ? "square.split.2x1" : "equal.circle" }
    private var name: String { mode == .tandem ? "Tandem" : "Echo" }
    private var desc: String { mode == .tandem ? "Two targets" : "Shared target" }
    private var tone: TQVStrandTone { mode == .tandem ? .indigo : .saffron }

    var body: some View {
        VStack(alignment: .leading, spacing: side * 0.012) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: side * 0.038, weight: .semibold))
                    .foregroundColor(isSelected ? TQVFiberPalette.strandColor(tone) : .white.opacity(0.35))
                Spacer()
                Circle()
                    .fill(isSelected ? TQVFiberPalette.strandColor(tone) : Color.white.opacity(0.12))
                    .frame(width: side * 0.022, height: side * 0.022)
                    .shadow(color: isSelected ? TQVFiberPalette.strandColor(tone).opacity(0.7) : .clear, radius: 4)
            }
            Text(name)
                .font(.system(size: side * 0.036, weight: .bold, design: .rounded))
                .foregroundColor(isSelected ? .white : .white.opacity(0.42))
            Text(desc)
                .font(.system(size: side * 0.022, weight: .medium, design: .rounded))
                .foregroundColor(isSelected ? .white.opacity(0.55) : .white.opacity(0.22))
        }
        .padding(side * 0.028)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            ZStack {
                TQVGlassPlate(
                    radius: side * 0.03,
                    tint: isSelected
                        ? TQVFiberPalette.strandColor(tone).opacity(0.18)
                        : Color.white.opacity(0.04)
                )
                RoundedRectangle(cornerRadius: side * 0.03)
                    .stroke(
                        isSelected
                            ? TQVFiberPalette.strandColor(tone).opacity(0.45)
                            : Color.white.opacity(0.08),
                        lineWidth: isSelected ? 1.4 : 1
                    )
            }
        )
        .rotationEffect(.degrees(mode == .tandem ? -1.4 : 1.4))
        .offset(y: isSelected ? -3 : 4)
        .animation(.spring(response: 0.35, dampingFraction: 0.78), value: isSelected)
    }
}
