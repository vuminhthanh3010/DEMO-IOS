import SwiftUI

struct TQVSpindleStage: View {
    @ObservedObject var conductor: TQVShuttleConductor
    @Binding var showMenu: Bool
    @Binding var showGuide: Bool
    let onPlay: () -> Void
    let onResume: () -> Void
    let onDaily: () -> Void
    @State private var heroPulse = false

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                TQVWovenBackdrop(tone: .spindle)

                VStack(spacing: 0) {
                    header(side: side)
                    TQVThreadBar(side: side)
                        .padding(.top, side * 0.018)

                    ScrollView(showsIndicators: false) {
                        VStack(spacing: side * 0.026) {
                            dailyBanner(side: side)
                            modeRow(side: side)
                            tierRow(side: side)
                            statsStrip(side: side)
                            personalBest(side: side)
                            heroPreview(side: side)
                        }
                        .padding(.horizontal, side * 0.06)
                        .padding(.top, side * 0.026)
                        .padding(.bottom, side * 0.03)
                    }

                    actionStack(side: side)
                        .padding(.horizontal, side * 0.06)
                        .padding(.top, side * 0.016)
                        .padding(.bottom, max(geo.safeAreaInsets.bottom, side * 0.03))
                        .background(
                            LinearGradient(
                                colors: [Color.black.opacity(0), Color.black.opacity(0.22)],
                                startPoint: .top, endPoint: .bottom
                            )
                            .ignoresSafeArea(edges: .bottom)
                        )
                }
            }
        }
    }

    // MARK: - Header

    private func header(side: CGFloat) -> some View {
        HStack(spacing: side * 0.028) {
            TQVLoomMark(size: side * 0.15)

            VStack(alignment: .leading, spacing: 2) {
                Text("Loomrift")
                    .font(.system(size: side * 0.05, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text("Dual-Grid Logic")
                    .font(.system(size: side * 0.024, weight: .medium, design: .rounded))
                    .foregroundColor(TQVFiberPalette.accent.opacity(0.65))
            }

            Spacer()

            HStack(spacing: side * 0.02) {
                Button(action: { showGuide = true }) {
                    TQVFacetButton(icon: "book.closed.fill", size: side * 0.1)
                }
                Button(action: { withAnimation(.spring()) { showMenu = true } }) {
                    TQVFacetButton(icon: "gearshape.fill", size: side * 0.1)
                }
            }
        }
        .padding(.horizontal, side * 0.06)
        .padding(.top, side * 0.05)
    }

    // MARK: - Daily Banner

    private func dailyBanner(side: CGFloat) -> some View {
        let done = !conductor.isDailyAvailable
        return Button(action: {
            guard !done else { return }
            conductor.newDailyGame()
            onDaily()
        }) {
            HStack(spacing: side * 0.022) {
                Image(systemName: done ? "checkmark.circle.fill" : "sun.max.fill")
                    .font(.system(size: side * 0.036, weight: .semibold))
                    .foregroundColor(done ? Color.green.opacity(0.85) : TQVFiberPalette.accentSecondary)

                VStack(alignment: .leading, spacing: 1) {
                    Text("Daily Challenge")
                        .font(.system(size: side * 0.03, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    Text(done ? "Completed today" :
                            "\(TQVShuttleForge.dailyMode.rawValue.capitalized) \u{00B7} Normal")
                        .font(.system(size: side * 0.021, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.4))
                }

                Spacer()

                if !done {
                    Image(systemName: "chevron.right")
                        .font(.system(size: side * 0.024, weight: .semibold))
                        .foregroundColor(TQVFiberPalette.accentSecondary.opacity(0.6))
                }
            }
            .padding(.horizontal, side * 0.032)
            .padding(.vertical, side * 0.022)
            .background(
                TQVGlassPlate(
                    radius: side * 0.026,
                    tint: done ? Color.green.opacity(0.06) : TQVFiberPalette.accentSecondary.opacity(0.1)
                )
            )
        }
        .disabled(done)
    }

    // MARK: - Mode

    private func modeRow(side: CGFloat) -> some View {
        HStack(spacing: side * 0.03) {
            ForEach(TQVWeaveMode.allCases, id: \.self) { mode in
                TQVModeCard(mode: mode, isSelected: conductor.selectedMode == mode, side: side)
                    .onTapGesture {
                        withAnimation(.easeInOut) { conductor.selectedMode = mode }
                        TQVLoomHaptics.selection()
                    }
            }
        }
        .padding(.top, side * 0.008)
    }

    // MARK: - Tier

    private func tierRow(side: CGFloat) -> some View {
        HStack(spacing: side * 0.012) {
            ForEach(TQVWeaveTier.allCases, id: \.self) { tier in
                let sel = conductor.selectedTier == tier
                VStack(spacing: 2) {
                    Text(tier.rawValue.capitalized)
                        .font(.system(size: side * 0.028, weight: sel ? .bold : .medium, design: .rounded))
                    Text("\(tier.gridRows)\u{00D7}\(tier.gridCols)")
                        .font(.system(size: side * 0.019, weight: .medium, design: .rounded))
                        .foregroundColor(sel ? .white.opacity(0.5) : .white.opacity(0.18))
                }
                .foregroundColor(sel ? .white : .white.opacity(0.35))
                .frame(maxWidth: .infinity)
                .padding(.vertical, side * 0.016)
                .background(
                    RoundedRectangle(cornerRadius: side * 0.018)
                        .fill(sel ? TQVFiberPalette.accent.opacity(0.28) : Color.white.opacity(0.05))
                )
                .onTapGesture {
                    withAnimation(.easeInOut) { conductor.selectedTier = tier }
                    TQVLoomHaptics.selection()
                }
            }
        }
    }

    // MARK: - Stats

    private func statsStrip(side: CGFloat) -> some View {
        HStack(spacing: 0) {
            stripItem(value: "\(conductor.ledger.totalWon)", label: "Won", side: side)
            stripDiv(side: side)
            stripItem(value: String(format: "%.0f%%", conductor.ledger.winRate), label: "Rate", side: side)
            stripDiv(side: side)
            stripItem(value: "\(conductor.ledger.currentStreak)", label: "Streak", side: side)
            stripDiv(side: side)
            stripItem(value: "\(conductor.ledger.bestStreak)", label: "Best", side: side)
        }
        .padding(.vertical, side * 0.018)
        .background(TQVGlassPlate(radius: side * 0.022, tint: Color.white.opacity(0.04)))
    }

    private func stripItem(value: String, label: String, side: CGFloat) -> some View {
        VStack(spacing: 1) {
            Text(value)
                .font(.system(size: side * 0.036, weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(label)
                .font(.system(size: side * 0.019, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.3))
        }
        .frame(maxWidth: .infinity)
    }

    private func stripDiv(side: CGFloat) -> some View {
        Rectangle()
            .fill(Color.white.opacity(0.08))
            .frame(width: 1, height: side * 0.045)
    }

    // MARK: - Personal Best

    private func personalBest(side: CGFloat) -> some View {
        let bm = conductor.currentBestMoves
        let bt = conductor.currentBestTime

        return Group {
            if bm != nil || bt != nil {
                HStack(spacing: side * 0.016) {
                    Image(systemName: "crown.fill")
                        .font(.system(size: side * 0.024))
                        .foregroundColor(TQVFiberPalette.accentSecondary)
                    if let m = bm {
                        Text("\(m) moves")
                            .font(.system(size: side * 0.026, weight: .bold, design: .rounded))
                            .foregroundColor(.white.opacity(0.6))
                    }
                    if let t = bt {
                        Text(fmt(t))
                            .font(.system(size: side * 0.026, weight: .bold, design: .rounded))
                            .foregroundColor(.white.opacity(0.6))
                    }
                    Spacer()
                    Text("\(conductor.selectedMode.rawValue.capitalized) \u{00B7} \(conductor.selectedTier.rawValue.capitalized)")
                        .font(.system(size: side * 0.019, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.22))
                }
            }
        }
    }

    // MARK: - Hero Preview

    private func heroPreview(side: CGFloat) -> some View {
        let warpTones: [TQVStrandTone] = [.indigo, .saffron, .jade, .saffron, .indigo, .jade]
        let weftTones: [TQVStrandTone] = [.jade, .indigo, .saffron, .indigo, .jade, .saffron]

        return VStack(spacing: side * 0.024) {
            Text("HOW IT WORKS")
                .font(.system(size: side * 0.02, weight: .bold, design: .rounded))
                .tracking(1.8)
                .foregroundColor(.white.opacity(0.26))

            HStack(spacing: side * 0.04) {
                heroGrid(tones: warpTones, label: "WARP", accent: TQVFiberPalette.accent, side: side)

                Image(systemName: "arrow.left.arrow.right")
                    .font(.system(size: side * 0.05, weight: .semibold))
                    .foregroundColor(TQVFiberPalette.accentSecondary.opacity(0.85))
                    .rotationEffect(.degrees(heroPulse ? 8 : -8))
                    .animation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true), value: heroPulse)

                heroGrid(tones: weftTones, label: "WEFT", accent: TQVFiberPalette.accentSecondary, side: side)
            }

            Text("Every tap advances one grid and reverses its twin cell")
                .font(.system(size: side * 0.021, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.32))
                .multilineTextAlignment(.center)
                .padding(.horizontal, side * 0.06)
        }
        .padding(.vertical, side * 0.032)
        .frame(maxWidth: .infinity)
        .background(TQVGlassPlate(radius: side * 0.03, tint: Color.white.opacity(0.03)))
        .onAppear { heroPulse = true }
    }

    private func heroGrid(tones: [TQVStrandTone], label: String, accent: Color, side: CGFloat) -> some View {
        let cell = side * 0.052
        return VStack(spacing: side * 0.01) {
            VStack(spacing: 3) {
                ForEach(0..<2, id: \.self) { r in
                    HStack(spacing: 3) {
                        ForEach(0..<3, id: \.self) { c in
                            RoundedRectangle(cornerRadius: cell * 0.28)
                                .fill(TQVFiberPalette.strandColor(tones[r * 3 + c]).opacity(0.85))
                                .frame(width: cell, height: cell)
                        }
                    }
                }
            }
            .padding(side * 0.018)
            .background(
                RoundedRectangle(cornerRadius: side * 0.02)
                    .fill(Color.black.opacity(0.28))
                    .overlay(
                        RoundedRectangle(cornerRadius: side * 0.02)
                            .stroke(accent.opacity(0.3), lineWidth: 1)
                    )
            )
            Text(label)
                .font(.system(size: side * 0.018, weight: .bold, design: .rounded))
                .tracking(1.2)
                .foregroundColor(accent.opacity(0.6))
        }
    }

    // MARK: - Actions

    private func actionStack(side: CGFloat) -> some View {
        VStack(spacing: side * 0.014) {
            if conductor.hasSavedGame {
                Button(action: onResume) {
                    TQVGhostCTA(title: "Continue", icon: "play.fill", side: side)
                }
            }
            Button(action: onPlay) {
                TQVWeaveCTA(title: "New Puzzle", icon: "plus.circle.fill", side: side)
            }
        }
    }

    private func fmt(_ t: Double) -> String {
        let m = Int(t) / 60; let s = Int(t) % 60
        return String(format: "%d:%02d", m, s)
    }
}
