import SwiftUI

struct TQVBobbinStage: View {
    let dismiss: () -> Void

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                TQVWovenBackdrop(tone: .bobbin)

                VStack(spacing: 0) {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("How to weave")
                                .font(.system(size: side * 0.042, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            Text("Swipe through the warp")
                                .font(.system(size: side * 0.022, weight: .medium, design: .rounded))
                                .foregroundColor(.white.opacity(0.4))
                        }
                        Spacer()
                        Button(action: dismiss) {
                            TQVFacetButton(icon: "xmark", size: side * 0.1)
                        }
                    }
                    .padding(.horizontal, side * 0.05)
                    .padding(.top, side * 0.03)

                    TabView {
                        pageCard(side: side,
                                 title: "Two grids",
                                 body: "Warp on the left, weft on the right. Both must match their goals at the same time.",
                                 visual: AnyView(dualMini(side: side)))
                        pageCard(side: side,
                                 title: "Every tap trades",
                                 body: "Advance a cell on one grid and the twin cell on the other grid steps backward.",
                                 visual: AnyView(tradeVisual(side: side)))
                        pageCard(side: side,
                                 title: "Alternate sides",
                                 body: "Tap warp, then weft, then warp again. The shuttle marker shows whose turn it is.",
                                 visual: AnyView(shuttleVisual(side: side)))
                        pageCard(side: side,
                                 title: "Lock both goals",
                                 body: "Win when both boards match together. Fewer moves earn a brighter star rating.",
                                 visual: AnyView(lockVisual(side: side)))
                        pageFive(side: side)
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                    .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                }
            }
        }
    }

    private func pageCard(side: CGFloat, title: String, body: String, visual: AnyView) -> some View {
        VStack(spacing: side * 0.03) {
            Spacer()
            visual
            Text(title)
                .font(.system(size: TQVFiberPalette.fontSize(.title, side: side),
                              weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
            Text(body)
                .font(.system(size: TQVFiberPalette.fontSize(.body, side: side),
                              weight: .regular, design: .rounded))
                .foregroundColor(.white.opacity(0.68))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, side * 0.06)
            Spacer()
            Spacer()
        }
        .padding(.horizontal, side * 0.04)
    }

    private func dualMini(side: CGFloat) -> some View {
        HStack(spacing: side * 0.04) {
            miniGrid([.indigo, .saffron, .jade, .saffron], "Warp", side)
            Image(systemName: "arrow.left.arrow.right")
                .font(.system(size: side * 0.04, weight: .semibold))
                .foregroundColor(TQVFiberPalette.accent.opacity(0.7))
            miniGrid([.jade, .indigo, .saffron, .jade], "Weft", side)
        }
    }

    private func tradeVisual(side: CGFloat) -> some View {
        HStack(spacing: side * 0.08) {
            VStack(spacing: 8) {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: side * 0.08))
                    .foregroundColor(TQVFiberPalette.accent)
                Text("Forward")
                    .font(.system(size: side * 0.024, weight: .semibold, design: .rounded))
                    .foregroundColor(.white.opacity(0.55))
            }
            VStack(spacing: 8) {
                Image(systemName: "arrow.down.circle.fill")
                    .font(.system(size: side * 0.08))
                    .foregroundColor(TQVFiberPalette.accentSecondary)
                Text("Reverse")
                    .font(.system(size: side * 0.024, weight: .semibold, design: .rounded))
                    .foregroundColor(.white.opacity(0.55))
            }
        }
        .padding(side * 0.03)
        .background(TQVGlassPlate(radius: side * 0.03, tint: Color.white.opacity(0.05)))
    }

    private func shuttleVisual(side: CGFloat) -> some View {
        TQVTurnBeacon(currentSide: .warp, side: side * 1.2)
            .padding(side * 0.03)
            .background(TQVGlassPlate(radius: side * 0.03, tint: Color.white.opacity(0.05)))
    }

    private func lockVisual(side: CGFloat) -> some View {
        HStack(spacing: side * 0.06) {
            check("Warp", side)
            check("Weft", side)
        }
    }

    private func pageFive(side: CGFloat) -> some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: side * 0.022) {
                Text("Modes & tips")
                    .font(.system(size: TQVFiberPalette.fontSize(.title, side: side),
                                  weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .padding(.top, side * 0.02)

                modeRow("square.split.2x1.fill", "Tandem",
                        "Each grid has its own target.", TQVFiberPalette.strandColor(.indigo), side)
                modeRow("equal.circle.fill", "Echo",
                        "Both grids share one target.", TQVFiberPalette.strandColor(.saffron), side)

                VStack(alignment: .leading, spacing: side * 0.014) {
                    tip("Undo is free — experiment.", side)
                    tip("Hints show the next correct tap.", side)
                    tip("Stay near the optimal move count.", side)
                    tip("Watch both boards after every tap.", side)
                }
                .padding(side * 0.022)
                .background(TQVGlassPlate(radius: side * 0.028, tint: Color.white.opacity(0.05)))
                .padding(.horizontal, side * 0.04)

                Spacer().frame(height: side * 0.08)
            }
        }
    }

    private func miniGrid(_ tones: [TQVStrandTone], _ label: String, _ side: CGFloat) -> some View {
        let cs = side * 0.05
        return VStack(spacing: 6) {
            Text(label.uppercased())
                .font(.system(size: side * 0.018, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundColor(.white.opacity(0.4))
            VStack(spacing: 5) {
                HStack(spacing: 5) {
                    Circle().fill(TQVFiberPalette.strandColor(tones[0])).frame(width: cs, height: cs)
                    Circle().fill(TQVFiberPalette.strandColor(tones[1])).frame(width: cs, height: cs)
                }
                HStack(spacing: 5) {
                    Circle().fill(TQVFiberPalette.strandColor(tones[2])).frame(width: cs, height: cs)
                    Circle().fill(TQVFiberPalette.strandColor(tones[3])).frame(width: cs, height: cs)
                }
            }
            .padding(side * 0.02)
            .background(TQVGlassPlate(radius: side * 0.022, tint: Color.white.opacity(0.05)))
        }
    }

    private func check(_ label: String, _ side: CGFloat) -> some View {
        VStack(spacing: 8) {
            ZStack {
                Circle()
                    .fill(TQVFiberPalette.accentSecondary.opacity(0.18))
                    .frame(width: side * 0.1, height: side * 0.1)
                Image(systemName: "checkmark")
                    .font(.system(size: side * 0.038, weight: .bold))
                    .foregroundColor(TQVFiberPalette.accentSecondary)
            }
            Text(label)
                .font(.system(size: side * 0.024, weight: .semibold, design: .rounded))
                .foregroundColor(.white.opacity(0.5))
        }
    }

    private func modeRow(_ icon: String, _ name: String, _ detail: String,
                         _ color: Color, _ side: CGFloat) -> some View {
        HStack(spacing: side * 0.022) {
            ZStack {
                RoundedRectangle(cornerRadius: side * 0.02)
                    .fill(color.opacity(0.2))
                    .frame(width: side * 0.09, height: side * 0.09)
                Image(systemName: icon)
                    .font(.system(size: side * 0.036, weight: .semibold))
                    .foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(name)
                    .font(.system(size: TQVFiberPalette.fontSize(.body, side: side),
                                  weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text(detail)
                    .font(.system(size: TQVFiberPalette.fontSize(.caption, side: side),
                                  weight: .regular, design: .rounded))
                    .foregroundColor(.white.opacity(0.55))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
        }
        .padding(side * 0.02)
        .background(TQVGlassPlate(radius: side * 0.022, tint: Color.white.opacity(0.05)))
        .padding(.horizontal, side * 0.04)
    }

    private func tip(_ text: String, _ side: CGFloat) -> some View {
        HStack(alignment: .top, spacing: side * 0.014) {
            Circle()
                .fill(TQVFiberPalette.accentSecondary)
                .frame(width: 6, height: 6)
                .padding(.top, 5)
            Text(text)
                .font(.system(size: TQVFiberPalette.fontSize(.caption, side: side),
                              weight: .regular, design: .rounded))
                .foregroundColor(.white.opacity(0.68))
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
