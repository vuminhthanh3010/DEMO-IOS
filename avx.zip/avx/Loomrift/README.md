# Loomrift

A dual-grid logic puzzle for iOS where every move is a trade-off: advancing one grid pushes the other backward.

## How It Works

Two small grids sit side by side. Each cell is a circle holding one of three states — Star, Square, or Bolt — shown in distinct colors. Tapping a cell on one grid cycles it forward, but the corresponding cell on the opposite grid cycles in reverse. Players must alternate taps between the two grids and bring both to match their target patterns simultaneously.

## Game Modes

- **Tandem** — each grid has a distinct target pattern.
- **Echo** — both grids share the same target, requiring a different strategy since the inverse coupling fights convergence.

## Difficulty Levels

| Level | Grid | Solution Length |
|-------|------|----------------|
| Easy | 2×3 | 4–6 moves |
| Normal | 3×3 | 8–12 moves |
| Hard | 3×4 | 14–20 moves |

## Features

Unlimited undo, limited hints (3/2/1 by tier), pause, move counter, timer, stats tracking, six achievements, three color themes (Ruby / Sapphire / Onyx), haptic feedback, share results, and rate prompt.

## Project Structure

```
Loomrift/
├── Models/          Pure game logic, no UI imports
├── ViewModels/      ObservableObject bridging logic and views
├── Views/           SwiftUI screens and components
├── Systems/         Theme, haptics, persistence, share, rate
├── tools/           Icon generator and test harness (not compiled into app)
```

## Build Requirements

- Xcode 16+ with iOS Simulator
- Minimum deployment target: iOS 14.0
- No external dependencies
- iPhone only, portrait orientation

```bash
scripts/build-run.sh Loomrift
```
