# Hướng dẫn chơi Loomrift

## Giới thiệu

Loomrift là game giải đố logic dạng lưới kép. Bạn có hai bảng nhỏ nằm cạnh nhau — bảng trái và bảng phải. Mục tiêu: làm cho cả hai bảng đồng thời khớp với hình mẫu đích.

## Luật chơi cơ bản

### Bước 1 — Nhìn hai bảng
Mỗi ô trên bảng là một hình tròn chứa một trong ba ký hiệu:
- **Ngôi sao** (Star — màu đỏ)
- **Vuông** (Square — màu tím)
- **Tia sét** (Bolt — màu vàng)

Phía trên mỗi bảng có hình mẫu đích (nhỏ) — đó là trạng thái bạn cần đạt được.

### Bước 2 — Chạm để đổi
Chạm vào một ô trên bảng trái → ô đó tiến 1 bước (Star → Square → Bolt → Star…).
Nhưng ô tương ứng bên bảng phải sẽ **lùi 1 bước** (ngược chiều).

Tương tự, chạm ô trên bảng phải → ô đó tiến, ô bên trái lùi.

### Bước 3 — Luân phiên
Bạn **bắt buộc** phải chạm xen kẽ: một lần bảng trái, rồi một lần bảng phải, rồi trái, rồi phải… Bảng nào đang đến lượt sẽ có viền sáng.

### Bước 4 — Thắng
Khi cả hai bảng cùng lúc khớp với hình mẫu đích → bạn thắng!

## Chế độ chơi

### Tandem
Hai bảng có hình mẫu đích **khác nhau**. Đây là chế độ tiêu chuẩn.

### Echo
Hai bảng phải kết thúc ở **cùng một hình mẫu**. Chiến thuật hoàn toàn khác vì cơ chế nghịch đảo liên tục đẩy hai bảng ra xa nhau.

## Độ khó

| Mức | Kích thước lưới | Số nước tối ưu |
|-----|----------------|----------------|
| Easy | 2×3 (6 ô/bảng) | 4–6 nước |
| Normal | 3×3 (9 ô/bảng) | 8–12 nước |
| Hard | 3×4 (12 ô/bảng) | 14–20 nước |

## Các nút trong màn chơi

- **Undo** (mũi tên quay lại): Hoàn tác nước đi gần nhất. Dùng bao nhiêu lần cũng được.
- **Hint** (bóng đèn): Gợi ý nước đi đúng tiếp theo. Có giới hạn: Easy 3 lần, Normal 2 lần, Hard 1 lần.
- **New** (mũi tên xoay): Tạo bàn chơi mới cùng chế độ và độ khó hiện tại.
- **Pause** (dừng): Tạm dừng, che bàn chơi. Đồng hồ dừng.

## Cách tính điểm

Trò chơi ghi nhận:
- **Số nước đi** bạn dùng so với số nước tối ưu (hiển thị trên màn hình).
- **Thời gian** hoàn thành.
- **Chuỗi thắng liên tiếp** (streak).
- **Kỷ lục** nước đi ít nhất và thời gian nhanh nhất cho mỗi tổ hợp chế độ × độ khó.

## Thành tựu

| Thành tựu | Điều kiện |
|-----------|-----------|
| First Win | Thắng 1 ván |
| Apprentice | Thắng 5 ván |
| Artisan | Thắng 20 ván |
| Perfect Path | Thắng bằng đúng số nước tối ưu |
| Unaided | Thắng mà không dùng hint |
| All Tiers | Thắng cả 3 độ khó trong một chế độ |

## Cài đặt

Mở menu (nút bánh răng góc trên phải ở màn Home):
- **Haptic Feedback**: Bật/tắt rung phản hồi khi chạm.
- **Show Hints**: Bật/tắt nút gợi ý trong màn chơi.
- **Default Tier**: Chọn độ khó mặc định khi bắt đầu ván mới.
- **Color Theme**: Chọn bảng màu (Ruby / Sapphire / Onyx).
- **Clear Progress**: Xoá toàn bộ thống kê và thành tựu (có xác nhận trước khi xoá).

## Mẹo chơi

1. Bắt đầu với Easy để quen cơ chế nghịch đảo.
2. Nhìn cả hai bảng cùng lúc, đừng chỉ tập trung vào một bên.
3. Dùng Undo thoải mái để thử nghiệm — không bị phạt.
4. Nếu bí, dùng Hint để thấy hướng đi, rồi tự suy tiếp.
5. Số nước tối ưu cho biết bài có thể giải ngắn đến đâu — cố gắng tiệm cận!
