import Foundation

@main
struct Harness {
    static func main() {
        var runs = 0, solvable = 0, replayFailed = 0
        var moveCounts: [Int] = []

        for mode in TQVWeaveMode.allCases {
            for tier in TQVWeaveTier.allCases {
                for seed in 1...200 {
                    let puzzle = TQVShuttleForge.compose(
                        mode: mode, tier: tier, seed: UInt64(seed)
                    )
                    runs += 1

                    guard let path = TQVWeaveOracle.solve(puzzle) else {
                        print("UNSOLVABLE mode=\(mode) tier=\(tier) seed=\(seed)")
                        continue
                    }
                    solvable += 1
                    moveCounts.append(path.count)

                    var board = puzzle.board
                    for move in path {
                        board.apply(move)
                    }
                    if !board.isComplete(
                        warpTarget: puzzle.warpTarget,
                        weftTarget: puzzle.weftTarget
                    ) {
                        replayFailed += 1
                        print("REPLAY MISMATCH mode=\(mode) tier=\(tier) seed=\(seed)")
                    }
                }
            }
        }

        let lo = moveCounts.min() ?? 0
        let hi = moveCounts.max() ?? 0
        let avg = moveCounts.isEmpty ? 0 : moveCounts.reduce(0, +) / moveCounts.count
        print("runs=\(runs) solvable=\(solvable) replayFailed=\(replayFailed)")
        print("moves min=\(lo) avg=\(avg) max=\(hi)")

        guard solvable == runs, replayFailed == 0 else {
            print("HARNESS FAIL")
            exit(1)
        }
        print("HARNESS PASS")
    }
}
