import AppKit
import CoreGraphics
import Foundation

let size = 1024
let outputPath = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "/tmp/icon.png"

let cs = CGColorSpaceCreateDeviceRGB()
guard let ctx = CGContext(data: nil, width: size, height: size,
                          bitsPerComponent: 8, bytesPerRow: size * 4,
                          space: cs,
                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
    print("Failed to create context"); exit(1)
}

let s = CGFloat(size)

// Deep rich background gradient: dark indigo to near-black
let bgColors: [CGFloat] = [
    0.12, 0.06, 0.22, 1.0,
    0.05, 0.03, 0.12, 1.0
]
let bgGrad = CGGradient(colorSpace: cs, colorComponents: bgColors,
                         locations: [0, 1], count: 2)!
ctx.drawLinearGradient(bgGrad, start: CGPoint(x: 0, y: s),
                       end: CGPoint(x: s, y: 0), options: [])

// Warm radial glow behind the grids
let warmGlow: [CGFloat] = [
    0.85, 0.30, 0.35, 0.12,
    0.85, 0.30, 0.35, 0.0
]
let warmGlowGrad = CGGradient(colorSpace: cs, colorComponents: warmGlow,
                               locations: [0, 1], count: 2)!
ctx.drawRadialGradient(warmGlowGrad,
                       startCenter: CGPoint(x: s * 0.35, y: s * 0.5),
                       startRadius: 0,
                       endCenter: CGPoint(x: s * 0.35, y: s * 0.5),
                       endRadius: s * 0.38, options: [])

// Cool radial glow
let coolGlow: [CGFloat] = [
    0.25, 0.50, 0.90, 0.10,
    0.25, 0.50, 0.90, 0.0
]
let coolGlowGrad = CGGradient(colorSpace: cs, colorComponents: coolGlow,
                               locations: [0, 1], count: 2)!
ctx.drawRadialGradient(coolGlowGrad,
                       startCenter: CGPoint(x: s * 0.65, y: s * 0.5),
                       startRadius: 0,
                       endCenter: CGPoint(x: s * 0.65, y: s * 0.5),
                       endRadius: s * 0.38, options: [])

// --- Helper: draw a rounded rect cell with gradient fill ---
func drawGradientCell(x: CGFloat, y: CGFloat, w: CGFloat, h: CGFloat,
                      corner: CGFloat, topColor: [CGFloat], botColor: [CGFloat]) {
    let rect = CGRect(x: x, y: y, width: w, height: h)
    let path = CGPath(roundedRect: rect, cornerWidth: corner, cornerHeight: corner, transform: nil)

    ctx.saveGState()
    ctx.addPath(path)
    ctx.clip()

    let colors = topColor + botColor
    let grad = CGGradient(colorSpace: cs, colorComponents: colors,
                           locations: [0, 1], count: 2)!
    ctx.drawLinearGradient(grad,
                           start: CGPoint(x: x, y: y + h),
                           end: CGPoint(x: x + w, y: y),
                           options: [])
    ctx.restoreGState()

    // Border
    ctx.saveGState()
    ctx.setStrokeColor(CGColor(colorSpace: cs, components: [1, 1, 1, 0.15])!)
    ctx.setLineWidth(s * 0.003)
    ctx.addPath(path)
    ctx.strokePath()
    ctx.restoreGState()
}

// --- Helper: draw a filled circle ---
func drawFilledCircle(cx: CGFloat, cy: CGFloat, r: CGFloat, color: [CGFloat]) {
    ctx.saveGState()
    ctx.setFillColor(CGColor(colorSpace: cs, components: color)!)
    ctx.fillEllipse(in: CGRect(x: cx - r, y: cy - r, width: r * 2, height: r * 2))
    ctx.restoreGState()
}

// --- Grid parameters ---
let gridW = s * 0.34
let gridH = s * 0.42
let gridY = s * 0.28
let leftGridX = s * 0.08
let rightGridX = s * 0.58
let gridCorner = s * 0.04

// Grid backing panels with subtle glass effect
func drawGridPanel(x: CGFloat) {
    ctx.saveGState()
    let panelRect = CGRect(x: x - s * 0.02, y: gridY - s * 0.02,
                           width: gridW + s * 0.04, height: gridH + s * 0.04)
    let panelPath = CGPath(roundedRect: panelRect,
                           cornerWidth: gridCorner + s * 0.01,
                           cornerHeight: gridCorner + s * 0.01,
                           transform: nil)
    ctx.setShadow(offset: CGSize(width: 0, height: s * 0.01), blur: s * 0.04,
                  color: CGColor(colorSpace: cs, components: [0, 0, 0, 0.5])!)
    ctx.setFillColor(CGColor(colorSpace: cs, components: [1, 1, 1, 0.06])!)
    ctx.addPath(panelPath)
    ctx.fillPath()
    ctx.restoreGState()

    ctx.setStrokeColor(CGColor(colorSpace: cs, components: [1, 1, 1, 0.10])!)
    ctx.setLineWidth(s * 0.002)
    ctx.addPath(panelPath)
    ctx.strokePath()
}

drawGridPanel(x: leftGridX)
drawGridPanel(x: rightGridX)

// --- Strand colors (Ruby theme) ---
let indigo: [CGFloat]  = [0.88, 0.22, 0.27, 1.0]   // red
let indigoB: [CGFloat] = [0.72, 0.16, 0.22, 1.0]
let saffron: [CGFloat]  = [0.94, 0.74, 0.16, 1.0]   // gold
let saffronB: [CGFloat] = [0.80, 0.58, 0.10, 1.0]
let jade: [CGFloat]     = [0.52, 0.28, 0.80, 1.0]   // purple
let jadeB: [CGFloat]    = [0.40, 0.20, 0.65, 1.0]

// --- Draw 3x3 grid of cells ---
func drawGrid(originX: CGFloat, tones: [[Int]]) {
    let rows = tones.count
    let cols = tones[0].count
    let cellGap = s * 0.015
    let cellW = (gridW - cellGap * CGFloat(cols + 1)) / CGFloat(cols)
    let cellH = (gridH - cellGap * CGFloat(rows + 1)) / CGFloat(rows)
    let cellCorner = s * 0.018

    for r in 0..<rows {
        for c in 0..<cols {
            let cx = originX + cellGap + CGFloat(c) * (cellW + cellGap)
            let cy = gridY + cellGap + CGFloat(r) * (cellH + cellGap)
            let tone = tones[r][c]

            let top: [CGFloat]
            let bot: [CGFloat]
            switch tone {
            case 0: top = indigo; bot = indigoB
            case 1: top = saffron; bot = saffronB
            default: top = jade; bot = jadeB
            }

            drawGradientCell(x: cx, y: cy, w: cellW, h: cellH,
                             corner: cellCorner, topColor: top, botColor: bot)

            // Inner symbol: small geometric shape
            let symCx = cx + cellW / 2
            let symCy = cy + cellH / 2
            let symR = min(cellW, cellH) * 0.22

            ctx.saveGState()
            ctx.setFillColor(CGColor(colorSpace: cs, components: [1, 1, 1, 0.85])!)

            switch tone {
            case 0: // Diamond
                let diamond = CGMutablePath()
                diamond.move(to: CGPoint(x: symCx, y: symCy - symR))
                diamond.addLine(to: CGPoint(x: symCx + symR * 0.75, y: symCy))
                diamond.addLine(to: CGPoint(x: symCx, y: symCy + symR))
                diamond.addLine(to: CGPoint(x: symCx - symR * 0.75, y: symCy))
                diamond.closeSubpath()
                ctx.addPath(diamond)
                ctx.fillPath()
            case 1: // Circle
                ctx.fillEllipse(in: CGRect(x: symCx - symR * 0.65, y: symCy - symR * 0.65,
                                           width: symR * 1.3, height: symR * 1.3))
            default: // Triangle
                let tri = CGMutablePath()
                tri.move(to: CGPoint(x: symCx, y: symCy - symR))
                tri.addLine(to: CGPoint(x: symCx + symR * 0.85, y: symCy + symR * 0.7))
                tri.addLine(to: CGPoint(x: symCx - symR * 0.85, y: symCy + symR * 0.7))
                tri.closeSubpath()
                ctx.addPath(tri)
                ctx.fillPath()
            }
            ctx.restoreGState()
        }
    }
}

// Left grid: mixed pattern
drawGrid(originX: leftGridX, tones: [
    [0, 1, 2],
    [1, 2, 0],
    [2, 0, 1]
])

// Right grid: inverse pattern
drawGrid(originX: rightGridX, tones: [
    [2, 0, 1],
    [0, 1, 2],
    [1, 2, 0]
])

// --- Coupling connection between grids ---
let linkY = s * 0.5
let linkLeft = leftGridX + gridW + s * 0.01
let linkRight = rightGridX - s * 0.01

// Glowing connection line
ctx.saveGState()
let lineColors: [CGFloat] = [
    0.92, 0.35, 0.40, 0.6,
    0.94, 0.68, 0.20, 0.6
]
let lineGrad = CGGradient(colorSpace: cs, colorComponents: lineColors,
                           locations: [0, 1], count: 2)!
ctx.setLineWidth(s * 0.006)
ctx.setShadow(offset: .zero, blur: s * 0.015,
              color: CGColor(colorSpace: cs, components: [0.92, 0.45, 0.35, 0.5])!)

let linePath = CGMutablePath()
linePath.move(to: CGPoint(x: linkLeft, y: linkY - s * 0.02))
linePath.addLine(to: CGPoint(x: linkRight, y: linkY - s * 0.02))
ctx.addPath(linePath)

let linePath2 = CGMutablePath()
linePath2.move(to: CGPoint(x: linkLeft, y: linkY + s * 0.02))
linePath2.addLine(to: CGPoint(x: linkRight, y: linkY + s * 0.02))
ctx.addPath(linePath2)

ctx.setStrokeColor(CGColor(colorSpace: cs, components: [0.92, 0.45, 0.35, 0.5])!)
ctx.strokePath()
ctx.restoreGState()

// Arrow heads pointing in opposite directions (inverse coupling)
let arrowSize = s * 0.022
let midX = (linkLeft + linkRight) / 2

ctx.saveGState()
ctx.setFillColor(CGColor(colorSpace: cs, components: [1, 1, 1, 0.7])!)

// Right arrow (top line)
let rArrow = CGMutablePath()
rArrow.move(to: CGPoint(x: midX + arrowSize * 1.5, y: linkY - s * 0.02))
rArrow.addLine(to: CGPoint(x: midX - arrowSize * 0.5, y: linkY - s * 0.02 - arrowSize))
rArrow.addLine(to: CGPoint(x: midX - arrowSize * 0.5, y: linkY - s * 0.02 + arrowSize))
rArrow.closeSubpath()
ctx.addPath(rArrow)
ctx.fillPath()

// Left arrow (bottom line)
let lArrow = CGMutablePath()
lArrow.move(to: CGPoint(x: midX - arrowSize * 1.5, y: linkY + s * 0.02))
lArrow.addLine(to: CGPoint(x: midX + arrowSize * 0.5, y: linkY + s * 0.02 - arrowSize))
lArrow.addLine(to: CGPoint(x: midX + arrowSize * 0.5, y: linkY + s * 0.02 + arrowSize))
lArrow.closeSubpath()
ctx.addPath(lArrow)
ctx.fillPath()
ctx.restoreGState()

// --- Small glowing dots at connection endpoints ---
for x in [linkLeft, linkRight] {
    for dy: CGFloat in [-0.02, 0.02] {
        drawFilledCircle(cx: x, cy: linkY + s * dy, r: s * 0.008,
                         color: [1, 1, 1, 0.6])
    }
}

// --- Decorative outer ring (subtle) ---
ctx.saveGState()
ctx.setStrokeColor(CGColor(colorSpace: cs, components: [1, 1, 1, 0.04])!)
ctx.setLineWidth(s * 0.003)
let ringR = s * 0.46
ctx.strokeEllipse(in: CGRect(x: s * 0.5 - ringR, y: s * 0.5 - ringR,
                              width: ringR * 2, height: ringR * 2))
ctx.restoreGState()

// Second decorative ring
ctx.saveGState()
ctx.setStrokeColor(CGColor(colorSpace: cs, components: [0.92, 0.35, 0.40, 0.06])!)
ctx.setLineWidth(s * 0.002)
let ringR2 = s * 0.42
ctx.strokeEllipse(in: CGRect(x: s * 0.5 - ringR2, y: s * 0.5 - ringR2,
                              width: ringR2 * 2, height: ringR2 * 2))
ctx.restoreGState()

// --- Ambient sparkle dots ---
let sparkles: [(CGFloat, CGFloat, CGFloat)] = [
    (0.15, 0.18, 0.004), (0.82, 0.22, 0.003), (0.90, 0.72, 0.005),
    (0.08, 0.78, 0.004), (0.50, 0.12, 0.003), (0.48, 0.88, 0.004),
    (0.22, 0.40, 0.003), (0.78, 0.55, 0.003)
]
for sp in sparkles {
    drawFilledCircle(cx: s * sp.0, cy: s * sp.1, r: s * sp.2,
                     color: [1, 1, 1, 0.25])
}

guard let image = ctx.makeImage() else { print("Failed to make image"); exit(1) }
let url = URL(fileURLWithPath: outputPath)
guard let dest = CGImageDestinationCreateWithURL(url as CFURL, kUTTypePNG, 1, nil) else {
    print("Failed to create destination"); exit(1)
}
CGImageDestinationAddImage(dest, image, nil)
guard CGImageDestinationFinalize(dest) else { print("Failed to finalize"); exit(1) }
print("Icon saved to \(outputPath)")
