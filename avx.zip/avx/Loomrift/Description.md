# App Store Listing — Loomrift

## App Name
Loomrift

## Subtitle
Dual-Grid Logic Puzzle

## Promotional Text
Two grids, one goal. Every move helps one side and hurts the other — find the path that solves both.

## Description
Loomrift is a turn-based logic puzzle built around a simple but tricky idea: two grids are linked in reverse. Tap a cell on the left grid to change it, and the matching cell on the right grid shifts the opposite way. You alternate taps between the two grids, trying to make both match their target patterns at the same time.

It sounds straightforward until you realize that fixing one grid messes up the other. The challenge is finding sequences of moves where the forward progress adds up on both sides while the disruption cancels itself out.

Two game modes keep things interesting. Tandem gives each grid a different target pattern. Echo asks you to bring both grids to the same pattern, which requires a completely different approach since the inverse coupling constantly pushes them apart.

Three difficulty levels scale the grid size and solution length: Easy uses a compact 2×3 grid solvable in a handful of moves, Normal steps up to 3×3 with longer solutions, and Hard expands to 3×4 for a serious workout.

Every puzzle is guaranteed solvable, and the optimal move count is shown so you can measure how clean your solution is. Unlimited undo lets you experiment freely, while limited hints point you toward the next correct move when you get stuck.

## Keywords
puzzle,logic,grid,brain,strategy,dual,pattern,match,think,inverse

## What's New
Initial release.

## Support URL
(placeholder)

## Privacy Policy URL
(placeholder)

## Age Rating
4+ (no objectionable content)

## Privacy
This app does not collect, store, or transmit any user data. All game progress is stored locally on the device using UserDefaults. No network requests are made. No analytics or tracking frameworks are included.

## In-App Purchases
None.

## Advertising
None.
