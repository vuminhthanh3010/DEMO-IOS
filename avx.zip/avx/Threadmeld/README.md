# Threadmeld

A color-grid puzzle game where every swap has a hidden consequence.

## How It Works

You see a grid of colored cells and a small target pattern. Your goal is to rearrange the grid to match the target. The twist: when you swap two cells that are two steps apart, the cell between them shifts its color based on the difference between the swapped values. Every move has a side effect you need to account for.

## Modes

- **Tapestry**: Unlimited moves. Fewer moves earn more stars.
- **Shuttle**: Solve in exactly the par number of moves. No room for mistakes.

## Difficulty

| Tier   | Grid  | Colors | Moves   |
|--------|-------|--------|---------|
| Spool  | 4 × 4 | 3      | 4 – 6   |
| Loom   | 5 × 5 | 3      | 8 – 12  |
| Forge  | 6 × 6 | 4      | 12 – 16 |

## Features

- Daily puzzle with streak tracking
- 11 achievement badges
- Hint system highlights the next optimal move
- Full undo history
- Progress bar showing matched cells
- Game timer (can be hidden)
- Save and resume in-progress games
- Statistics: games played, win rate, best moves, streaks
- Personal records per mode and tier
- Color blind mode (shows letters on cells)
- Three color palette options
- Haptic feedback (toggleable)
- Dark mode support

## Requirements

- iOS 14.0+
- iPhone

## Building

Open `Threadmeld.xcodeproj` in Xcode, select an iPhone simulator, and run.
