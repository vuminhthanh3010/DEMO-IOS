# App Store Description

## Name
Threadmeld

## Subtitle
Color Grid Puzzle

## Description

Swap, shift, solve. Threadmeld is a color-grid puzzle where every move matters — and every move has a hidden twist.

Pick two cells separated by one space. They swap their colors, but the cell caught in the middle shifts too. Plan carefully: the ripple from each swap reshapes the board in ways you need to predict.

Match the target pattern to complete the puzzle. Earn up to three stars based on how efficiently you solve it.

TAPESTRY MODE
Take as many moves as you want. Fewer moves, more stars. Great for learning the mechanics and finding elegant solutions.

SHUTTLE MODE
Solve in exactly the par number of moves. One extra move and you fail. Pure precision.

THREE DIFFICULTY LEVELS
Start with small 4×4 grids and 3 colors. Scale up to 6×6 grids with 4 colors and 16-move solutions. Every puzzle is generated fresh, so you'll never run out.

DAILY PUZZLE
A new challenge every day. Build your streak, earn badges, and compare solutions with friends.

FEATURES
• 11 achievement badges to unlock
• Hint system shows the next optimal move
• Full undo — rewind any mistake
• Progress bar tracks matched cells
• Game timer for speed-runners
• Save mid-puzzle and come back later
• Track your stats: win rate, best move counts, streaks
• Color blind mode with letter labels
• Three hand-picked color palettes
• Haptic feedback that feels right

## Keywords
puzzle, color, grid, swap, logic, brain, strategy, pattern, matching

## Category
Games > Puzzle
