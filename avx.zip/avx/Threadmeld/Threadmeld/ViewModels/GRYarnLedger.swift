import SwiftUI
import Combine

class GRYarnLedger: ObservableObject {
    @Published var tally: GRTallyCloth

    init() {
        tally = GRVault.loadTally()
    }

    func refresh() {
        tally = GRVault.loadTally()
    }

    func clearProgress() {
        var cloth = GRTallyCloth()
        cloth.clear()
        GRVault.saveTally(cloth)
        GRVault.clearPending()
        tally = cloth
    }

    var hasPending: Bool {
        GRVault.loadPending() != nil
    }

    var winRate: Int {
        guard tally.gamesPlayed > 0 else { return 0 }
        return Int(Double(tally.gamesWon) / Double(tally.gamesPlayed) * 100)
    }

    var todayDone: Bool { tally.todayDone }
    var dailyStreak: Int { tally.dailyStreak }

    func bestMovesFor(_ mode: GRWeaveMode, _ tier: GRSpoolTier) -> Int? {
        tally.bestMoves["\(mode.rawValue)_\(tier.rawValue)"]
    }

    func bestTimeFor(_ mode: GRWeaveMode, _ tier: GRSpoolTier) -> Int? {
        tally.bestTimes["\(mode.rawValue)_\(tier.rawValue)"]
    }

    var earnedBadges: [GRBadgeInfo] {
        GRBadgeInfo.all.filter { tally.badges[$0.key] == true }
    }

    var unearnedBadges: [GRBadgeInfo] {
        GRBadgeInfo.all.filter { tally.badges[$0.key] != true }
    }

    var recordEntries: [(label: String, moves: Int)] {
        var entries: [(label: String, moves: Int)] = []
        for mode in GRWeaveMode.allCases {
            for tier in GRSpoolTier.allCases {
                let key = "\(mode.rawValue)_\(tier.rawValue)"
                if let best = tally.bestMoves[key] {
                    entries.append((label: "\(mode.label) \(tier.label)", moves: best))
                }
            }
        }
        return entries
    }
}
