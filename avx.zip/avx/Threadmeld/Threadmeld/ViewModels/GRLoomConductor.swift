import SwiftUI
import Combine

class GRLoomConductor: ObservableObject {
    @Published var board: GRFiberGrid
    @Published var target: GRFiberGrid
    @Published var selectedCell: Int? = nil
    @Published var moveCount: Int = 0
    @Published var par: Int
    @Published var isComplete: Bool = false
    @Published var isPaused: Bool = false
    @Published var elapsed: Int = 0
    @Published var hintMove: GRCrossStitch? = nil
    @Published var invalidShake: Bool = false
    @Published var hintsUsed: Int = 0
    @Published var lastCross: GRCrossStitch? = nil
    @Published var matchDelta: Int = 0

    let mode: GRWeaveMode
    let tier: GRSpoolTier
    let isDaily: Bool

    private var solution: GRThreadPath
    private var history: [GRFiberGrid] = []
    private var timer: Timer?
    private var onPath: Bool = true
    private var initialBoard: GRFiberGrid

    var hintsRemaining: Int {
        let max = mode == .tapestry ? GRConfig.maxHintsTapestry : GRConfig.maxHintsShuttle
        return max - hintsUsed
    }

    var stars: Int {
        if moveCount <= par { return 3 }
        if moveCount <= par + 2 { return 2 }
        return 1
    }

    var matchingCells: Int {
        board.matchCount(against: target)
    }

    var totalCells: Int { board.size * board.size }

    var solutionSteps: [GRCrossStitch] { solution.steps }

    var validTargets: [Int] {
        guard let sel = selectedCell else { return [] }
        let row = sel / board.size, col = sel % board.size
        var targets: [Int] = []
        if col >= 2 { targets.append(row * board.size + col - 2) }
        if col + 2 < board.size { targets.append(row * board.size + col + 2) }
        if row >= 2 { targets.append((row - 2) * board.size + col) }
        if row + 2 < board.size { targets.append((row + 2) * board.size + col) }
        return targets
    }

    var canReset: Bool { !isComplete && !isPaused && !history.isEmpty }

    func previewMiddleValue(from selIdx: Int, to targetIdx: Int) -> Int {
        let fr = selIdx / board.size, fc = selIdx % board.size
        let tr = targetIdx / board.size, tc = targetIdx % board.size
        let mr = (fr + tr) / 2, mc = (fc + tc) / 2
        let mi = mr * board.size + mc
        let shift = ((board.cells[selIdx] - board.cells[targetIdx]) % board.colorCount + board.colorCount) % board.colorCount
        return (board.cells[mi] + shift) % board.colorCount
    }

    init(mode: GRWeaveMode, tier: GRSpoolTier) {
        self.mode = mode
        self.tier = tier
        self.isDaily = false
        let seed = UInt64(Date().timeIntervalSince1970 * 1000) ^ UInt64(arc4random())
        let comp = GRWarpForge.compose(mode: mode, tier: tier, seed: seed)
        self.board = comp.board
        self.target = comp.target
        self.solution = GRThreadPath(steps: comp.solution)
        self.par = comp.par
        self.initialBoard = comp.board
        logSolution(comp.solution)
        startTimer()
    }

    init(daily: Bool) {
        self.mode = .tapestry
        self.tier = .loom
        self.isDaily = true
        let seed = GRTallyCloth.dailySeed()
        let comp = GRWarpForge.compose(mode: .tapestry, tier: .loom, seed: seed)
        self.board = comp.board
        self.target = comp.target
        self.solution = GRThreadPath(steps: comp.solution)
        self.par = comp.par
        self.initialBoard = comp.board
        logSolution(comp.solution)
        startTimer()
    }

    init(saved: GRSavedState) {
        self.mode = saved.mode
        self.tier = saved.tier
        self.isDaily = false
        self.board = saved.board
        self.target = saved.target
        self.solution = GRThreadPath(steps: saved.solution)
        self.par = saved.par
        self.moveCount = saved.moveCount
        self.hintsUsed = saved.hintsUsed
        self.elapsed = saved.elapsed
        self.history = saved.history
        self.onPath = false
        self.initialBoard = saved.history.first ?? saved.board
        startTimer()
    }

    func selectCell(index: Int) {
        guard !isComplete, !isPaused else { return }

        let row = index / board.size
        let col = index % board.size

        if let sel = selectedCell {
            let sr = sel / board.size, sc = sel % board.size
            let cross = GRCrossStitch(fromRow: sr, fromCol: sc, toRow: row, toCol: col)
            let sameRow = sr == row && abs(sc - col) == 2
            let sameCol = sc == col && abs(sr - row) == 2
            if sameRow || sameCol {
                performCross(cross)
            } else {
                GRHaptics.error()
                withAnimation(.default) { invalidShake = true }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self.invalidShake = false
                }
            }
            selectedCell = nil
        } else {
            selectedCell = index
            GRHaptics.select()
        }
        hintMove = nil
    }

    func performCross(_ cross: GRCrossStitch) {
        let beforeMatch = matchingCells
        history.append(board)
        board.apply(cross)
        moveCount += 1
        lastCross = cross
        matchDelta = matchingCells - beforeMatch
        GRHaptics.tap()

        if let expected = solution.peek,
           cross == expected {
            solution.advance()
        } else {
            onPath = false
        }

        if board.matches(target) {
            isComplete = true
            stopTimer()
            GRHaptics.success()
            var tally = GRVault.loadTally()
            tally.recordWin(mode: mode, tier: tier, moves: moveCount, time: elapsed)
            if isDaily { tally.recordDaily() }
            GRVault.saveTally(tally)
            if !isDaily { GRVault.clearPending() }
        } else {
            saveState()
        }
    }

    func undo() {
        guard !isComplete, !isPaused, !history.isEmpty else { return }
        board = history.removeLast()
        moveCount = max(0, moveCount - 1)
        onPath = false
        lastCross = nil
        matchDelta = 0
        GRHaptics.select()
        saveState()
    }

    func resetToStart() {
        guard canReset else { return }
        board = initialBoard
        history.removeAll()
        moveCount = 0
        onPath = true
        solution.reset()
        selectedCell = nil
        hintMove = nil
        lastCross = nil
        matchDelta = 0
        GRHaptics.tap()
        saveState()
    }

    func showHint() {
        guard !isComplete, hintsRemaining > 0 else { return }
        hintsUsed += 1

        if onPath, let next = solution.peek {
            hintMove = next
        } else {
            hintMove = board.bestMove(toward: target)
        }
        GRHaptics.tap()
    }

    func newGame() {
        stopTimer()
        let seed: UInt64
        if isDaily {
            seed = GRTallyCloth.dailySeed()
        } else {
            seed = UInt64(Date().timeIntervalSince1970 * 1000) ^ UInt64(arc4random())
        }
        let comp = GRWarpForge.compose(mode: mode, tier: tier, seed: seed)
        board = comp.board
        target = comp.target
        solution = GRThreadPath(steps: comp.solution)
        par = comp.par
        initialBoard = comp.board
        moveCount = 0
        hintsUsed = 0
        isComplete = false
        isPaused = false
        elapsed = 0
        history = []
        selectedCell = nil
        hintMove = nil
        lastCross = nil
        matchDelta = 0
        onPath = true
        invalidShake = false
        logSolution(comp.solution)
        startTimer()
        if !isDaily { GRVault.clearPending() }
    }

    func togglePause() {
        isPaused.toggle()
        if isPaused { stopTimer() } else { startTimer() }
    }

    private func logSolution(_ steps: [GRCrossStitch]) {
        let desc = steps.map { "(\($0.fromRow),\($0.fromCol))\u{2192}(\($0.toRow),\($0.toCol))" }
        GRTrace.reveal(desc)
    }

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            self?.elapsed += 1
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    private func saveState() {
        guard !isDaily else { return }
        let state = GRSavedState(
            mode: mode, tier: tier, board: board, target: target,
            solution: solution.steps, par: par, moveCount: moveCount,
            hintsUsed: hintsUsed, elapsed: elapsed, history: history
        )
        GRVault.savePending(state)
    }

    #if DEBUG
    func runUnattended() {
        let allSteps = solution.steps
        guard !allSteps.isEmpty else {
            GRTrace.line("autoplay", "no path")
            return
        }
        GRTrace.line("autoplay", "path count=\(allSteps.count)")
        var step = 0
        Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { [weak self] tmr in
            guard let self = self else { tmr.invalidate(); return }
            guard step < allSteps.count else {
                tmr.invalidate()
                GRTrace.line("autoplay", self.isComplete ? "WIN" : "LOSE")
                return
            }
            self.performCross(allSteps[step])
            step += 1
        }
    }
    #endif
}
