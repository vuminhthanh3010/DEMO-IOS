import Foundation

enum GRWeaveMode: String, CaseIterable, Codable {
    case tapestry
    case shuttle

    var label: String {
        switch self {
        case .tapestry: return "Tapestry"
        case .shuttle:  return "Shuttle"
        }
    }

    var blurb: String {
        switch self {
        case .tapestry: return "Free play — fewest moves wins"
        case .shuttle:  return "Solve in exactly par moves"
        }
    }
}
