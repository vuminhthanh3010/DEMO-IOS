import Foundation

struct GRCrossStitch: Equatable, Codable {
    let fromRow: Int
    let fromCol: Int
    let toRow: Int
    let toCol: Int

    var midRow: Int { (fromRow + toRow) / 2 }
    var midCol: Int { (fromCol + toCol) / 2 }

    var reversed: GRCrossStitch {
        GRCrossStitch(fromRow: toRow, fromCol: toCol, toRow: fromRow, toCol: fromCol)
    }

    static func allMoves(gridSize s: Int) -> [GRCrossStitch] {
        var list: [GRCrossStitch] = []
        for r in 0..<s {
            for c in 0..<s {
                if c + 2 < s {
                    list.append(GRCrossStitch(fromRow: r, fromCol: c, toRow: r, toCol: c + 2))
                    list.append(GRCrossStitch(fromRow: r, fromCol: c + 2, toRow: r, toCol: c))
                }
                if r + 2 < s {
                    list.append(GRCrossStitch(fromRow: r, fromCol: c, toRow: r + 2, toCol: c))
                    list.append(GRCrossStitch(fromRow: r + 2, fromCol: c, toRow: r, toCol: c))
                }
            }
        }
        return list
    }

    func isValidNeighbor(of other: GRCrossStitch) -> Bool {
        let samePositions = (fromRow == other.fromRow && fromCol == other.fromCol
            && toRow == other.toRow && toCol == other.toCol)
        let swappedPositions = (fromRow == other.toRow && fromCol == other.toCol
            && toRow == other.fromRow && toCol == other.fromCol)
        return !samePositions && !swappedPositions
    }
}
