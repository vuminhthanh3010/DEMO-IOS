import Foundation

struct GRTallyCloth: Codable {
    var gamesPlayed: Int = 0
    var gamesWon: Int = 0
    var currentStreak: Int = 0
    var bestStreak: Int = 0
    var bestMoves: [String: Int] = [:]
    var bestTimes: [String: Int] = [:]
    var badges: [String: Bool] = [:]
    var totalMoves: Int = 0
    var totalTime: Int = 0
    var dailyLog: [String: Bool] = [:]

    mutating func recordWin(mode: GRWeaveMode, tier: GRSpoolTier, moves: Int, time: Int = 0) {
        gamesPlayed += 1
        gamesWon += 1
        currentStreak += 1
        totalMoves += moves
        totalTime += time
        if currentStreak > bestStreak { bestStreak = currentStreak }

        let key = "\(mode.rawValue)_\(tier.rawValue)"
        if let prev = bestMoves[key] {
            if moves < prev { bestMoves[key] = moves }
        } else {
            bestMoves[key] = moves
        }
        if time > 0 {
            if let prev = bestTimes[key] {
                if time < prev { bestTimes[key] = time }
            } else {
                bestTimes[key] = time
            }
        }

        checkBadges()
    }

    mutating func recordLoss() {
        gamesPlayed += 1
        currentStreak = 0
    }

    mutating func recordDaily() {
        dailyLog[Self.todayKey()] = true
        checkBadges()
    }

    var todayDone: Bool {
        dailyLog[Self.todayKey()] == true
    }

    var dailyStreak: Int {
        let cal = Calendar.current
        var date = Date()
        var streak = 0
        for _ in 0..<365 {
            let key = Self.dateKey(date)
            guard dailyLog[key] == true else { break }
            streak += 1
            guard let prev = cal.date(byAdding: .day, value: -1, to: date) else { break }
            date = prev
        }
        return streak
    }

    mutating func clear() {
        self = GRTallyCloth()
    }

    static func todayKey() -> String {
        dateKey(Date())
    }

    static func dateKey(_ date: Date) -> String {
        let cal = Calendar.current
        let c = cal.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    static func dailySeed() -> UInt64 {
        let cal = Calendar.current
        let c = cal.dateComponents([.year, .month, .day], from: Date())
        return UInt64((c.year ?? 0) * 10000 + (c.month ?? 0) * 100 + (c.day ?? 0))
    }

    private mutating func checkBadges() {
        if gamesWon >= 1 { badges["first_weave"] = true }
        if gamesWon >= 10 { badges["weaver_10"] = true }
        if gamesWon >= 50 { badges["master_weaver"] = true }
        if gamesWon >= 100 { badges["grand_weaver"] = true }
        if currentStreak >= 5 { badges["streak_5"] = true }
        if currentStreak >= 10 { badges["streak_10"] = true }
        if currentStreak >= 25 { badges["streak_25"] = true }
        if bestMoves.keys.contains(where: { $0.contains("forge") }) {
            badges["forge_solved"] = true
        }
        if bestMoves.count >= 6 { badges["all_modes"] = true }
        if dailyStreak >= 7 { badges["daily_7"] = true }
        if dailyStreak >= 30 { badges["daily_30"] = true }
    }
}
