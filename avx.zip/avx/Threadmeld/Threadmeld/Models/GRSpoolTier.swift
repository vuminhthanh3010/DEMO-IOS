import Foundation

enum GRSpoolTier: String, CaseIterable, Codable {
    case spool
    case loom
    case forge

    var label: String {
        switch self {
        case .spool: return "Spool"
        case .loom:  return "Loom"
        case .forge: return "Forge"
        }
    }

    var gridSize: Int {
        switch self {
        case .spool: return 4
        case .loom:  return 5
        case .forge: return 6
        }
    }

    var colorCount: Int {
        switch self {
        case .spool, .loom: return 3
        case .forge:        return 4
        }
    }

    var moveLow: Int {
        switch self {
        case .spool: return 4
        case .loom:  return 8
        case .forge: return 12
        }
    }

    var moveHigh: Int {
        switch self {
        case .spool: return 6
        case .loom:  return 12
        case .forge: return 16
        }
    }
}
