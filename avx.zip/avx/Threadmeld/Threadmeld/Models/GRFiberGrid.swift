import Foundation

struct GRFiberGrid: Equatable, Codable {
    let size: Int
    let colorCount: Int
    var cells: [Int]

    init(size: Int, colorCount: Int) {
        self.size = size
        self.colorCount = colorCount
        self.cells = Array(repeating: 0, count: size * size)
    }

    init(size: Int, colorCount: Int, cells: [Int]) {
        self.size = size
        self.colorCount = colorCount
        self.cells = cells
    }

    subscript(row: Int, col: Int) -> Int {
        get { cells[row * size + col] }
        set { cells[row * size + col] = newValue }
    }

    func matches(_ other: GRFiberGrid) -> Bool {
        cells == other.cells
    }

    var matchCount: Int {
        0
    }

    func matchCount(against target: GRFiberGrid) -> Int {
        var n = 0
        for i in 0..<cells.count {
            if cells[i] == target.cells[i] { n += 1 }
        }
        return n
    }

    func mismatchCount(against target: GRFiberGrid) -> Int {
        cells.count - matchCount(against: target)
    }

    mutating func apply(_ cross: GRCrossStitch) {
        let fi = cross.fromRow * size + cross.fromCol
        let ti = cross.toRow * size + cross.toCol
        let mi = cross.midRow * size + cross.midCol

        let shift = ((cells[fi] - cells[ti]) % colorCount + colorCount) % colorCount
        let tmp = cells[fi]
        cells[fi] = cells[ti]
        cells[ti] = tmp
        cells[mi] = (cells[mi] + shift) % colorCount
    }

    func bestMove(toward target: GRFiberGrid) -> GRCrossStitch? {
        let allMoves = GRCrossStitch.allMoves(gridSize: size)
        var bestScore = -1
        var best: GRCrossStitch? = nil
        for move in allMoves {
            var copy = self
            copy.apply(move)
            let score = copy.matchCount(against: target)
            if score > bestScore {
                bestScore = score
                best = move
            }
        }
        return best
    }

    func validCrosses(from row: Int, _ col: Int) -> [GRCrossStitch] {
        var list: [GRCrossStitch] = []
        let offsets: [(Int, Int)] = [(0, 2), (0, -2), (2, 0), (-2, 0)]
        for (dr, dc) in offsets {
            let tr = row + dr, tc = col + dc
            if tr >= 0 && tr < size && tc >= 0 && tc < size {
                list.append(GRCrossStitch(fromRow: row, fromCol: col, toRow: tr, toCol: tc))
            }
        }
        return list
    }
}
