import Foundation

struct GRMillRNG {
    private var state: UInt64

    init(seed: UInt64) { state = seed == 0 ? 1 : seed }

    mutating func next() -> UInt64 {
        state &+= 0x9e3779b97f4a7c15
        var z = state
        z = (z ^ (z >> 30)) &* 0xbf58476d1ce4e5b9
        z = (z ^ (z >> 27)) &* 0x94d049bb133111eb
        return z ^ (z >> 31)
    }

    mutating func nextInt(_ bound: Int) -> Int {
        Int(next() % UInt64(bound))
    }
}

struct GRComposition {
    var board: GRFiberGrid
    let target: GRFiberGrid
    let solution: [GRCrossStitch]
    let par: Int
}

enum GRWarpForge {
    static func compose(mode: GRWeaveMode, tier: GRSpoolTier, seed: UInt64) -> GRComposition {
        var rng = GRMillRNG(seed: seed)
        let s = tier.gridSize
        let k = tier.colorCount

        var target = GRFiberGrid(size: s, colorCount: k)
        for i in 0..<target.cells.count {
            target.cells[i] = rng.nextInt(k)
        }

        let span = tier.moveHigh - tier.moveLow + 1
        let n = rng.nextInt(span) + tier.moveLow

        let pool = GRCrossStitch.allMoves(gridSize: s)
        var board = target
        var moves: [GRCrossStitch] = []
        var last: GRCrossStitch? = nil

        for _ in 0..<n {
            var move: GRCrossStitch
            var attempts = 0
            repeat {
                move = pool[rng.nextInt(pool.count)]
                attempts += 1
                if attempts > 200 { break }
            } while !isUseful(move, on: board, last: last)

            board.apply(move)
            moves.append(move)
            last = move
        }

        let solution = Array(moves.reversed())
        return GRComposition(board: board, target: target, solution: solution, par: n)
    }

    private static func isUseful(_ move: GRCrossStitch, on board: GRFiberGrid, last: GRCrossStitch?) -> Bool {
        let fi = move.fromRow * board.size + move.fromCol
        let ti = move.toRow * board.size + move.toCol
        if board.cells[fi] == board.cells[ti] { return false }
        if let prev = last {
            if !move.isValidNeighbor(of: prev) { return false }
        }
        return true
    }
}
