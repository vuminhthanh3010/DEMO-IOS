import Foundation

struct GRThreadPath {
    let steps: [GRCrossStitch]
    private(set) var cursor: Int = 0

    var isDone: Bool { cursor >= steps.count }

    var peek: GRCrossStitch? {
        guard cursor < steps.count else { return nil }
        return steps[cursor]
    }

    mutating func advance() { cursor += 1 }

    mutating func reset() { cursor = 0 }

    var remaining: Int { max(0, steps.count - cursor) }
}
