import SwiftUI

@main
struct ThreadmeldApp: App {
    var body: some Scene {
        WindowGroup {
            #if DEBUG
            if CommandLine.arguments.contains("-GRRehearse") {
                GRRehearsalStage()
            } else {
                GRRootView()
            }
            #else
            GRRootView()
            #endif
        }
    }
}

struct GRRootView: View {
    enum Phase: Equatable {
        case splash, home, game, tally, settings, primer
    }

    @State private var phase: Phase = .splash
    @State private var selectedMode: GRWeaveMode = .tapestry
    @State private var selectedTier: GRSpoolTier = .spool
    @State private var gameID = UUID()
    @StateObject private var ledger = GRYarnLedger()
    @State private var conductor: GRLoomConductor?
    @State private var resumedConductor: GRLoomConductor?

    var body: some View {
        ZStack {
            switch phase {
            case .splash:
                GROpeningStage {
                    withAnimation(.easeInOut(duration: 0.4)) { phase = .home }
                }
                .transition(.opacity)

            case .home:
                GRHearthStage(
                    ledger: ledger,
                    onStart: { mode, tier in
                        selectedMode = mode
                        selectedTier = tier
                        let c = GRLoomConductor(mode: mode, tier: tier)
                        conductor = c
                        resumedConductor = nil
                        gameID = UUID()
                        withAnimation(.easeInOut(duration: 0.35)) { phase = .game }
                    },
                    onContinue: {
                        if let saved = GRVault.loadPending() {
                            let c = GRLoomConductor(saved: saved)
                            resumedConductor = c
                            conductor = nil
                            gameID = UUID()
                            withAnimation(.easeInOut(duration: 0.35)) { phase = .game }
                        }
                    },
                    onDaily: {
                        let c = GRLoomConductor(daily: true)
                        conductor = c
                        resumedConductor = nil
                        gameID = UUID()
                        withAnimation(.easeInOut(duration: 0.35)) { phase = .game }
                    },
                    onSettings: {
                        withAnimation(.easeInOut(duration: 0.3)) { phase = .settings }
                    },
                    onGuide: {
                        withAnimation(.easeInOut(duration: 0.3)) { phase = .primer }
                    }
                )
                .transition(.move(edge: .leading))
                .onAppear { ledger.refresh() }

            case .game:
                if let c = conductor ?? resumedConductor {
                    GRLoomStage(
                        conductor: c,
                        onFinish: {
                            withAnimation(.easeInOut(duration: 0.35)) { phase = .tally }
                        },
                        onHome: {
                            withAnimation(.easeInOut(duration: 0.3)) { phase = .home }
                        }
                    )
                    .id(gameID)
                    .transition(.move(edge: .trailing))
                    .onAppear {
                        #if DEBUG
                        if CommandLine.arguments.contains("-GRUnattended") {
                            c.runUnattended()
                        }
                        #endif
                    }
                }

            case .tally:
                if let c = conductor ?? resumedConductor {
                    GRTallyStage(
                        conductor: c,
                        onHome: {
                            withAnimation(.easeInOut(duration: 0.3)) { phase = .home }
                        },
                        onNewGame: {
                            let nc = GRLoomConductor(mode: selectedMode, tier: selectedTier)
                            conductor = nc
                            resumedConductor = nil
                            gameID = UUID()
                            withAnimation(.easeInOut(duration: 0.35)) { phase = .game }
                        }
                    )
                    .transition(.move(edge: .trailing))
                }

            case .settings:
                GRBobbinStage(
                    onBack: {
                        withAnimation(.easeInOut(duration: 0.3)) { phase = .home }
                    },
                    ledger: ledger
                )
                .transition(.move(edge: .trailing))

            case .primer:
                GRPrimerStage(
                    onBack: {
                        withAnimation(.easeInOut(duration: 0.3)) { phase = .home }
                    }
                )
                .transition(.move(edge: .trailing))
            }
        }
        .onAppear {
            #if DEBUG
            setupUnattended()
            #endif
        }
    }

    #if DEBUG
    private func setupUnattended() {
        guard CommandLine.arguments.contains("-GRUnattended") else { return }
        var mode: GRWeaveMode = .tapestry
        var tier: GRSpoolTier = .spool
        if let mi = CommandLine.arguments.firstIndex(of: "-GRMode"),
           mi + 1 < CommandLine.arguments.count,
           let m = GRWeaveMode(rawValue: CommandLine.arguments[mi + 1]) {
            mode = m
        }
        if let ti = CommandLine.arguments.firstIndex(of: "-GRTier"),
           ti + 1 < CommandLine.arguments.count,
           let t = GRSpoolTier(rawValue: CommandLine.arguments[ti + 1]) {
            tier = t
        }
        selectedMode = mode
        selectedTier = tier
        let c = GRLoomConductor(mode: mode, tier: tier)
        conductor = c
        phase = .game
    }
    #endif
}
