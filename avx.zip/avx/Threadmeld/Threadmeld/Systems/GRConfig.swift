import Foundation

enum GRConfig {
    static let storeID = "000000000"
    static let reviewURL = "https://apps.apple.com/app/id\(storeID)?action=write-review"
    static let maxHintsTapestry = 3
    static let maxHintsShuttle = 1
}

struct GRBadgeInfo {
    let key: String
    let icon: String
    let label: String
    let desc: String

    static let all: [GRBadgeInfo] = [
        GRBadgeInfo(key: "first_weave", icon: "hand.thumbsup.fill", label: "First Weave", desc: "Win your first game"),
        GRBadgeInfo(key: "weaver_10", icon: "star.fill", label: "Apprentice", desc: "Win 10 games"),
        GRBadgeInfo(key: "master_weaver", icon: "crown.fill", label: "Master", desc: "Win 50 games"),
        GRBadgeInfo(key: "grand_weaver", icon: "sparkles", label: "Grand", desc: "Win 100 games"),
        GRBadgeInfo(key: "streak_5", icon: "flame.fill", label: "On Fire", desc: "5 win streak"),
        GRBadgeInfo(key: "streak_10", icon: "bolt.fill", label: "Unstoppable", desc: "10 win streak"),
        GRBadgeInfo(key: "streak_25", icon: "tornado", label: "Legendary", desc: "25 win streak"),
        GRBadgeInfo(key: "forge_solved", icon: "hammer.fill", label: "Forgemaster", desc: "Solve a Forge puzzle"),
        GRBadgeInfo(key: "all_modes", icon: "checkmark.seal.fill", label: "Completionist", desc: "Every mode and tier"),
        GRBadgeInfo(key: "daily_7", icon: "calendar", label: "Weekly", desc: "7-day daily streak"),
        GRBadgeInfo(key: "daily_30", icon: "calendar.badge.checkmark", label: "Monthly", desc: "30-day daily streak"),
    ]
}
