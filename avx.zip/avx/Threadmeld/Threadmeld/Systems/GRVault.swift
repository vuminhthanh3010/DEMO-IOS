import Foundation

enum GRVault {
    private static let tallyKey = "gr_tally"
    private static let savedGameKey = "gr_saved_game"

    static func loadTally() -> GRTallyCloth {
        guard let data = UserDefaults.standard.data(forKey: tallyKey),
              let cloth = try? JSONDecoder().decode(GRTallyCloth.self, from: data) else {
            return GRTallyCloth()
        }
        return cloth
    }

    static func saveTally(_ cloth: GRTallyCloth) {
        if let data = try? JSONEncoder().encode(cloth) {
            UserDefaults.standard.set(data, forKey: tallyKey)
        }
    }

    static func savePending(_ state: GRSavedState) {
        if let data = try? JSONEncoder().encode(state) {
            UserDefaults.standard.set(data, forKey: savedGameKey)
        }
    }

    static func loadPending() -> GRSavedState? {
        guard let data = UserDefaults.standard.data(forKey: savedGameKey),
              let state = try? JSONDecoder().decode(GRSavedState.self, from: data) else {
            return nil
        }
        return state
    }

    static func clearPending() {
        UserDefaults.standard.removeObject(forKey: savedGameKey)
    }

    static func clearAll() {
        UserDefaults.standard.removeObject(forKey: tallyKey)
        UserDefaults.standard.removeObject(forKey: savedGameKey)
    }
}

struct GRSavedState: Codable {
    let mode: GRWeaveMode
    let tier: GRSpoolTier
    let board: GRFiberGrid
    let target: GRFiberGrid
    let solution: [GRCrossStitch]
    let par: Int
    let moveCount: Int
    let hintsUsed: Int
    let elapsed: Int
    let history: [GRFiberGrid]
}
