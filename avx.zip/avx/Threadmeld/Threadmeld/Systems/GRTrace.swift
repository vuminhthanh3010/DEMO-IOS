import Foundation

enum GRTrace {
    static func line(_ tag: String, _ msg: String) {
        #if DEBUG
        print("[\(tag)] \(msg)")
        fflush(stdout)
        #endif
    }

    static func reveal(_ steps: [String]) {
        #if DEBUG
        print("[board] solution: " + steps.joined(separator: " → "))
        fflush(stdout)
        #endif
    }
}
