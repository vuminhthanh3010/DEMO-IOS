import SwiftUI

enum GRStageTone: String, CaseIterable {
    case hearth, loom, tally, bobbin, primer
}

enum GRColorScheme: String, CaseIterable, Codable {
    case amber, indigo, sage
    var label: String {
        switch self {
        case .amber:  return "Amber"
        case .indigo: return "Indigo"
        case .sage:   return "Sage"
        }
    }
}

enum GRPalette {
    static func gradient(for tone: GRStageTone, scheme: GRColorScheme = .amber, dark: Bool = false) -> [Color] {
        switch (tone, dark) {
        case (.hearth, false): return [Color(h: 15, s: 0.55, b: 0.42), Color(h: 340, s: 0.40, b: 0.32)]
        case (.hearth, true):  return [Color(h: 15, s: 0.60, b: 0.18), Color(h: 340, s: 0.48, b: 0.14)]
        case (.loom, false):   return [Color(h: 225, s: 0.82, b: 0.13), Color(h: 245, s: 0.55, b: 0.18)]
        case (.loom, true):    return [Color(h: 225, s: 0.88, b: 0.07), Color(h: 245, s: 0.60, b: 0.10)]
        case (.tally, false):  return [Color(h: 160, s: 0.55, b: 0.22), Color(h: 40, s: 0.60, b: 0.35)]
        case (.tally, true):   return [Color(h: 160, s: 0.60, b: 0.12), Color(h: 40, s: 0.65, b: 0.18)]
        case (.bobbin, false): return [Color(h: 240, s: 0.06, b: 0.12), Color(h: 220, s: 0.10, b: 0.16)]
        case (.bobbin, true):  return [Color(h: 240, s: 0.08, b: 0.06), Color(h: 220, s: 0.12, b: 0.09)]
        case (.primer, false): return [Color(h: 185, s: 0.60, b: 0.22), Color(h: 230, s: 0.45, b: 0.16)]
        case (.primer, true):  return [Color(h: 185, s: 0.65, b: 0.10), Color(h: 230, s: 0.50, b: 0.08)]
        }
    }

    static func fiberColors(count: Int, dark: Bool = false) -> [Color] {
        if dark {
            switch count {
            case 4:  return [Color(h: 38, s: 0.80, b: 0.88), Color(h: 210, s: 0.70, b: 0.82),
                             Color(h: 350, s: 0.65, b: 0.85), Color(h: 158, s: 0.58, b: 0.70)]
            default: return [Color(h: 38, s: 0.80, b: 0.88), Color(h: 210, s: 0.70, b: 0.82),
                             Color(h: 350, s: 0.65, b: 0.85)]
            }
        } else {
            switch count {
            case 4:  return [Color(h: 38, s: 0.85, b: 0.92), Color(h: 215, s: 0.75, b: 0.78),
                             Color(h: 352, s: 0.70, b: 0.85), Color(h: 160, s: 0.62, b: 0.65)]
            default: return [Color(h: 38, s: 0.85, b: 0.92), Color(h: 215, s: 0.75, b: 0.78),
                             Color(h: 352, s: 0.70, b: 0.85)]
            }
        }
    }

    static let accentGold = Color(h: 42, s: 0.85, b: 0.95)
    static let accentCoral = Color(h: 5, s: 0.65, b: 0.90)
    static let accentTeal = Color(h: 175, s: 0.55, b: 0.75)
    static let textPrimary = Color.white
    static let textSecondary = Color.white.opacity(0.75)
}

extension Color {
    init(h: Double, s: Double, b: Double) {
        self.init(hue: h / 360.0, saturation: s, brightness: b)
    }
}
