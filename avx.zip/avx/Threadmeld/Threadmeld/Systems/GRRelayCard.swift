import SwiftUI
import UIKit

struct GRRelayCard: UIViewControllerRepresentable {
    let payload: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: payload, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}
