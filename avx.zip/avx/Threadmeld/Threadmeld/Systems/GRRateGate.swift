import StoreKit
import UIKit

enum GRRateGate {
    static func prompt() {
        SKStoreReviewController.requestReview()
    }

    static func openStore() {
        guard let url = URL(string: GRConfig.reviewURL) else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
}
