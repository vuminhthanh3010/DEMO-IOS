import SwiftUI

struct GRTallyStage: View {
    let conductor: GRLoomConductor
    let onHome: () -> Void
    let onNewGame: () -> Void
    @State private var showShare = false
    @State private var appear = false
    @State private var replayBoard: GRFiberGrid?
    @State private var isReplaying = false

    private var unit: CGFloat { UIScreen.main.bounds.width }

    var body: some View {
        ZStack {
            GRBackdrop(tone: .tally)

            ScrollView(showsIndicators: false) {
                VStack(spacing: unit * 0.03) {
                    Spacer().frame(height: unit * 0.08)

                    Text("Puzzle Solved!")
                        .font(.system(size: unit * 0.08, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)
                        .shadow(color: GRPalette.accentGold.opacity(0.4), radius: 20, y: 0)
                        .opacity(appear ? 1 : 0)
                        .scaleEffect(appear ? 1 : 0.5)

                    starsView(unit: unit)

                    statsCapsules(unit: unit)

                    boardPreview(unit: unit)

                    replayButton(unit: unit)

                    Spacer().frame(height: unit * 0.02)

                    VStack(spacing: unit * 0.016) {
                        GRShuttleButton("Share", icon: "square.and.arrow.up",
                                        tint: Color(h: 190, s: 0.50, b: 0.55), wide: true) {
                            showShare = true
                        }
                        GRShuttleButton("New Game", icon: "arrow.2.squarepath",
                                        tint: Color(h: 35, s: 0.70, b: 0.80), wide: true) {
                            onNewGame()
                        }
                        GRShuttleButton("Home", icon: "house.fill",
                                        tint: Color(h: 260, s: 0.30, b: 0.45), wide: true) {
                            onHome()
                        }
                    }
                    .padding(.horizontal, unit * 0.06)

                    Spacer().frame(height: unit * 0.05)
                }
                .padding(.horizontal, unit * 0.06)
            }
        }
        .sheet(isPresented: $showShare) {
            GRRelayCard(payload: [shareText])
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.65).delay(0.1)) {
                appear = true
            }
        }
    }

    private func starsView(unit: CGFloat) -> some View {
        HStack(spacing: unit * 0.035) {
            ForEach(1...3, id: \.self) { i in
                ZStack {
                    if i <= conductor.stars {
                        Circle()
                            .fill(RadialGradient(
                                colors: [GRPalette.accentGold.opacity(0.5), Color.clear],
                                center: .center, startRadius: 0, endRadius: unit * 0.07
                            ))
                            .frame(width: unit * 0.15, height: unit * 0.15)
                            .scaleEffect(appear ? 1.3 : 0.4)
                    }

                    Image(systemName: i <= conductor.stars ? "star.fill" : "star")
                        .font(.system(size: unit * 0.10))
                        .foregroundColor(i <= conductor.stars
                            ? GRPalette.accentGold
                            : .white.opacity(0.15))
                        .scaleEffect(appear && i <= conductor.stars ? 1 : 0.4)
                        .animation(.spring(response: 0.5, dampingFraction: 0.5)
                            .delay(Double(i) * 0.2), value: appear)
                }
            }
        }
        .padding(.vertical, unit * 0.01)
    }

    private func statsCapsules(unit: CGFloat) -> some View {
        VStack(spacing: unit * 0.01) {
            HStack(spacing: unit * 0.015) {
                statPill(icon: "square.grid.3x3", text: conductor.mode.label,
                         color: Color(h: 35, s: 0.60, b: 0.70), unit: unit)
                statPill(icon: "gauge", text: conductor.tier.label,
                         color: Color(h: 215, s: 0.55, b: 0.65), unit: unit)
            }
            HStack(spacing: unit * 0.015) {
                statPill(icon: "arrow.left.arrow.right", text: "\(conductor.moveCount)/\(conductor.par) moves",
                         color: conductor.moveCount <= conductor.par
                            ? Color(h: 130, s: 0.50, b: 0.65)
                            : Color(h: 42, s: 0.65, b: 0.75), unit: unit)
                statPill(icon: "clock", text: formattedTime,
                         color: Color(h: 260, s: 0.40, b: 0.55), unit: unit)
            }
        }
    }

    private func statPill(icon: String, text: String, color: Color, unit: CGFloat) -> some View {
        HStack(spacing: unit * 0.012) {
            Image(systemName: icon)
                .font(.system(size: unit * 0.022))
                .foregroundColor(color)
            Text(text)
                .font(.system(size: unit * 0.024, weight: .semibold, design: .rounded))
                .foregroundColor(.white.opacity(0.85))
        }
        .padding(.horizontal, unit * 0.025)
        .padding(.vertical, unit * 0.015)
        .frame(maxWidth: .infinity)
        .background(
            Capsule().fill(color.opacity(0.12))
        )
        .overlay(
            Capsule().stroke(color.opacity(0.25), lineWidth: 0.5)
        )
    }

    private func boardPreview(unit: CGFloat) -> some View {
        let displayGrid = replayBoard ?? conductor.board
        return VStack(spacing: unit * 0.01) {
            Text(isReplaying ? "REPLAYING..." : "COMPLETED BOARD")
                .font(.system(size: unit * 0.016, weight: .semibold, design: .rounded))
                .tracking(1.5)
                .foregroundColor(.white.opacity(0.4))

            GRDesignMiniature(grid: displayGrid, side: unit * 0.28)
        }
    }

    private func replayButton(unit: CGFloat) -> some View {
        Button(action: startReplay) {
            HStack(spacing: unit * 0.012) {
                Image(systemName: isReplaying ? "stop.fill" : "play.fill")
                    .font(.system(size: unit * 0.022))
                Text(isReplaying ? "Stop" : "Replay Solution")
                    .font(.system(size: unit * 0.024, weight: .medium, design: .rounded))
            }
            .foregroundColor(.white.opacity(0.7))
            .padding(.horizontal, unit * 0.035)
            .padding(.vertical, unit * 0.014)
            .background(Capsule().fill(Color.white.opacity(0.08)))
            .overlay(Capsule().stroke(Color.white.opacity(0.12), lineWidth: 0.5))
        }
    }

    private func startReplay() {
        guard !isReplaying else {
            isReplaying = false
            replayBoard = nil
            return
        }
        let steps = conductor.solutionSteps
        guard !steps.isEmpty else { return }

        isReplaying = true
        replayBoard = conductor.target
        var board = conductor.target
        for step in steps {
            board.apply(step)
        }
        replayBoard = board

        var currentBoard = board
        var stepIdx = 0
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { tmr in
            guard self.isReplaying, stepIdx < steps.count else {
                tmr.invalidate()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    self.isReplaying = false
                    self.replayBoard = nil
                }
                return
            }
            let revStep = steps[steps.count - 1 - stepIdx].reversed
            currentBoard.apply(revStep)
            self.replayBoard = currentBoard
            stepIdx += 1
        }
    }

    private var formattedTime: String {
        let m = conductor.elapsed / 60, s = conductor.elapsed % 60
        return String(format: "%d:%02d", m, s)
    }

    private var shareText: String {
        "Threadmeld \u{2014} \(conductor.mode.label) \(conductor.tier.label): solved in \(conductor.moveCount) moves (par \(conductor.par)) \u{2b50}\u{fe0f}\u{00d7}\(conductor.stars)"
    }
}
