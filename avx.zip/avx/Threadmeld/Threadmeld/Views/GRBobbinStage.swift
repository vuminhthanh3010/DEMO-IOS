import SwiftUI

struct GRBobbinStage: View {
    let onBack: () -> Void
    @ObservedObject var ledger: GRYarnLedger
    @AppStorage("gr_haptics") private var hapticsOn = true
    @AppStorage("gr_timer_visible") private var timerVisible = true
    @AppStorage("gr_color_blind") private var colorBlind = false
    @AppStorage("gr_color_scheme") private var colorScheme = "amber"
    @State private var showClearConfirm = false

    private var unit: CGFloat { UIScreen.main.bounds.width }

    var body: some View {
        ZStack {
            GRBackdrop(tone: .bobbin)

            VStack(spacing: 0) {
                    HStack {
                        Button(action: onBack) {
                            HStack(spacing: unit * 0.012) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: unit * 0.03, weight: .semibold))
                                Text("Back")
                                    .font(.system(size: unit * 0.025, weight: .medium, design: .rounded))
                            }
                            .foregroundColor(.white.opacity(0.7))
                            .padding(.horizontal, unit * 0.02)
                            .padding(.vertical, unit * 0.012)
                            .background(Color.white.opacity(0.06))
                            .clipShape(Capsule())
                        }
                        Spacer()
                        Text("Settings")
                            .font(.system(size: unit * 0.05, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        Spacer()
                        Color.clear.frame(width: unit * 0.15, height: unit * 0.09)
                    }
                    .padding(.horizontal, unit * 0.05)
                    .padding(.bottom, unit * 0.015)

                    ScrollView(showsIndicators: false) {
                        VStack(spacing: unit * 0.028) {
                            settingsGroup(unit: unit) {
                                sectionDot("GENERAL", color: Color(h: 215, s: 0.55, b: 0.70), unit: unit)
                                settingsCard(unit: unit) {
                                    toggleRow("Haptics", isOn: $hapticsOn, icon: "waveform",
                                              accent: Color(h: 215, s: 0.55, b: 0.70), unit: unit)
                                    divider(unit: unit)
                                    toggleRow("Show Timer", isOn: $timerVisible, icon: "clock",
                                              accent: Color(h: 215, s: 0.55, b: 0.70), unit: unit)
                                }
                            }

                            settingsGroup(unit: unit) {
                                sectionDot("ACCESSIBILITY", color: Color(h: 130, s: 0.50, b: 0.65), unit: unit)
                                settingsCard(unit: unit) {
                                    toggleRow("Color Blind Mode", isOn: $colorBlind, icon: "eye",
                                              accent: Color(h: 130, s: 0.50, b: 0.65), unit: unit)
                                    Text("Shows letter labels on cells for easier color identification")
                                        .font(.system(size: unit * 0.019, design: .rounded))
                                        .foregroundColor(.white.opacity(0.3))
                                        .padding(.leading, unit * 0.07)
                                        .padding(.top, -unit * 0.01)
                                }
                            }

                            settingsGroup(unit: unit) {
                                sectionDot("APPEARANCE", color: Color(h: 280, s: 0.45, b: 0.65), unit: unit)
                                settingsCard(unit: unit) {
                                    VStack(alignment: .leading, spacing: unit * 0.015) {
                                        Text("Color Palette")
                                            .font(.system(size: unit * 0.026, weight: .medium, design: .rounded))
                                            .foregroundColor(.white.opacity(0.6))
                                        HStack(spacing: unit * 0.015) {
                                            ForEach(GRColorScheme.allCases, id: \.self) { scheme in
                                                paletteChip(scheme, unit: unit)
                                            }
                                        }
                                    }
                                }
                            }

                            settingsGroup(unit: unit) {
                                sectionDot("STATISTICS", color: Color(h: 35, s: 0.65, b: 0.80), unit: unit)
                                settingsCard(unit: unit) {
                                    statsDetail(unit: unit)
                                }
                            }

                            if !ledger.recordEntries.isEmpty {
                                settingsGroup(unit: unit) {
                                    sectionDot("RECORDS", color: GRPalette.accentGold, unit: unit)
                                    settingsCard(unit: unit) {
                                        VStack(spacing: 0) {
                                            ForEach(Array(ledger.recordEntries.enumerated()), id: \.offset) { idx, entry in
                                                if idx > 0 { divider(unit: unit) }
                                                HStack {
                                                    Image(systemName: "trophy.fill")
                                                        .font(.system(size: unit * 0.022))
                                                        .foregroundColor(GRPalette.accentGold.opacity(0.6))
                                                        .frame(width: unit * 0.04)
                                                    Text(entry.label)
                                                        .font(.system(size: unit * 0.024, design: .rounded))
                                                        .foregroundColor(.white.opacity(0.6))
                                                    Spacer()
                                                    Text("\(entry.moves) moves")
                                                        .font(.system(size: unit * 0.024, weight: .semibold, design: .rounded))
                                                        .foregroundColor(.white)
                                                }
                                                .padding(.vertical, unit * 0.007)
                                            }
                                        }
                                    }
                                }
                            }

                            settingsGroup(unit: unit) {
                                sectionDot("ACHIEVEMENTS", color: Color(h: 45, s: 0.70, b: 0.80), unit: unit)
                                settingsCard(unit: unit) {
                                    let cols = Array(repeating: GridItem(.flexible(), spacing: unit * 0.015), count: 4)
                                    LazyVGrid(columns: cols, spacing: unit * 0.015) {
                                        ForEach(GRBadgeInfo.all, id: \.key) { badge in
                                            let earned = ledger.tally.badges[badge.key] == true
                                            VStack(spacing: unit * 0.006) {
                                                ZStack {
                                                    Circle()
                                                        .fill(earned
                                                            ? LinearGradient(
                                                                colors: [Color(h: 35, s: 0.70, b: 0.80), Color(h: 25, s: 0.60, b: 0.60)],
                                                                startPoint: .topLeading, endPoint: .bottomTrailing)
                                                            : LinearGradient(
                                                                colors: [Color.white.opacity(0.05), Color.white.opacity(0.02)],
                                                                startPoint: .topLeading, endPoint: .bottomTrailing))
                                                        .frame(width: unit * 0.085, height: unit * 0.085)
                                                    Image(systemName: badge.icon)
                                                        .font(.system(size: unit * 0.026, weight: .semibold))
                                                        .foregroundColor(earned ? .white : .white.opacity(0.15))
                                                }
                                                .shadow(color: earned ? GRPalette.accentGold.opacity(0.2) : Color.clear, radius: 6, y: 3)
                                                Text(badge.label)
                                                    .font(.system(size: unit * 0.014, weight: .medium, design: .rounded))
                                                    .foregroundColor(earned ? .white.opacity(0.65) : .white.opacity(0.15))
                                                    .lineLimit(1)
                                            }
                                        }
                                    }
                                }
                            }

                            settingsGroup(unit: unit) {
                                sectionDot("DATA", color: Color(h: 0, s: 0.50, b: 0.65), unit: unit)
                                settingsCard(unit: unit) {
                                    Button(action: { showClearConfirm = true }) {
                                        HStack(spacing: unit * 0.015) {
                                            Image(systemName: "trash")
                                                .font(.system(size: unit * 0.026))
                                            Text("Reset Progress")
                                                .font(.system(size: unit * 0.028, weight: .medium, design: .rounded))
                                        }
                                        .foregroundColor(.red.opacity(0.8))
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                }

                                settingsCard(unit: unit) {
                                    Button(action: { GRRateGate.openStore() }) {
                                        HStack(spacing: unit * 0.015) {
                                            Image(systemName: "star.fill")
                                                .font(.system(size: unit * 0.026))
                                                .foregroundColor(GRPalette.accentGold)
                                            Text("Rate Threadmeld")
                                                .font(.system(size: unit * 0.028, weight: .medium, design: .rounded))
                                                .foregroundColor(.white.opacity(0.85))
                                        }
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, unit * 0.05)
                        .padding(.top, unit * 0.01)
                        .padding(.bottom, unit * 0.06)
                    }
                }
            }
        .alert(isPresented: $showClearConfirm) {
            Alert(
                title: Text("Reset Progress"),
                message: Text("This will erase all stats and saved games."),
                primaryButton: .destructive(Text("Reset")) {
                    ledger.clearProgress()
                },
                secondaryButton: .cancel()
            )
        }
    }

    private func settingsGroup<Content: View>(unit: CGFloat, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: unit * 0.01) {
            content()
        }
    }

    private func sectionDot(_ title: String, color: Color, unit: CGFloat) -> some View {
        HStack(spacing: unit * 0.012) {
            Circle()
                .fill(color)
                .frame(width: unit * 0.014, height: unit * 0.014)
            Text(title)
                .font(.system(size: unit * 0.02, weight: .semibold, design: .rounded))
                .tracking(1.5)
                .foregroundColor(.white.opacity(0.35))
        }
    }

    private func settingsCard<Content: View>(unit: CGFloat, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: unit * 0.015) {
            content()
        }
        .padding(unit * 0.032)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: unit * 0.022)
                .fill(Color.white.opacity(0.04))
        )
        .overlay(
            RoundedRectangle(cornerRadius: unit * 0.022)
                .stroke(Color.white.opacity(0.06), lineWidth: 0.5)
        )
    }

    private func statsDetail(unit: CGFloat) -> some View {
        VStack(spacing: 0) {
            detailRow("Games Played", "\(ledger.tally.gamesPlayed)", unit: unit)
            divider(unit: unit)
            detailRow("Games Won", "\(ledger.tally.gamesWon)", unit: unit)
            divider(unit: unit)
            detailRow("Win Rate", "\(ledger.winRate)%", unit: unit)
            divider(unit: unit)
            detailRow("Total Moves", "\(ledger.tally.totalMoves)", unit: unit)
            divider(unit: unit)
            detailRow("Total Time", formatTime(ledger.tally.totalTime), unit: unit)
            divider(unit: unit)
            detailRow("Daily Streak", "\(ledger.dailyStreak) days", unit: unit)
        }
    }

    private func detailRow(_ label: String, _ value: String, unit: CGFloat) -> some View {
        HStack {
            Text(label)
                .font(.system(size: unit * 0.024, design: .rounded))
                .foregroundColor(.white.opacity(0.5))
            Spacer()
            Text(value)
                .font(.system(size: unit * 0.026, weight: .semibold, design: .rounded))
                .foregroundColor(.white)
        }
        .padding(.vertical, unit * 0.007)
    }

    private func formatTime(_ seconds: Int) -> String {
        if seconds < 60 { return "\(seconds)s" }
        let m = seconds / 60
        if m < 60 { return "\(m)m" }
        let h = m / 60
        return "\(h)h \(m % 60)m"
    }

    private func toggleRow(_ label: String, isOn: Binding<Bool>, icon: String,
                           accent: Color, unit: CGFloat) -> some View {
        Toggle(isOn: isOn) {
            HStack(spacing: unit * 0.015) {
                Image(systemName: icon)
                    .font(.system(size: unit * 0.026))
                    .foregroundColor(accent.opacity(0.7))
                    .frame(width: unit * 0.04)
                Text(label)
                    .font(.system(size: unit * 0.028, weight: .medium, design: .rounded))
                    .foregroundColor(.white)
            }
        }
        .toggleStyle(SwitchToggleStyle(tint: accent))
    }

    private func divider(unit: CGFloat) -> some View {
        Rectangle()
            .fill(Color.white.opacity(0.04))
            .frame(height: 1)
    }

    private func paletteChip(_ scheme: GRColorScheme, unit: CGFloat) -> some View {
        let sel = colorScheme == scheme.rawValue
        let color = chipColor(scheme)
        return Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { colorScheme = scheme.rawValue }
        }) {
            HStack(spacing: unit * 0.01) {
                Circle()
                    .fill(color)
                    .frame(width: unit * 0.025, height: unit * 0.025)
                Text(scheme.label)
                    .font(.system(size: unit * 0.023, weight: .semibold, design: .rounded))
                    .foregroundColor(.white)
            }
            .padding(.horizontal, unit * 0.022)
            .padding(.vertical, unit * 0.012)
            .background(
                Capsule()
                    .fill(sel ? color.opacity(0.20) : Color.white.opacity(0.04))
            )
            .overlay(
                Capsule()
                    .stroke(sel ? color.opacity(0.40) : Color.clear, lineWidth: 1)
            )
        }
    }

    private func chipColor(_ scheme: GRColorScheme) -> Color {
        switch scheme {
        case .amber:  return Color(h: 35, s: 0.80, b: 0.85)
        case .indigo: return Color(h: 230, s: 0.65, b: 0.75)
        case .sage:   return Color(h: 150, s: 0.50, b: 0.65)
        }
    }
}
