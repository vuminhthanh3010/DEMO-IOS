import SwiftUI

struct GRLoomStage: View {
    @ObservedObject var conductor: GRLoomConductor
    let onFinish: () -> Void
    let onHome: () -> Void
    @State private var deltaOpacity: Double = 0
    @State private var deltaText: String = ""
    @State private var deltaColor: Color = .clear
    @State private var showTargetOverlay: Bool = false

    private var unit: CGFloat { UIScreen.main.bounds.width }
    private var screenHeight: CGFloat { UIScreen.main.bounds.height }

    var body: some View {
        ZStack {
            GRBackdrop(tone: .loom)

            VStack(spacing: unit * 0.012) {
                headerBar(unit: unit)
                hudRow(unit: unit)
                progressArc(unit: unit)

                Spacer(minLength: unit * 0.005)

                GRWeaveMat(conductor: conductor, side: unit * 0.82)

                Spacer(minLength: unit * 0.005)

                actionBar(unit: unit)
                Spacer().frame(height: unit * 0.01)
            }
            .padding(.horizontal, unit * 0.045)
            .frame(width: unit, height: screenHeight)

            if conductor.isPaused {
                pauseOverlay(unit: unit)
            }

            if showTargetOverlay {
                targetOverlay(unit: unit)
            }
        }
        .onChange(of: conductor.isComplete) { done in
            if done {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { onFinish() }
            }
        }
        .onChange(of: conductor.matchDelta) { delta in
            if delta != 0 {
                deltaText = delta > 0 ? "+\(delta)" : "\(delta)"
                deltaColor = delta > 0 ? Color(h: 130, s: 0.55, b: 0.80) : Color(h: 0, s: 0.60, b: 0.80)
                withAnimation(.easeIn(duration: 0.12)) { deltaOpacity = 1 }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                    withAnimation(.easeOut(duration: 0.4)) { deltaOpacity = 0 }
                }
            }
        }
    }

    private func headerBar(unit: CGFloat) -> some View {
        HStack {
            Button(action: onHome) {
                HStack(spacing: unit * 0.012) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: unit * 0.03, weight: .semibold))
                    Text("Back")
                        .font(.system(size: unit * 0.025, weight: .medium, design: .rounded))
                }
                .foregroundColor(.white.opacity(0.7))
                .padding(.horizontal, unit * 0.02)
                .padding(.vertical, unit * 0.012)
                .background(Color.white.opacity(0.06))
                .clipShape(Capsule())
            }

            Spacer()

            VStack(spacing: 1) {
                Text(conductor.isDaily ? "Daily Puzzle" : conductor.mode.label)
                    .font(.system(size: unit * 0.022, weight: .semibold, design: .rounded))
                Text(conductor.tier.label)
                    .font(.system(size: unit * 0.018, design: .rounded))
            }
            .foregroundColor(.white.opacity(0.5))

            Spacer()

            timerLabel(unit: unit)
        }
        .padding(.horizontal, unit * 0.01)
        .padding(.vertical, unit * 0.008)
    }

    private func timerLabel(unit: CGFloat) -> some View {
        let m = conductor.elapsed / 60, s = conductor.elapsed % 60
        return Text(String(format: "%d:%02d", m, s))
            .font(.system(size: unit * 0.028, weight: .medium, design: .monospaced))
            .foregroundColor(.white.opacity(0.4))
            .padding(.horizontal, unit * 0.02)
            .padding(.vertical, unit * 0.012)
            .background(Color.white.opacity(0.04))
            .clipShape(Capsule())
    }

    private func hudRow(unit: CGFloat) -> some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 4) {
                    Text("\(conductor.moveCount)")
                        .font(.system(size: unit * 0.06, weight: .heavy, design: .rounded))
                        .foregroundColor(moveCountColor)
                    Text("/ \(conductor.par)")
                        .font(.system(size: unit * 0.028, design: .rounded))
                        .foregroundColor(.white.opacity(0.35))
                }

                HStack(spacing: unit * 0.01) {
                    Text("\(conductor.matchingCells)/\(conductor.totalCells)")
                        .font(.system(size: unit * 0.02, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.4))
                    Text("matched")
                        .font(.system(size: unit * 0.018, design: .rounded))
                        .foregroundColor(.white.opacity(0.25))

                    if deltaOpacity > 0 {
                        Text(deltaText)
                            .font(.system(size: unit * 0.025, weight: .bold, design: .rounded))
                            .foregroundColor(deltaColor)
                            .opacity(deltaOpacity)
                            .offset(y: deltaOpacity > 0.5 ? 0 : -8)
                    }
                }
            }

            Spacer()

            Button(action: { withAnimation(.spring(response: 0.3)) { showTargetOverlay = true } }) {
                GRDesignMiniature(grid: conductor.target, side: unit * 0.14)
            }
        }
    }

    private var moveCountColor: Color {
        if conductor.moveCount <= conductor.par {
            return Color(h: 130, s: 0.55, b: 0.80)
        }
        return Color(h: 42, s: 0.80, b: 0.90)
    }

    private func progressArc(unit: CGFloat) -> some View {
        let fraction = CGFloat(conductor.matchingCells) / CGFloat(max(1, conductor.totalCells))
        return GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color.white.opacity(0.06))
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color(h: 130, s: 0.55, b: 0.70), Color(h: 175, s: 0.50, b: 0.65)],
                        startPoint: .leading, endPoint: .trailing
                    ))
                    .frame(width: max(proxy.size.height, proxy.size.width * fraction))
                    .animation(.spring(response: 0.4, dampingFraction: 0.8), value: conductor.matchingCells)
            }
        }
        .frame(height: unit * 0.01)
        .clipShape(Capsule())
    }

    private func actionBar(unit: CGFloat) -> some View {
        HStack(spacing: 0) {
            actionItem("Hint", icon: "lightbulb.fill", accent: Color(h: 45, s: 0.80, b: 0.90),
                        badge: "\(conductor.hintsRemaining)", unit: unit) {
                conductor.showHint()
            }
            actionItem("Undo", icon: "arrow.uturn.backward", accent: Color(h: 210, s: 0.55, b: 0.75),
                        badge: nil, unit: unit) {
                conductor.undo()
            }
            actionItem("Reset", icon: "arrow.counterclockwise", accent: Color(h: 350, s: 0.50, b: 0.70),
                        badge: nil, unit: unit) {
                conductor.resetToStart()
            }
            actionItem("Pause", icon: "pause.fill", accent: Color(h: 280, s: 0.45, b: 0.65),
                        badge: nil, unit: unit) {
                conductor.togglePause()
            }
            actionItem("New", icon: "arrow.2.squarepath", accent: Color(h: 160, s: 0.50, b: 0.65),
                        badge: nil, unit: unit) {
                conductor.newGame()
            }
        }
        .padding(.vertical, unit * 0.012)
        .padding(.horizontal, unit * 0.01)
        .background(
            RoundedRectangle(cornerRadius: unit * 0.025)
                .fill(Color.white.opacity(0.04))
        )
        .overlay(
            RoundedRectangle(cornerRadius: unit * 0.025)
                .stroke(Color.white.opacity(0.06), lineWidth: 0.5)
        )
    }

    private func actionItem(_ label: String, icon: String, accent: Color,
                            badge: String?, unit: CGFloat, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: unit * 0.006) {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: icon)
                        .font(.system(size: unit * 0.035, weight: .medium))
                        .foregroundColor(.white.opacity(0.85))
                        .frame(width: unit * 0.09, height: unit * 0.09)
                        .background(accent.opacity(0.15))
                        .clipShape(RoundedRectangle(cornerRadius: unit * 0.018))

                    if let badge = badge {
                        Text(badge)
                            .font(.system(size: unit * 0.016, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .frame(width: unit * 0.035, height: unit * 0.035)
                            .background(accent.opacity(0.6))
                            .clipShape(Circle())
                            .offset(x: unit * 0.008, y: -unit * 0.008)
                    }
                }
                Text(label)
                    .font(.system(size: unit * 0.016, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity)
        }
    }

    private func pauseOverlay(unit: CGFloat) -> some View {
        ZStack {
            Color.black.opacity(0.7).ignoresSafeArea()
            VStack(spacing: unit * 0.04) {
                Image(systemName: "pause.circle.fill")
                    .font(.system(size: unit * 0.12))
                    .foregroundColor(.white.opacity(0.6))
                Text("Paused")
                    .font(.system(size: unit * 0.07, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                GRShuttleButton("Resume", icon: "play.fill",
                                tint: Color(h: 130, s: 0.50, b: 0.65), wide: true) {
                    conductor.togglePause()
                }
                .padding(.horizontal, unit * 0.15)
            }
        }
    }

    private func targetOverlay(unit: CGFloat) -> some View {
        ZStack {
            Color.black.opacity(0.75).ignoresSafeArea()
                .onTapGesture {
                    withAnimation(.spring(response: 0.3)) { showTargetOverlay = false }
                }

            VStack(spacing: 16) {
                Text("TARGET PATTERN")
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .tracking(3)
                    .foregroundColor(.white.opacity(0.6))

                GRDesignMiniature(grid: conductor.target, side: 200)

                Text("Tap anywhere to close")
                    .font(.system(size: 12, design: .rounded))
                    .foregroundColor(.white.opacity(0.3))
            }
        }
        .transition(.opacity)
    }
}
