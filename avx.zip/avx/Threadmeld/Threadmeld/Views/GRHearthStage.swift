import SwiftUI

struct GRHearthStage: View {
    @ObservedObject var ledger: GRYarnLedger
    let onStart: (GRWeaveMode, GRSpoolTier) -> Void
    let onContinue: () -> Void
    let onDaily: () -> Void
    let onSettings: () -> Void
    let onGuide: () -> Void

    @State private var selectedMode: GRWeaveMode = .tapestry
    @State private var selectedTier: GRSpoolTier = .spool

    private var unit: CGFloat { UIScreen.main.bounds.width }

    var body: some View {
        VStack(spacing: 0) {
            topBar(unit: unit)
                .padding(.horizontal, unit * 0.06)
                .padding(.top, unit * 0.07)
                .padding(.bottom, unit * 0.03)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: unit * 0.045) {
                    dailyHero(unit: unit)

                    VStack(alignment: .leading, spacing: unit * 0.018) {
                        sectionLabel("MODE", unit: unit)
                        modeSwitch(unit: unit)
                        Text(selectedMode.blurb)
                            .font(.system(size: unit * 0.018, design: .rounded))
                            .foregroundColor(.white.opacity(0.3))
                            .padding(.horizontal, unit * 0.01)
                    }

                    VStack(alignment: .leading, spacing: unit * 0.018) {
                        sectionLabel("DIFFICULTY", unit: unit)
                        tierRow(unit: unit)
                    }

                    if let best = ledger.bestMovesFor(selectedMode, selectedTier) {
                        bestRecordChip(best, unit: unit)
                    }
                }
                .padding(.horizontal, unit * 0.06)
                .padding(.bottom, unit * 0.02)
            }

            ctaBar(unit: unit)
        }
        .background(GRBackdrop(tone: .hearth))
    }

    // MARK: - Top bar

    private func topBar(unit: CGFloat) -> some View {
        HStack {
            HStack(alignment: .firstTextBaseline, spacing: unit * 0.01) {
                Text("Thread")
                    .font(.system(size: unit * 0.062, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                Text("Meld")
                    .font(.system(size: unit * 0.062, weight: .heavy, design: .rounded))
                    .foregroundColor(.white.opacity(0.4))
            }

            Spacer()

            HStack(spacing: unit * 0.02) {
                navIconButton(icon: "book.fill", action: onGuide, unit: unit)
                navIconButton(icon: "gearshape.fill", action: onSettings, unit: unit)
            }
        }
    }

    private func navIconButton(icon: String, action: @escaping () -> Void, unit: CGFloat) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: unit * 0.032, weight: .semibold))
                .foregroundColor(.white.opacity(0.75))
                .frame(width: unit * 0.1, height: unit * 0.1)
                .background(Circle().fill(Color.white.opacity(0.07)))
                .overlay(Circle().stroke(Color.white.opacity(0.1), lineWidth: 1))
        }
    }

    // MARK: - Daily hero

    private func dailyHero(unit: CGFloat) -> some View {
        let done = ledger.todayDone
        let streak = ledger.dailyStreak
        let accent = Color(h: 35, s: 0.78, b: 0.80)

        return Button(action: onDaily) {
            VStack(alignment: .leading, spacing: unit * 0.035) {
                HStack {
                    Text("TODAY'S PUZZLE")
                        .font(.system(size: unit * 0.017, weight: .bold, design: .rounded))
                        .tracking(1.5)
                        .foregroundColor(.white.opacity(0.7))

                    Spacer()

                    if streak > 0 {
                        HStack(spacing: 3) {
                            Image(systemName: "flame.fill")
                                .font(.system(size: unit * 0.017))
                            Text("\(streak)")
                                .font(.system(size: unit * 0.019, weight: .bold, design: .rounded))
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, unit * 0.02)
                        .padding(.vertical, unit * 0.008)
                        .background(Capsule().fill(Color.black.opacity(0.18)))
                    }
                }

                HStack(alignment: .bottom) {
                    VStack(alignment: .leading, spacing: unit * 0.005) {
                        Text(done ? "Solved for today" : "Daily Challenge")
                            .font(.system(size: unit * 0.042, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                        Text(done ? "Come back tomorrow" : "One puzzle. One shot.")
                            .font(.system(size: unit * 0.02, design: .rounded))
                            .foregroundColor(.white.opacity(0.65))
                    }

                    Spacer()

                    ZStack {
                        Circle().fill(Color.white.opacity(0.16))
                        Image(systemName: done ? "checkmark" : "arrow.right")
                            .font(.system(size: unit * 0.03, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .frame(width: unit * 0.11, height: unit * 0.11)
                }
            }
            .padding(unit * 0.032)
            .background(
                ZStack(alignment: .topLeading) {
                    LinearGradient(
                        colors: [accent, Color(h: 350, s: 0.55, b: 0.50)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    )

                    Circle()
                        .fill(Color.white.opacity(0.08))
                        .frame(width: unit * 0.55, height: unit * 0.55)
                        .offset(x: unit * 0.28, y: -unit * 0.18)

                    Circle()
                        .fill(Color.black.opacity(0.08))
                        .frame(width: unit * 0.4, height: unit * 0.4)
                        .offset(x: -unit * 0.2, y: unit * 0.14)
                }
            )
            .clipShape(RoundedRectangle(cornerRadius: unit * 0.055))
        }
        .shadow(color: accent.opacity(0.25), radius: 16, y: 8)
    }

    // MARK: - Mode

    private func sectionLabel(_ text: String, unit: CGFloat) -> some View {
        Text(text)
            .font(.system(size: unit * 0.015, weight: .semibold, design: .rounded))
            .tracking(2)
            .foregroundColor(.white.opacity(0.22))
    }

    private func modeSwitch(unit: CGFloat) -> some View {
        HStack(spacing: unit * 0.01) {
            ForEach(GRWeaveMode.allCases, id: \.self) { mode in
                let sel = selectedMode == mode
                Button(action: {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { selectedMode = mode }
                }) {
                    Text(mode.label)
                        .font(.system(size: unit * 0.026, weight: .bold, design: .rounded))
                        .foregroundColor(sel ? Color(h: 15, s: 0.4, b: 0.16) : .white.opacity(0.4))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, unit * 0.022)
                        .background(
                            Capsule().fill(sel ? Color.white : Color.clear)
                        )
                }
            }
        }
        .padding(unit * 0.008)
        .background(Capsule().fill(Color.white.opacity(0.05)))
        .overlay(Capsule().stroke(Color.white.opacity(0.08), lineWidth: 1))
    }

    // MARK: - Difficulty

    private func tierRow(unit: CGFloat) -> some View {
        HStack(spacing: unit * 0.025) {
            ForEach(GRSpoolTier.allCases, id: \.self) { tier in
                tierCard(tier, unit: unit)
            }
        }
    }

    private func tierCard(_ tier: GRSpoolTier, unit: CGFloat) -> some View {
        let sel = selectedTier == tier
        let accent = tierAccent(tier)

        return Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { selectedTier = tier }
        }) {
            VStack(spacing: unit * 0.014) {
                miniGridPreview(tier: tier, unit: unit)
                    .padding(unit * 0.016)
                    .background(
                        RoundedRectangle(cornerRadius: unit * 0.03)
                            .fill(sel ? accent.opacity(0.16) : Color.white.opacity(0.03))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: unit * 0.03)
                            .stroke(sel ? accent.opacity(0.7) : Color.white.opacity(0.06), lineWidth: sel ? 1.5 : 0.75)
                    )

                Text(tier.label)
                    .font(.system(size: unit * 0.023, weight: .bold, design: .rounded))
                    .foregroundColor(sel ? .white : .white.opacity(0.4))

                Text("\(tier.gridSize)\u{00d7}\(tier.gridSize)")
                    .font(.system(size: unit * 0.016, weight: .medium, design: .rounded))
                    .foregroundColor(sel ? accent : .white.opacity(0.2))
            }
            .frame(maxWidth: .infinity)
        }
    }

    private func miniGridPreview(tier: GRSpoolTier, unit: CGFloat) -> some View {
        let size = tier.gridSize
        let palette = GRPalette.fiberColors(count: tier.colorCount, dark: true)
        let cols = Array(repeating: GridItem(.flexible(), spacing: 1.5), count: size)

        return LazyVGrid(columns: cols, spacing: 1.5) {
            ForEach(0..<size * size, id: \.self) { i in
                let row = i / size, col = i % size
                RoundedRectangle(cornerRadius: 1.5)
                    .fill(palette[(row * 2 + col * 3 + row * col) % palette.count])
            }
        }
        .frame(width: unit * 0.14, height: unit * 0.14)
    }

    private func tierAccent(_ tier: GRSpoolTier) -> Color {
        switch tier {
        case .spool: return Color(h: 130, s: 0.55, b: 0.70)
        case .loom:  return Color(h: 215, s: 0.60, b: 0.80)
        case .forge: return Color(h: 350, s: 0.55, b: 0.75)
        }
    }

    private func bestRecordChip(_ moves: Int, unit: CGFloat) -> some View {
        HStack(spacing: unit * 0.014) {
            Image(systemName: "trophy.fill")
                .font(.system(size: unit * 0.02))
                .foregroundColor(GRPalette.accentGold)
            Text("Personal best: \(moves) moves")
                .font(.system(size: unit * 0.019, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.45))
        }
        .padding(.horizontal, unit * 0.01)
    }

    // MARK: - CTA bar

    private func ctaBar(unit: CGFloat) -> some View {
        VStack(spacing: unit * 0.012) {
            if ledger.hasPending {
                GRShuttleButton("Continue", icon: "play.fill",
                                tint: Color(h: 215, s: 0.50, b: 0.60), wide: true) {
                    onContinue()
                }
            }
            GRShuttleButton("Start Game", icon: "sparkles",
                            tint: Color(h: 35, s: 0.70, b: 0.80), wide: true) {
                onStart(selectedMode, selectedTier)
            }
        }
        .padding(.horizontal, unit * 0.06)
        .padding(.top, unit * 0.024)
        .padding(.bottom, unit * 0.014)
        .background(
            ZStack {
                GRGlassPane(style: .systemUltraThinMaterialDark)
                LinearGradient(
                    colors: [Color.black.opacity(0.0), Color.black.opacity(0.22)],
                    startPoint: .top, endPoint: .bottom
                )
            }
            .ignoresSafeArea(edges: .bottom)
        )
        .overlay(
            Rectangle().fill(Color.white.opacity(0.06)).frame(height: 0.5),
            alignment: .top
        )
    }
}
