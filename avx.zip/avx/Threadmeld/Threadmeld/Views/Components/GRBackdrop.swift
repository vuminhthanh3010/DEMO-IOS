import SwiftUI

struct GRBackdrop: View {
    let tone: GRStageTone
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        let dark = colorScheme == .dark
        ZStack {
            LinearGradient(
                colors: GRPalette.gradient(for: tone, dark: dark),
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            decorativeLayer(dark: dark)
        }
        .ignoresSafeArea()
    }

    @ViewBuilder
    private func decorativeLayer(dark: Bool) -> some View {
        let m: Double = dark ? 0.5 : 1.0
        switch tone {
        case .hearth: hearthDecor(m: m)
        case .loom:   loomDecor(m: m)
        case .tally:  tallyDecor(m: m)
        case .bobbin: bobbinDecor(m: m)
        case .primer: primerDecor(m: m)
        }
    }

    private func hearthDecor(m: Double) -> some View {
        ZStack {
            GRDiamondLattice()
                .stroke(Color.white.opacity(0.04 * m), lineWidth: 0.5)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 30, s: 0.75, b: 0.65).opacity(0.30 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 200
                ))
                .frame(width: 400, height: 400)
                .offset(x: 110, y: -260)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 345, s: 0.50, b: 0.55).opacity(0.22 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 160
                ))
                .frame(width: 320, height: 320)
                .offset(x: -130, y: 300)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 42, s: 0.60, b: 0.70).opacity(0.12 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 120
                ))
                .frame(width: 240, height: 240)
                .offset(x: 30, y: 60)
        }
    }

    private func loomDecor(m: Double) -> some View {
        ZStack {
            GRCrosshatch()
                .stroke(Color.white.opacity(0.022 * m), lineWidth: 0.5)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 215, s: 0.50, b: 0.40).opacity(0.18 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 280
                ))
                .frame(width: 560, height: 560)
                .offset(y: 40)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 260, s: 0.40, b: 0.30).opacity(0.10 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 120
                ))
                .frame(width: 240, height: 240)
                .offset(x: 150, y: -300)
        }
    }

    private func tallyDecor(m: Double) -> some View {
        ZStack {
            ForEach(0..<16, id: \.self) { i in
                Rectangle()
                    .fill(LinearGradient(
                        colors: [
                            Color(h: 42, s: 0.80, b: 0.85).opacity(0.06 * m),
                            Color.clear
                        ],
                        startPoint: .center, endPoint: .trailing
                    ))
                    .frame(width: 600, height: 2)
                    .rotationEffect(.degrees(Double(i) * 22.5))
                    .offset(y: -40)
            }

            Circle()
                .fill(RadialGradient(
                    colors: [GRPalette.accentGold.opacity(0.16 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 200
                ))
                .frame(width: 400, height: 400)
                .offset(y: -60)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 160, s: 0.50, b: 0.50).opacity(0.14 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 140
                ))
                .frame(width: 280, height: 280)
                .offset(x: 100, y: 300)
        }
    }

    private func bobbinDecor(m: Double) -> some View {
        ZStack {
            GRRuledLines()
                .stroke(Color.white.opacity(0.025 * m), lineWidth: 0.5)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 260, s: 0.25, b: 0.25).opacity(0.10 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 150
                ))
                .frame(width: 300, height: 300)
                .offset(x: -60, y: -320)
        }
    }

    private func primerDecor(m: Double) -> some View {
        ZStack {
            GRDotGrid()
                .fill(Color.white.opacity(0.035 * m))

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 178, s: 0.55, b: 0.50).opacity(0.16 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 200
                ))
                .frame(width: 400, height: 400)
                .offset(x: -80, y: -160)

            Circle()
                .fill(RadialGradient(
                    colors: [Color(h: 15, s: 0.50, b: 0.55).opacity(0.13 * m), Color.clear],
                    center: .center, startRadius: 0, endRadius: 140
                ))
                .frame(width: 280, height: 280)
                .offset(x: 100, y: 260)
        }
    }
}

struct GRDiamondLattice: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let sp: CGFloat = 36
        let w = rect.width, h = rect.height
        var x: CGFloat = -h
        while x < w + h {
            p.move(to: CGPoint(x: x, y: 0))
            p.addLine(to: CGPoint(x: x + h, y: h))
            x += sp
        }
        x = -h
        while x < w + h {
            p.move(to: CGPoint(x: x + h, y: 0))
            p.addLine(to: CGPoint(x: x, y: h))
            x += sp
        }
        return p
    }
}

struct GRCrosshatch: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let sp: CGFloat = 32
        var y: CGFloat = 0
        while y < rect.height {
            p.move(to: CGPoint(x: 0, y: y))
            p.addLine(to: CGPoint(x: rect.width, y: y))
            y += sp
        }
        var x: CGFloat = 0
        while x < rect.width {
            p.move(to: CGPoint(x: x, y: 0))
            p.addLine(to: CGPoint(x: x, y: rect.height))
            x += sp
        }
        return p
    }
}

struct GRRuledLines: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let sp: CGFloat = 22
        var y: CGFloat = 0
        while y < rect.height {
            p.move(to: CGPoint(x: 0, y: y))
            p.addLine(to: CGPoint(x: rect.width, y: y))
            y += sp
        }
        return p
    }
}

struct GRDotGrid: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let sp: CGFloat = 18
        let r: CGFloat = 1.2
        var y: CGFloat = sp
        while y < rect.height {
            var x: CGFloat = sp
            while x < rect.width {
                p.addEllipse(in: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2))
                x += sp
            }
            y += sp
        }
        return p
    }
}
