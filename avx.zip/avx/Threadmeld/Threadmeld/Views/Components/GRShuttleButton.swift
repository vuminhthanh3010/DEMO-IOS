import SwiftUI

struct GRShuttleButton: View {
    let label: String
    let icon: String?
    let tint: Color
    let action: () -> Void
    var small: Bool = false
    var wide: Bool = false

    init(_ label: String, icon: String? = nil, tint: Color = .white,
         small: Bool = false, wide: Bool = false, action: @escaping () -> Void) {
        self.label = label
        self.icon = icon
        self.tint = tint
        self.small = small
        self.wide = wide
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            if small {
                compactBody
            } else {
                capsuleBody
            }
        }
    }

    private var capsuleBody: some View {
        HStack(spacing: 8) {
            if let icon = icon {
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .bold))
            }
            Text(label)
                .font(.system(size: 16, weight: .bold, design: .rounded))
        }
        .foregroundColor(.white)
        .padding(.vertical, 15)
        .padding(.horizontal, 28)
        .frame(maxWidth: wide ? .infinity : nil)
        .background(
            ZStack {
                Capsule()
                    .fill(LinearGradient(
                        colors: [tint, tint.opacity(0.55)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ))
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color.white.opacity(0.22), Color.clear],
                        startPoint: .top, endPoint: .center
                    ))
            }
        )
        .overlay(
            Capsule()
                .stroke(Color.white.opacity(0.18), lineWidth: 1)
        )
        .shadow(color: tint.opacity(0.35), radius: 14, y: 7)
    }

    private var compactBody: some View {
        VStack(spacing: 5) {
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.10))
                Circle()
                    .stroke(Color.white.opacity(0.15), lineWidth: 1)
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white.opacity(0.9))
                }
            }
            .frame(width: 48, height: 48)
            .shadow(color: tint.opacity(0.3), radius: 8, y: 4)

            Text(label)
                .font(.system(size: 10, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.6))
        }
    }
}
