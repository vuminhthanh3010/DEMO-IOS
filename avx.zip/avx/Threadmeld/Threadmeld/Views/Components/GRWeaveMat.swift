import SwiftUI

struct GRWeaveMat: View {
    @ObservedObject var conductor: GRLoomConductor
    let side: CGFloat

    private var cellSize: CGFloat {
        let count = CGFloat(conductor.board.size)
        let gaps = count + 1
        return (side - gaps * spacing) / count
    }

    private var spacing: CGFloat { side * 0.02 }

    var body: some View {
        let s = conductor.board.size
        let validSet = Set(conductor.validTargets)
        let columns = Array(repeating: GridItem(.fixed(cellSize), spacing: spacing), count: s)

        ZStack {
            LazyVGrid(columns: columns, spacing: spacing) {
                ForEach(0..<s * s, id: \.self) { idx in
                    let row = idx / s, col = idx % s
                    let hint = conductor.hintMove
                    let isHintFrom = hint.map { $0.fromRow == row && $0.fromCol == col } ?? false
                    let isHintTo = hint.map { $0.toRow == row && $0.toCol == col } ?? false
                    let isHintMid = hint.map { $0.midRow == row && $0.midCol == col } ?? false

                    GRFiberCell(
                        value: conductor.board[row, col],
                        targetValue: conductor.target[row, col],
                        colorCount: conductor.board.colorCount,
                        isSelected: conductor.selectedCell == idx,
                        isHintFrom: isHintFrom,
                        isHintTo: isHintTo,
                        isHintMid: isHintMid,
                        isValidTarget: validSet.contains(idx),
                        cellSize: cellSize
                    )
                    .onTapGesture { conductor.selectCell(index: idx) }
                    .animation(.spring(response: 0.3, dampingFraction: 0.7), value: conductor.board.cells[idx])
                }
            }
        }
        .frame(width: side, height: side)
        .padding(spacing * 1.5)
        .background(
            RoundedRectangle(cornerRadius: side * 0.04)
                .fill(Color.black.opacity(0.25))
        )
        .overlay(
            GRBoardBrackets(cornerRadius: side * 0.04)
                .stroke(Color.white.opacity(0.15), lineWidth: 2)
                .padding(4)
        )
    }
}

struct GRBoardBrackets: Shape {
    let cornerRadius: CGFloat
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let len: CGFloat = min(rect.width, rect.height) * 0.12
        let cr = min(cornerRadius, len * 0.5)

        p.move(to: CGPoint(x: rect.minX, y: rect.minY + len))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.minY + cr))
        p.addQuadCurve(to: CGPoint(x: rect.minX + cr, y: rect.minY),
                       control: CGPoint(x: rect.minX, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.minX + len, y: rect.minY))

        p.move(to: CGPoint(x: rect.maxX - len, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX - cr, y: rect.minY))
        p.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.minY + cr),
                       control: CGPoint(x: rect.maxX, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY + len))

        p.move(to: CGPoint(x: rect.maxX, y: rect.maxY - len))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - cr))
        p.addQuadCurve(to: CGPoint(x: rect.maxX - cr, y: rect.maxY),
                       control: CGPoint(x: rect.maxX, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.maxX - len, y: rect.maxY))

        p.move(to: CGPoint(x: rect.minX + len, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX + cr, y: rect.maxY))
        p.addQuadCurve(to: CGPoint(x: rect.minX, y: rect.maxY - cr),
                       control: CGPoint(x: rect.minX, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY - len))

        return p
    }
}
