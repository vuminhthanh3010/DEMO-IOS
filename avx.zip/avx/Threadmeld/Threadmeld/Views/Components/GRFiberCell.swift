import SwiftUI

struct GRFiberCell: View {
    let value: Int
    let targetValue: Int
    let colorCount: Int
    let isSelected: Bool
    let isHintFrom: Bool
    let isHintTo: Bool
    let isHintMid: Bool
    let isValidTarget: Bool
    let cellSize: CGFloat
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("gr_color_blind") private var colorBlind = false

    private var baseColor: Color {
        let dark = colorScheme == .dark
        let palette = GRPalette.fiberColors(count: colorCount, dark: dark)
        return palette[value % palette.count]
    }

    private var matchesTarget: Bool { value == targetValue }

    private static let labels = ["A", "B", "C", "D"]

    var body: some View {
        let corner = cellSize * 0.22
        ZStack {
            RoundedRectangle(cornerRadius: corner)
                .fill(
                    LinearGradient(
                        colors: [baseColor, baseColor.opacity(0.50)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    )
                )
                .shadow(color: baseColor.opacity(isSelected ? 0.7 : 0.45),
                        radius: isSelected ? cellSize * 0.25 : cellSize * 0.12,
                        x: 0, y: cellSize * 0.08)

            RoundedRectangle(cornerRadius: corner)
                .fill(
                    RadialGradient(
                        colors: [Color.white.opacity(0.50), Color.clear],
                        center: UnitPoint(x: 0.25, y: 0.20),
                        startRadius: 0, endRadius: cellSize * 0.45
                    )
                )

            RoundedRectangle(cornerRadius: corner)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(0.15), Color.black.opacity(0.18)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ),
                    lineWidth: cellSize * 0.03
                )

            if colorBlind {
                Text(Self.labels[value % Self.labels.count])
                    .font(.system(size: cellSize * 0.35, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .shadow(color: Color.black.opacity(0.6), radius: 2, y: 1)
            }

            if matchesTarget {
                RoundedRectangle(cornerRadius: corner)
                    .stroke(Color(h: 130, s: 0.60, b: 0.75), lineWidth: cellSize * 0.05)
                RoundedRectangle(cornerRadius: corner)
                    .fill(Color(h: 130, s: 0.60, b: 0.75).opacity(0.12))
            }

            if isSelected {
                RoundedRectangle(cornerRadius: corner)
                    .stroke(Color.white, lineWidth: cellSize * 0.08)
                    .shadow(color: Color.white.opacity(0.9), radius: cellSize * 0.15)
            }

            if isValidTarget {
                RoundedRectangle(cornerRadius: corner)
                    .stroke(Color.white.opacity(0.7), lineWidth: cellSize * 0.04)
                    .shadow(color: Color.white.opacity(0.4), radius: cellSize * 0.12)

                RoundedRectangle(cornerRadius: corner * 1.3)
                    .stroke(Color.white.opacity(0.25), lineWidth: cellSize * 0.02)
                    .frame(width: cellSize * 1.12, height: cellSize * 1.12)
            }

            if isHintFrom || isHintTo {
                RoundedRectangle(cornerRadius: corner)
                    .stroke(Color.yellow, lineWidth: cellSize * 0.06)
                    .shadow(color: Color.yellow.opacity(0.5), radius: cellSize * 0.08)
            }

            if isHintMid {
                RoundedRectangle(cornerRadius: corner)
                    .stroke(Color.orange, lineWidth: cellSize * 0.05)
                    .shadow(color: Color.orange.opacity(0.4), radius: cellSize * 0.06)
            }
        }
        .frame(width: cellSize, height: cellSize)
        .scaleEffect(isSelected ? 1.08 : 1.0)
        .animation(.spring(response: 0.25, dampingFraction: 0.7), value: isSelected)
    }
}
