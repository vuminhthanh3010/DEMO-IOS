import SwiftUI
import UIKit

struct GRGlassPane: UIViewRepresentable {
    var style: UIBlurEffect.Style = .systemUltraThinMaterialDark

    func makeUIView(context: Context) -> UIVisualEffectView {
        let view = UIVisualEffectView(effect: UIBlurEffect(style: style))
        view.clipsToBounds = true
        return view
    }

    func updateUIView(_ view: UIVisualEffectView, context: Context) {
        view.effect = UIBlurEffect(style: style)
    }
}

struct GRGlassCard<Content: View>: View {
    let radius: CGFloat
    let tint: Double
    let border: Double
    let content: Content

    init(radius: CGFloat = 16, tint: Double = 0.06, border: Double = 0.12,
         @ViewBuilder content: () -> Content) {
        self.radius = radius
        self.tint = tint
        self.border = border
        self.content = content()
    }

    var body: some View {
        content
            .background(
                ZStack {
                    GRGlassPane(style: .systemUltraThinMaterialDark)
                    Color.white.opacity(tint)
                }
                .clipShape(RoundedRectangle(cornerRadius: radius))
            )
            .overlay(
                RoundedRectangle(cornerRadius: radius)
                    .stroke(Color.white.opacity(border), lineWidth: 1)
            )
    }
}
