import SwiftUI

struct GRDesignMiniature: View {
    let grid: GRFiberGrid
    let side: CGFloat
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("gr_color_blind") private var colorBlind = false

    private static let labels = ["A", "B", "C", "D"]

    var body: some View {
        let s = grid.size
        let gap: CGFloat = 1.5
        let cell = (side - CGFloat(s + 1) * gap) / CGFloat(s)
        let dark = colorScheme == .dark
        let palette = GRPalette.fiberColors(count: grid.colorCount, dark: dark)
        let cols = Array(repeating: GridItem(.fixed(cell), spacing: gap), count: s)

        VStack(spacing: 3) {
            Text("TARGET")
                .font(.system(size: side * 0.09, weight: .bold, design: .rounded))
                .tracking(1.5)
                .foregroundColor(.white.opacity(0.7))

            LazyVGrid(columns: cols, spacing: gap) {
                ForEach(0..<s * s, id: \.self) { idx in
                    ZStack {
                        RoundedRectangle(cornerRadius: cell * 0.2)
                            .fill(palette[grid.cells[idx] % palette.count])
                            .frame(width: cell, height: cell)
                        if colorBlind {
                            Text(Self.labels[grid.cells[idx] % Self.labels.count])
                                .font(.system(size: cell * 0.5, weight: .heavy, design: .rounded))
                                .foregroundColor(.white)
                                .shadow(color: Color.black.opacity(0.6), radius: 1, y: 0.5)
                        }
                    }
                }
            }
            .frame(width: side, height: side)
        }
        .padding(6)
        .background(
            ZStack {
                GRGlassPane(style: .systemUltraThinMaterialDark)
                Color.black.opacity(0.2)
            }
            .clipShape(RoundedRectangle(cornerRadius: 10))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.white.opacity(0.15), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(0.3), radius: 6, y: 3)
    }
}
