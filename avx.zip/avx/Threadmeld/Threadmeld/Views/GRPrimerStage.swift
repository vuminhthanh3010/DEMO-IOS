import SwiftUI

struct GRPrimerStage: View {
    let onBack: () -> Void

    private var unit: CGFloat { UIScreen.main.bounds.width }
    private var screenHeight: CGFloat { UIScreen.main.bounds.height }

    var body: some View {
        ZStack {
            GRBackdrop(tone: .primer)

            VStack(spacing: 0) {
                    HStack {
                        Button(action: onBack) {
                            HStack(spacing: unit * 0.012) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: unit * 0.03, weight: .semibold))
                                Text("Back")
                                    .font(.system(size: unit * 0.025, weight: .medium, design: .rounded))
                            }
                            .foregroundColor(.white.opacity(0.7))
                            .padding(.horizontal, unit * 0.02)
                            .padding(.vertical, unit * 0.012)
                            .background(Color.white.opacity(0.06))
                            .clipShape(Capsule())
                        }
                        Spacer()
                        Text("How to Play")
                            .font(.system(size: unit * 0.05, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        Spacer()
                        Color.clear.frame(width: unit * 0.15, height: unit * 0.09)
                    }
                    .padding(.horizontal, unit * 0.05)
                    .padding(.bottom, unit * 0.015)

                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .leading, spacing: 0) {
                            timelineStep(1, "Pick a cell",
                                         "Tap any colored cell to select it. A white border highlights your choice.",
                                         accent: Color(h: 35, s: 0.75, b: 0.85), isLast: false, unit: unit)
                            timelineStep(2, "Pick its partner",
                                         "Tap another cell exactly two steps away in the same row or column.",
                                         accent: Color(h: 215, s: 0.65, b: 0.75), isLast: false, unit: unit)
                            timelineStep(3, "Watch the middle",
                                         "The two cells swap colors. The cell caught between them shifts its color based on the difference.",
                                         accent: Color(h: 350, s: 0.60, b: 0.80), isLast: false, unit: unit)
                            timelineStep(4, "Match the target",
                                         "Rearrange all cells until they match the small target pattern. Matched cells glow green.",
                                         accent: Color(h: 130, s: 0.55, b: 0.70), isLast: true, unit: unit)

                            Spacer().frame(height: unit * 0.03)

                            infoSection("Modes", icon: "square.stack.fill",
                                        accent: Color(h: 35, s: 0.70, b: 0.80),
                                        "Tapestry: take as many moves as you want \u{2014} fewer moves earn more stars. Shuttle: solve in exactly par moves. One extra move means failure.",
                                        unit: unit)
                            infoSection("Hints", icon: "lightbulb.fill",
                                        accent: Color(h: 45, s: 0.80, b: 0.90),
                                        "Tap the lightbulb to see the next optimal move highlighted in yellow. Limited per game \u{2014} use wisely.",
                                        unit: unit)
                            infoSection("Daily Puzzle", icon: "calendar",
                                        accent: Color(h: 15, s: 0.60, b: 0.80),
                                        "A fresh puzzle every day, the same for all players. Complete daily puzzles to build your streak and unlock badges.",
                                        unit: unit)
                            infoSection("Valid Moves", icon: "scope",
                                        accent: Color(h: 175, s: 0.55, b: 0.70),
                                        "When you select a cell, all valid target positions glow white. This helps you see which swaps are possible.",
                                        unit: unit)
                            infoSection("Tips", icon: "wand.and.stars",
                                        accent: Color(h: 280, s: 0.50, b: 0.70),
                                        "Swapping two cells of the same color leaves the middle cell unchanged. Use Undo freely \u{2014} it has no limit. Tap the target preview to see it enlarged.",
                                        unit: unit)
                        }
                        .padding(.horizontal, unit * 0.05)
                        .padding(.bottom, unit * 0.06)
                        .padding(.top, unit * 0.02)
                    }
                }
                .frame(width: unit, height: screenHeight)
            }
        }
    private func timelineStep(_ number: Int, _ title: String, _ desc: String,
                              accent: Color, isLast: Bool, unit: CGFloat) -> some View {
        HStack(alignment: .top, spacing: unit * 0.025) {
            VStack(spacing: 0) {
                ZStack {
                    Circle()
                        .fill(accent)
                        .frame(width: unit * 0.075, height: unit * 0.075)
                        .shadow(color: accent.opacity(0.3), radius: 8, y: 3)
                    Text("\(number)")
                        .font(.system(size: unit * 0.032, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                }
                if !isLast {
                    Rectangle()
                        .fill(
                            LinearGradient(
                                colors: [accent.opacity(0.4), accent.opacity(0.08)],
                                startPoint: .top, endPoint: .bottom
                            )
                        )
                        .frame(width: 2)
                        .frame(maxHeight: .infinity)
                }
            }
            .frame(width: unit * 0.075)

            VStack(alignment: .leading, spacing: unit * 0.006) {
                Text(title)
                    .font(.system(size: unit * 0.032, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text(desc)
                    .font(.system(size: unit * 0.024, design: .rounded))
                    .foregroundColor(.white.opacity(0.6))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.bottom, unit * 0.025)

            Spacer()
        }
    }

    private func infoSection(_ title: String, icon: String, accent: Color,
                             _ text: String, unit: CGFloat) -> some View {
        HStack(alignment: .top, spacing: 0) {
            Rectangle()
                .fill(accent)
                .frame(width: 3)
                .cornerRadius(1.5)

            VStack(alignment: .leading, spacing: unit * 0.008) {
                HStack(spacing: unit * 0.012) {
                    Image(systemName: icon)
                        .font(.system(size: unit * 0.026))
                        .foregroundColor(accent)
                    Text(title)
                        .font(.system(size: unit * 0.03, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                }
                Text(text)
                    .font(.system(size: unit * 0.024, design: .rounded))
                    .foregroundColor(.white.opacity(0.55))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.leading, unit * 0.025)
            .padding(.vertical, unit * 0.015)
        }
        .padding(.horizontal, unit * 0.015)
        .padding(.vertical, unit * 0.005)
        .background(
            RoundedRectangle(cornerRadius: unit * 0.02)
                .fill(accent.opacity(0.05))
        )
        .padding(.bottom, unit * 0.01)
    }
}
