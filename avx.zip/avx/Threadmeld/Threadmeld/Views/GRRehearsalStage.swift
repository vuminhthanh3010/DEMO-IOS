#if DEBUG
import SwiftUI

struct GRRehearsalStage: View {
    struct GRFrameSpec: Identifiable {
        let id: String, w: CGFloat, h: CGFloat
    }
    private static let specs = [
        GRFrameSpec(id: "SE 375\u{00d7}667",  w: 375, h: 667),
        GRFrameSpec(id: "Std 393\u{00d7}852", w: 393, h: 852),
        GRFrameSpec(id: "Max 440\u{00d7}956", w: 440, h: 956)
    ]
    private static let stages = ["Splash", "Home", "Game", "Tally", "Options", "Primer"]

    @State private var spec = 0
    @State private var stage = 1

    var body: some View {
        VStack(spacing: 8) {
            picker(Self.specs.map(\.id), selection: $spec)
            picker(Self.stages, selection: $stage)

            GeometryReader { outer in
                let s = Self.specs[spec]
                let k = min(outer.size.width / s.w, outer.size.height / s.h) * 0.96
                content(for: stage)
                    .frame(width: s.w, height: s.h)
                    .clipped()
                    .border(Color.red.opacity(0.6))
                    .scaleEffect(k, anchor: .center)
                    .frame(width: s.w * k, height: s.h * k)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .padding(8)
    }

    private func picker(_ items: [String], selection: Binding<Int>) -> some View {
        HStack(spacing: 6) {
            ForEach(items.indices, id: \.self) { i in
                Button(items[i]) { selection.wrappedValue = i }
                    .font(.system(size: 11, weight: .semibold))
                    .padding(.horizontal, 8).padding(.vertical, 5)
                    .background(selection.wrappedValue == i ? Color.accentColor : Color.gray.opacity(0.25))
                    .foregroundColor(selection.wrappedValue == i ? .white : .primary)
                    .cornerRadius(6)
            }
        }
    }

    @ViewBuilder private func content(for index: Int) -> some View {
        switch index {
        case 0: GROpeningStage { }
        case 1: GRHearthStage(
                    ledger: GRYarnLedger(),
                    onStart: { _, _ in }, onContinue: {},
                    onDaily: {},
                    onSettings: {}, onGuide: {}
                )
        case 2: GRLoomStage(
                    conductor: GRLoomConductor(mode: .tapestry, tier: .spool),
                    onFinish: {}, onHome: {}
                )
        case 3: GRTallyStage(
                    conductor: GRLoomConductor(mode: .tapestry, tier: .spool),
                    onHome: {}, onNewGame: {}
                )
        case 4: GRBobbinStage(onBack: {}, ledger: GRYarnLedger())
        default: GRPrimerStage(onBack: {})
        }
    }
}
#endif
