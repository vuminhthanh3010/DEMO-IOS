import SwiftUI

struct GROpeningStage: View {
    let onDone: () -> Void
    @State private var linesOut = false
    @State private var glowPulse = false
    @State private var titleIn = false
    @State private var subtitleIn = false
    @State private var ringExpand = false

    var body: some View {
        ZStack {
            GRBackdrop(tone: .hearth)

            Circle()
                .stroke(GRPalette.accentGold.opacity(ringExpand ? 0 : 0.3), lineWidth: 2)
                .frame(width: ringExpand ? 300 : 40, height: ringExpand ? 300 : 40)
                .opacity(ringExpand ? 0 : 1)

            Circle()
                .fill(RadialGradient(
                    colors: [GRPalette.accentGold.opacity(0.50), Color.clear],
                    center: .center, startRadius: 0, endRadius: 90
                ))
                .frame(width: 180, height: 180)
                .scaleEffect(glowPulse ? 1.5 : 0.2)
                .opacity(glowPulse ? 0.75 : 0)

            ForEach(0..<8, id: \.self) { i in
                Capsule()
                    .fill(LinearGradient(
                        colors: [threadColor(i).opacity(0), threadColor(i), threadColor(i).opacity(0)],
                        startPoint: .leading, endPoint: .trailing
                    ))
                    .frame(width: linesOut ? 200 : 0, height: 2.5)
                    .rotationEffect(.degrees(Double(i) * 22.5))
                    .opacity(linesOut ? 1 : 0)
            }

            Circle()
                .fill(Color.white.opacity(0.9))
                .frame(width: 6, height: 6)
                .scaleEffect(linesOut ? 1 : 0)

            VStack(spacing: 10) {
                Spacer()
                Spacer()
                Spacer()
                Text("THREADMELD")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .tracking(6)
                    .foregroundColor(.white)
                    .opacity(titleIn ? 1 : 0)
                    .offset(y: titleIn ? 0 : 18)
                Text("Color Grid Puzzle")
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.45))
                    .opacity(subtitleIn ? 1 : 0)
                Spacer()
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.9)) { linesOut = true }
            withAnimation(.easeInOut(duration: 1.0).delay(0.15)) { glowPulse = true }
            withAnimation(.easeOut(duration: 1.2).delay(0.05)) { ringExpand = true }
            withAnimation(.easeOut(duration: 0.6).delay(0.7)) { titleIn = true }
            withAnimation(.easeOut(duration: 0.5).delay(0.9)) { subtitleIn = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { onDone() }
        }
    }

    private func threadColor(_ i: Int) -> Color {
        let c: [Color] = [
            Color(h: 38, s: 0.80, b: 0.90),
            Color(h: 215, s: 0.65, b: 0.75),
            Color(h: 350, s: 0.60, b: 0.80),
            Color(h: 130, s: 0.55, b: 0.70),
            Color(h: 38, s: 0.80, b: 0.90),
            Color(h: 215, s: 0.65, b: 0.75),
            Color(h: 350, s: 0.60, b: 0.80),
            Color(h: 130, s: 0.55, b: 0.70)
        ]
        return c[i % c.count]
    }
}
