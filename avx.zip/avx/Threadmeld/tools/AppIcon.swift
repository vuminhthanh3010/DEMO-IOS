import AppKit

let size: CGFloat = 1024
let image = NSImage(size: NSSize(width: size, height: size))
image.lockFocus()
guard let ctx = NSGraphicsContext.current?.cgContext else {
    fatalError("No CGContext")
}

// Background: deep indigo to midnight gradient
let bgColors: [CGFloat] = [
    30/255, 20/255, 60/255, 1,
    15/255, 10/255, 35/255, 1
]
let bgSpace = CGColorSpaceCreateDeviceRGB()
let bgGrad = CGGradient(colorSpace: bgSpace, colorComponents: bgColors, locations: [0, 1], count: 2)!
ctx.drawLinearGradient(bgGrad, start: CGPoint(x: 0, y: size), end: CGPoint(x: size, y: 0), options: [])

// Subtle radial glow in center
let glowColors: [CGFloat] = [
    80/255, 50/255, 120/255, 0.3,
    80/255, 50/255, 120/255, 0.0
]
let glowGrad = CGGradient(colorSpace: bgSpace, colorComponents: glowColors, locations: [0, 1], count: 2)!
ctx.drawRadialGradient(glowGrad, startCenter: CGPoint(x: size*0.5, y: size*0.5), startRadius: 0,
                       endCenter: CGPoint(x: size*0.5, y: size*0.5), endRadius: size*0.45, options: [])

func drawThread(points: [(CGFloat,CGFloat)], color1: [CGFloat], color2: [CGFloat], width: CGFloat) {
    let path = CGMutablePath()
    guard points.count >= 2 else { return }
    path.move(to: CGPoint(x: points[0].0, y: points[0].1))
    for i in 1..<points.count {
        let prev = points[i-1]
        let cur = points[i]
        let cx1 = prev.0 + (cur.0 - prev.0) * 0.5
        let cy1 = prev.1
        let cx2 = prev.0 + (cur.0 - prev.0) * 0.5
        let cy2 = cur.1
        path.addCurve(to: CGPoint(x: cur.0, y: cur.1),
                      control1: CGPoint(x: cx1, y: cy1),
                      control2: CGPoint(x: cx2, y: cy2))
    }

    let threadColors = color1 + color2
    let tGrad = CGGradient(colorSpace: bgSpace, colorComponents: threadColors, locations: [0, 1], count: 2)!

    ctx.saveGState()
    ctx.addPath(path)
    ctx.setLineWidth(width)
    ctx.setLineCap(.round)
    ctx.setLineJoin(.round)
    ctx.replacePathWithStrokedPath()
    ctx.clip()
    let bbox = path.boundingBox
    ctx.drawLinearGradient(tGrad,
                           start: CGPoint(x: bbox.minX, y: bbox.minY),
                           end: CGPoint(x: bbox.maxX, y: bbox.maxY),
                           options: [])
    ctx.restoreGState()

    // Specular highlight
    ctx.saveGState()
    let highlightPath = CGMutablePath()
    highlightPath.move(to: CGPoint(x: points[0].0, y: points[0].1))
    for i in 1..<points.count {
        let prev = points[i-1]
        let cur = points[i]
        let cx1 = prev.0 + (cur.0 - prev.0) * 0.5
        let cy1 = prev.1
        let cx2 = prev.0 + (cur.0 - prev.0) * 0.5
        let cy2 = cur.1
        highlightPath.addCurve(to: CGPoint(x: cur.0, y: cur.1),
                               control1: CGPoint(x: cx1, y: cy1),
                               control2: CGPoint(x: cx2, y: cy2))
    }
    ctx.addPath(highlightPath)
    ctx.setLineWidth(width * 0.25)
    ctx.setLineCap(.round)
    ctx.setStrokeColor(CGColor(red: 1, green: 1, blue: 1, alpha: 0.25))
    ctx.strokePath()
    ctx.restoreGState()
}

// Thread 1: warm amber — diagonal flowing down-left to up-right
let t1: [(CGFloat,CGFloat)] = [
    (120, 200), (300, 500), (500, 350), (700, 650), (900, 400)
]
drawThread(points: t1,
           color1: [255/255, 180/255, 60/255, 1],
           color2: [220/255, 120/255, 30/255, 1],
           width: 48)

// Thread 2: soft teal — flowing through center
let t2: [(CGFloat,CGFloat)] = [
    (150, 800), (350, 550), (550, 700), (750, 350), (880, 600)
]
drawThread(points: t2,
           color1: [80/255, 200/255, 180/255, 1],
           color2: [40/255, 150/255, 140/255, 1],
           width: 44)

// Thread 3: lavender — crossing both
let t3: [(CGFloat,CGFloat)] = [
    (200, 900), (400, 300), (600, 600), (800, 200)
]
drawThread(points: t3,
           color1: [180/255, 140/255, 220/255, 1],
           color2: [140/255, 100/255, 190/255, 1],
           width: 40)

// Intersection nodes (small glowing circles at crossings)
let nodes: [(CGFloat, CGFloat)] = [
    (350, 470), (530, 520), (700, 400), (550, 650)
]
for (nx, ny) in nodes {
    let r: CGFloat = 18
    let nodeColors: [CGFloat] = [
        1, 1, 1, 0.6,
        1, 1, 1, 0.0
    ]
    let nodeGrad = CGGradient(colorSpace: bgSpace, colorComponents: nodeColors, locations: [0, 1], count: 2)!
    ctx.drawRadialGradient(nodeGrad,
                           startCenter: CGPoint(x: nx, y: ny), startRadius: 0,
                           endCenter: CGPoint(x: nx, y: ny), endRadius: r * 2.5,
                           options: [])
    ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 0.8))
    ctx.fillEllipse(in: CGRect(x: nx - r, y: ny - r, width: r*2, height: r*2))
}

image.unlockFocus()

guard let tiff = image.tiffRepresentation,
      let bitmap = NSBitmapImageRep(data: tiff),
      let png = bitmap.representation(using: .png, properties: [:]) else {
    fatalError("PNG conversion failed")
}

let path = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "/tmp/icon.png"
try! png.write(to: URL(fileURLWithPath: path))
print("Icon saved to \(path)")
