import Foundation

@main
struct Harness {
    static func main() {
        var runs = 0, solvable = 0, replayFailed = 0
        var moveCounts: [Int] = []

        for mode in GRWeaveMode.allCases {
            for tier in GRSpoolTier.allCases {
                for seed in 1...200 {
                    let made = GRWarpForge.compose(mode: mode, tier: tier, seed: UInt64(seed))
                    runs += 1

                    let path = made.solution
                    if path.isEmpty {
                        print("EMPTY SOLUTION mode=\(mode) tier=\(tier) seed=\(seed)")
                        continue
                    }
                    solvable += 1
                    moveCounts.append(path.count)

                    var work = made.board
                    for step in path {
                        work.apply(step)
                    }
                    if !work.matches(made.target) {
                        replayFailed += 1
                        print("REPLAY MISMATCH mode=\(mode) tier=\(tier) seed=\(seed)")
                        print("  got:    \(work.cells)")
                        print("  target: \(made.target.cells)")
                    }
                }
            }
        }

        let lo = moveCounts.min() ?? 0
        let hi = moveCounts.max() ?? 0
        let avg = moveCounts.isEmpty ? 0 : moveCounts.reduce(0, +) / moveCounts.count
        print("runs=\(runs) solvable=\(solvable) replayFailed=\(replayFailed)")
        print("moves min=\(lo) avg=\(avg) max=\(hi)")

        guard solvable == runs, replayFailed == 0 else {
            print("HARNESS FAIL")
            exit(1)
        }
        print("HARNESS PASS")
    }
}
