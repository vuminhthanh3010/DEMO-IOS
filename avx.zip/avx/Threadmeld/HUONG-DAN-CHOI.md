# Hướng dẫn chơi Threadmeld

## Mục tiêu

Sắp xếp bảng màu sao cho khớp với hình mẫu nhỏ ở góc trên bên phải.

## Cách chơi

1. **Chạm vào một ô** — ô được chọn sẽ có viền trắng.
2. **Chạm vào ô thứ hai** cách ô đầu đúng 2 bước (cùng hàng hoặc cùng cột).
3. Hai ô hoán đổi màu. Ô ở giữa sẽ **dịch chuyển màu** dựa trên hiệu số giữa hai ô vừa đổi.
4. Lặp lại cho đến khi bảng khớp hình mẫu. Ô đã đúng vị trí sẽ phát sáng xanh.

## Chế độ chơi

- **Tapestry**: Không giới hạn số nước. Càng ít nước càng nhiều sao (tối đa 3 sao).
- **Shuttle**: Phải giải đúng bằng số nước tối thiểu. Thêm một nước là thua.

## Độ khó

| Độ khó | Bảng  | Số màu | Số nước |
|--------|-------|--------|---------|
| Spool  | 4 × 4 | 3      | 4 – 6   |
| Loom   | 5 × 5 | 3      | 8 – 12  |
| Forge  | 6 × 6 | 4      | 12 – 16 |

## Công cụ hỗ trợ

- **Hint** (bóng đèn): Hiện nước đi tối ưu tiếp theo. Có giới hạn số lần dùng.
- **Undo** (mũi tên quay lại): Hoàn tác nước đi gần nhất. Dùng không giới hạn.
- **Pause**: Tạm dừng, đồng hồ dừng lại.
- **New**: Tạo bài mới cùng chế độ và độ khó.

## Mẹo

- Đổi hai ô cùng màu sẽ không thay đổi ô giữa — dùng thủ thuật này để di chuyển mà không gây xáo trộn.
- Bắt đầu từ độ khó Spool để quen cơ chế, rồi tăng dần.
- Dùng Hint khi bí để hiểu cách giải tối ưu.

## Thử thách hàng ngày

Mỗi ngày có một bài mới (Tapestry · Loom · 5×5). Hoàn thành liên tiếp để tăng chuỗi ngày và mở khoá huy hiệu.

## Thành tựu

11 huy hiệu: First Weave, Apprentice, Master, Grand, On Fire, Unstoppable, Legendary, Forgemaster, Completionist, Weekly, Monthly. Hoàn thành các mốc khác nhau để mở khoá.

## Cài đặt

- Bật/tắt rung phản hồi.
- Ẩn/hiện đồng hồ đếm giờ.
- Chế độ mù màu: hiện chữ cái trên ô để dễ phân biệt.
- Chọn bảng màu (Amber, Indigo, Sage).
- Xoá toàn bộ tiến trình nếu muốn chơi lại từ đầu.
