# App Store copy

## Name
Cinderwake

## Subtitle (≤30 chars)
Hex hearth ember puzzle

## Promotional text
Two tap flavours, one drifting rune, one target to chase. A calm little
thinker for a coffee break.

## Description

Cinderwake is a small hex-hearth puzzle. Every cell on the board holds an
ember. Tap one below the ceiling and its glow rises by one. Tap one already
lit to the top and it bursts — dropping to nothing while feeding its
neighbours one glow each.

There are two ways to win: **Match** asks you to shape the board into a
random target pattern; **Beacon** asks for every cell to settle at exactly
one glow. Three difficulties open up more of the board and add a wandering
Chill rune that takes one cell out of play each turn.

No timers hurrying you along. No accounts. No ads. No in-app purchases.
Just a hearth and a handful of embers.

### Features
- Two modes: Match and Beacon
- Three difficulties: Ember, Coal, Blaze
- Hint, undo and replay in every round
- Personal streak, best time and best move count per combo
- Six unlockable achievements
- Three colour palettes (Ember, Ash, Copper), light and dark aware
- Haptic feedback you can turn off
- Rehearsal harness for developers to preview screens at three device sizes

## Keywords (≤100 chars, comma separated)
puzzle,hex,brain,solitaire,logic,ember,zen,strategy,relax,solo

## What's new (first release)
First launch of Cinderwake.

## Support URL
https://cinderwake.example.com/support   *(placeholder — replace before submission)*

## Privacy policy URL
https://cinderwake.example.com/privacy   *(placeholder — replace before submission)*

## Age rating
4+

## Data collection
None. Cinderwake does not track users, has no analytics, no advertising SDKs
and no in-app purchases. All progress is stored on device.

## Marketing URL
(optional — leave blank at launch)
