# Cinderwake

A small hex-hearth puzzle for iPhone. Tap embers to nudge heat around a
hexagonal board until the pattern matches a target — while a blue "chill" rune
walks the outer ring and takes cells out of play as it goes.

## The rules

The board is a hexagon of 7 or 19 cells. Every cell holds an ember whose glow
runs from 0 to 3 dots.

- **Kindle** — tap a cell whose glow is below 3 and it gains one dot.
- **Burst** — tap a cell already at 3 and it drops to 0; each in-board
  neighbour that isn't already at 3 gains one dot.
- **Chill rune** — on Coal and Blaze rounds a blue snowflake walks around the
  perimeter one (Coal) or two (Blaze) cells per turn. The cell it stands on
  cannot be tapped that turn.
- **Win** — reach the target pattern (shown in the top-right chip). In Match
  mode the target is a randomly-shaped pattern; in Beacon mode every cell
  must settle at exactly one glow.

## Modes and difficulties

- **Match** — random target pattern, hardest to plan.
- **Beacon** — every cell must land at exactly 1 glow.

Difficulties: **Ember** (7 cells, no chill), **Coal** (19 cells, one-step
chill drift), **Blaze** (19 cells, two-step chill).

## Building

Open `Cinderwake.xcodeproj` in Xcode 15 or later.  Deployment target is
iOS 14.0.  There are no external dependencies — everything is SwiftUI /
Foundation / Combine / UIKit / StoreKit.

Build and run on **iPhone 17 Pro** (the workshop's fixed simulator target).

## Structure

```
Cinderwake/
├── Cinderwake/
│   ├── Models/           pure game logic, no SwiftUI imports
│   ├── ViewModels/       DMHearthConductor
│   ├── Systems/          palette, blur canvas, persistence, share, rate, trace, autopilot
│   ├── Views/            six screens + rehearsal harness (DEBUG)
│   │   └── Components/   hex face, board canvas, anvil CTA, bellows handle, target chip, progress
│   └── Assets.xcassets
├── tools/
│   ├── Harness.swift     offline logic harness (200 trials × 2 modes × 3 difficulties)
│   └── AppIcon.swift     CoreGraphics icon generator
├── README.md
├── Description.md        App Store copy
└── HUONG-DAN-CHOI.md     Vietnamese play guide
```

## QA

- `scripts/logic-harness.sh Cinderwake` — must print `HARNESS PASS`.
- `scripts/qa-sim.sh Cinderwake --args "-DMUnattended -DMMode <mode> -DMDifficulty <diff>"` —
  autopilot must end with `[autoplay] WIN` on every combination.
- `scripts/qa-sim.sh Cinderwake --args "-DMRehearse"` — rehearsal frames for
  SE / iPhone 17 / iPhone 17 Pro Max on every screen.

## Privacy

Cinderwake does not collect data. There are no accounts, no ads, no in-app
purchases and no network calls beyond the App Store "rate this app" link.
