import Foundation
import AppKit
import CoreGraphics

// Renders a 1024×1024 Cinderwake app icon and writes PNG to argv[1].
// Composition:
//   • Deep radial red-black background with a subtle vertical warm gradient.
//   • Seven hexagon plates arranged as a hex flower (1 centre + 6 ring cells).
//   • Centre hex is a molten gold pip; ring hexes fade ember → crimson going out.
//   • A blue "chill" arc curls around one outer hex — a hint of the game's rune.
//   • Warm inner shadow + glow beneath the cluster for depth. No text.

let outPath = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "/tmp/icon.png"
let side: CGFloat = 1024

guard let ctx = CGContext(
    data: nil, width: Int(side), height: Int(side),
    bitsPerComponent: 8, bytesPerRow: 0,
    space: CGColorSpaceCreateDeviceRGB(),
    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
    print("Cannot make context"); exit(1)
}

// Y-flip so vector math matches CG.
ctx.translateBy(x: 0, y: side); ctx.scaleBy(x: 1, y: -1)

func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> CGColor {
    CGColor(colorSpace: CGColorSpaceCreateDeviceRGB(), components: [r, g, b, a])!
}

// Background — deep red-black radial
let bgColors = [
    rgb(0.28, 0.08, 0.04),
    rgb(0.07, 0.02, 0.02),
    rgb(0.02, 0.01, 0.01)
] as CFArray
let bgLocs: [CGFloat] = [0, 0.55, 1]
if let bgGrad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: bgColors, locations: bgLocs) {
    ctx.drawRadialGradient(bgGrad,
                           startCenter: CGPoint(x: side * 0.45, y: side * 0.55),
                           startRadius: 0,
                           endCenter: CGPoint(x: side * 0.5, y: side * 0.5),
                           endRadius: side * 0.8,
                           options: [])
}

// A soft warm halo behind the cluster
let haloColors = [rgb(0.95, 0.5, 0.15, 0.6), rgb(0.7, 0.15, 0.05, 0.05), rgb(0, 0, 0, 0)] as CFArray
if let hg = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: haloColors, locations: [0, 0.6, 1]) {
    ctx.drawRadialGradient(hg,
                           startCenter: CGPoint(x: side * 0.5, y: side * 0.5),
                           startRadius: 0,
                           endCenter: CGPoint(x: side * 0.5, y: side * 0.5),
                           endRadius: side * 0.5,
                           options: [])
}

// Draw seven hexagons
func hexPath(cx: CGFloat, cy: CGFloat, size: CGFloat) -> CGPath {
    let p = CGMutablePath()
    let dx = size * CGFloat(sqrt(3.0)) / 2
    let dy = size / 2
    p.move(to: CGPoint(x: cx, y: cy + size))
    p.addLine(to: CGPoint(x: cx + dx, y: cy + dy))
    p.addLine(to: CGPoint(x: cx + dx, y: cy - dy))
    p.addLine(to: CGPoint(x: cx, y: cy - size))
    p.addLine(to: CGPoint(x: cx - dx, y: cy - dy))
    p.addLine(to: CGPoint(x: cx - dx, y: cy + dy))
    p.closeSubpath()
    return p
}

let hexSize: CGFloat = side * 0.135
let step = hexSize * CGFloat(sqrt(3.0))
let cx = side * 0.5
let cy = side * 0.5

// Ring positions (axial, pointy-top pixel offsets)
let ringOffsets: [(dx: CGFloat, dy: CGFloat)] = [
    (0, hexSize * 1.5 * 1),          // top? we use screen-up = positive y
    (step * 0.5, hexSize * 0.75),
    (step * 0.5, -hexSize * 0.75),
    (0, -hexSize * 1.5),
    (-step * 0.5, -hexSize * 0.75),
    (-step * 0.5, hexSize * 0.75),
]
_ = ringOffsets

// Actually use standard axial coord for pointy-top hex neighbors
let neighbors: [(q: Int, r: Int)] = [
    (+1, 0), (+1, -1), (0, -1), (-1, 0), (-1, +1), (0, +1)
]

func pixel(q: Int, r: Int) -> CGPoint {
    let x = hexSize * CGFloat(sqrt(3.0)) * (CGFloat(q) + CGFloat(r) / 2)
    let y = hexSize * 1.5 * CGFloat(r)
    return CGPoint(x: cx + x, y: cy + y)
}

// Ring cell colours (ember gradient from bright to deep)
let ringColors: [(top: CGColor, bot: CGColor)] = [
    (rgb(0.98, 0.62, 0.22), rgb(0.72, 0.22, 0.08)),
    (rgb(0.96, 0.55, 0.18), rgb(0.60, 0.18, 0.06)),
    (rgb(0.92, 0.48, 0.14), rgb(0.55, 0.14, 0.04)),
    (rgb(0.86, 0.36, 0.10), rgb(0.48, 0.10, 0.03)),
    (rgb(0.90, 0.42, 0.14), rgb(0.55, 0.12, 0.04)),
    (rgb(0.94, 0.50, 0.16), rgb(0.62, 0.18, 0.06)),
]

// Shadow behind cluster
ctx.saveGState()
ctx.setShadow(offset: CGSize(width: 0, height: -24), blur: 40,
              color: rgb(0.3, 0.05, 0, 0.75))
let clusterHalo = hexPath(cx: cx, cy: cy, size: hexSize * 3.2)
ctx.addPath(clusterHalo)
ctx.setFillColor(rgb(0, 0, 0, 0.001))
ctx.fillPath()
ctx.restoreGState()

// Draw ring cells first (6 outer)
for (i, n) in neighbors.enumerated() {
    let pt = pixel(q: n.q, r: n.r)
    let path = hexPath(cx: pt.x, cy: pt.y, size: hexSize * 0.92)
    ctx.saveGState()
    ctx.addPath(path)
    ctx.clip()
    let colors = [ringColors[i].top, ringColors[i].bot] as CFArray
    let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1])!
    ctx.drawLinearGradient(grad,
                           start: CGPoint(x: pt.x, y: pt.y + hexSize),
                           end: CGPoint(x: pt.x, y: pt.y - hexSize),
                           options: [])
    ctx.restoreGState()

    // Rim
    ctx.addPath(hexPath(cx: pt.x, cy: pt.y, size: hexSize * 0.92))
    ctx.setStrokeColor(rgb(0.35, 0.14, 0.06, 0.9))
    ctx.setLineWidth(4)
    ctx.strokePath()
}

// Centre hex — molten gold
let centre = CGPoint(x: cx, y: cy)
let centrePath = hexPath(cx: centre.x, cy: centre.y, size: hexSize * 0.98)
ctx.saveGState()
ctx.addPath(centrePath); ctx.clip()
let goldColors = [
    rgb(1.00, 0.95, 0.75),
    rgb(1.00, 0.75, 0.30),
    rgb(0.90, 0.40, 0.12)
] as CFArray
let goldGrad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: goldColors, locations: [0, 0.55, 1])!
ctx.drawRadialGradient(goldGrad,
                       startCenter: CGPoint(x: cx, y: cy + hexSize * 0.15),
                       startRadius: 0,
                       endCenter: centre,
                       endRadius: hexSize,
                       options: [])
ctx.restoreGState()
// Rim on centre
ctx.addPath(hexPath(cx: cx, cy: cy, size: hexSize * 0.98))
ctx.setStrokeColor(rgb(0.7, 0.30, 0.10, 1))
ctx.setLineWidth(5)
ctx.strokePath()

// Chill rune — a small blue arc around one outer hex (top-right neighbor)
let chillCentre = pixel(q: 1, r: -1)
ctx.saveGState()
ctx.setStrokeColor(rgb(0.55, 0.85, 1.0, 0.95))
ctx.setLineWidth(10)
ctx.setLineCap(.round)
let arcRadius = hexSize * 1.15
let arcPath = CGMutablePath()
arcPath.addArc(center: chillCentre,
               radius: arcRadius,
               startAngle: .pi * 0.15,
               endAngle: .pi * 1.05,
               clockwise: false)
ctx.addPath(arcPath)
ctx.strokePath()
// Inner white glow along the arc
ctx.setStrokeColor(rgb(0.85, 0.95, 1.0, 0.7))
ctx.setLineWidth(4)
ctx.addPath(arcPath)
ctx.strokePath()
// Two little snow dots at either end
ctx.setFillColor(rgb(0.95, 0.98, 1.0, 0.95))
let arcStart = CGPoint(x: chillCentre.x + arcRadius * cos(.pi * 0.15),
                       y: chillCentre.y + arcRadius * sin(.pi * 0.15))
let arcEnd = CGPoint(x: chillCentre.x + arcRadius * cos(.pi * 1.05),
                     y: chillCentre.y + arcRadius * sin(.pi * 1.05))
ctx.fillEllipse(in: CGRect(x: arcStart.x - 10, y: arcStart.y - 10, width: 20, height: 20))
ctx.fillEllipse(in: CGRect(x: arcEnd.x - 10, y: arcEnd.y - 10, width: 20, height: 20))
ctx.restoreGState()

// Final vignette
ctx.setBlendMode(.multiply)
let vig = [rgb(1, 1, 1, 1), rgb(0.1, 0.05, 0.03, 1)] as CFArray
if let vg = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: vig, locations: [0.6, 1]) {
    ctx.drawRadialGradient(vg, startCenter: CGPoint(x: cx, y: cy), startRadius: side * 0.25,
                           endCenter: CGPoint(x: cx, y: cy), endRadius: side * 0.7, options: [])
}
ctx.setBlendMode(.normal)

// Encode PNG
guard let img = ctx.makeImage() else { print("Cannot make image"); exit(1) }
let rep = NSBitmapImageRep(cgImage: img)
guard let data = rep.representation(using: .png, properties: [:]) else {
    print("Cannot encode PNG"); exit(1)
}
try? data.write(to: URL(fileURLWithPath: outPath))
print("wrote \(outPath) (\(data.count) bytes)")
