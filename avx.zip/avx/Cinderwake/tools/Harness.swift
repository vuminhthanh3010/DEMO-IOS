import Foundation

@main
struct Harness {
    static let TRIALS_PER_COMBO = 200
    static var fatalErrors: [String] = []
    static var summaries: [String] = []

    static func fail(_ msg: String) { fatalErrors.append(msg) }

    static func check(_ mode: DMMode, _ diff: DMDifficulty, trials: Int) {
        var minLen = Int.max
        var maxLen = 0
        var sumLen = 0
        for i in 0..<trials {
            let seed: UInt64 = UInt64(i) &* 0x9E37_79B1
                &+ (UInt64(mode.rawValue) << 32)
                &+ UInt64(diff.rawValue)
            let puzzle = DMEmberForge.forge(mode: mode, difficulty: diff, seed: seed)

            if puzzle.initialBoard == puzzle.target {
                fail("\(mode.title)/\(diff.title) trial \(i): initialBoard == target (trivial puzzle)")
                continue
            }
            if puzzle.initialSolution.isEmpty {
                fail("\(mode.title)/\(diff.title) trial \(i): empty solution chain")
                continue
            }
            guard let played = DMSolver.playback(chain: puzzle.initialSolution,
                                                  on: puzzle.initialBoard,
                                                  rune: puzzle.initialRune) else {
                fail("\(mode.title)/\(diff.title) trial \(i): solution playback tripped chill / invalid tap")
                continue
            }
            if played.board != puzzle.target {
                fail("\(mode.title)/\(diff.title) trial \(i): playback did NOT reach target")
                continue
            }
            let n = puzzle.initialSolution.count
            if !(3...25).contains(n) {
                fail("\(mode.title)/\(diff.title) trial \(i): out-of-range plan length \(n)")
            }
            var b = puzzle.initialBoard
            var rn = puzzle.initialRune
            var brokenAt = -1
            for (k, step) in puzzle.initialSolution.enumerated() {
                if rn.current == step {
                    fail("\(mode.title)/\(diff.title) trial \(i) step \(k): chain hits chill at \(step)")
                    brokenAt = k
                    break
                }
                guard let next = b.applyingTap(at: step) else {
                    fail("\(mode.title)/\(diff.title) trial \(i) step \(k): tap returned nil")
                    brokenAt = k
                    break
                }
                for c in next.cells {
                    let lv = next.level(at: c)
                    if lv < 0 || lv > DMHearth.maxLevel {
                        fail("\(mode.title)/\(diff.title) trial \(i) step \(k): level out of range \(lv)")
                        brokenAt = k
                        break
                    }
                }
                b = next
                rn.advance()
            }
            _ = brokenAt
            minLen = min(minLen, n)
            maxLen = max(maxLen, n)
            sumLen += n
        }
        let avg = Double(sumLen) / Double(trials)
        let line = String(
            format: "  %@ %@ trials=%d  solutionLen min=%d max=%d avg=%.2f",
            mode.title, diff.title, trials, minLen, maxLen, avg
        )
        summaries.append(line)
    }

    static func stressShallow() {
        let diff = DMDifficulty.ember
        for i in 0..<8 {
            let seed = UInt64(i) &+ 0xDEADBEEF
            let p = DMEmberForge.forge(mode: .beacon, difficulty: diff, seed: seed)
            let wrong = p.initialBoard.cells.first!
            if p.rune.current == wrong { continue }
            guard let scrambled = p.initialBoard.applyingTap(at: wrong) else { continue }
            var rn = p.initialRune
            rn.advance()
            _ = DMSolver.shallowSolve(from: scrambled, to: p.target, rune: rn, maxDepth: 10)
        }
    }

    static func main() {
        print("[harness] Cinderwake")
        for mode in DMMode.allCases {
            for diff in DMDifficulty.allCases {
                check(mode, diff, trials: TRIALS_PER_COMBO)
            }
        }
        stressShallow()

        for line in summaries { print(line) }

        if fatalErrors.isEmpty {
            print("HARNESS PASS")
            exit(0)
        } else {
            print("HARNESS FAIL — \(fatalErrors.count) issue(s):")
            for e in fatalErrors.prefix(20) { print("  · " + e) }
            exit(1)
        }
    }
}
