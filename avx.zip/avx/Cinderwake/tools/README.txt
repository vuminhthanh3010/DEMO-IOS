Scripts phụ trợ (vẽ icon...). Thư mục này nằm NGOÀI nhóm nguồn được Xcode
đồng bộ, nên file ở đây không bị compile vào app. Chạy: swift tools/AppIcon.swift out.png
