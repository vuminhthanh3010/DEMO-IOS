import Foundation

struct DMPuzzle: Codable {
    let mode: DMMode
    let difficulty: DMDifficulty
    let seed: UInt64
    let target: DMHearth
    let initialBoard: DMHearth
    let initialSolution: [DMHexCoord]
    let plannedLength: Int
    let initialRune: DMChillRune

    // Runtime state below.
    var board: DMHearth
    var rune: DMChillRune
    var moveCount: Int
    var undosLeft: Int
    var hintsLeft: Int
    var history: [DMHearthSnapshot]

    var isSolved: Bool { board == target }
    var hasHistory: Bool { !history.isEmpty }
    var optimalMoves: Int { plannedLength }
}

struct DMHearthSnapshot: Codable {
    let board: DMHearth
    let rune: DMChillRune
    let moveCount: Int
}
