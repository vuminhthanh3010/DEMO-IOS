import Foundation

/// The board: a hexagon of `radius` filled with ember levels 0...3.
struct DMHearth: Equatable, Codable {
    static let maxLevel = 3

    let radius: Int
    private(set) var levels: [DMHexCoord: Int]

    static func empty(radius: Int) -> DMHearth {
        let cells = DMHexCoord.hexagon(radius: radius)
        var levels: [DMHexCoord: Int] = [:]
        for c in cells { levels[c] = 0 }
        return DMHearth(radius: radius, levels: levels)
    }

    var cells: [DMHexCoord] { DMHexCoord.hexagon(radius: radius) }

    func level(at c: DMHexCoord) -> Int { levels[c] ?? 0 }

    func contains(_ c: DMHexCoord) -> Bool { levels[c] != nil }

    func neighbors(of c: DMHexCoord) -> [DMHexCoord] {
        c.neighbors().filter { contains($0) }
    }

    mutating func setLevel(_ v: Int, at c: DMHexCoord) {
        guard levels[c] != nil else { return }
        levels[c] = max(0, min(DMHearth.maxLevel, v))
    }

    // MARK: - Forward moves (the two flavours are decided by cell state)

    /// Whether tapping `c` would change the board.
    /// Kindle (< 3) always changes the level; Burst (= 3) changes the level too.
    func canTap(at c: DMHexCoord) -> Bool { levels[c] != nil }

    /// Forward tap. Returns the resulting board, or nil if `c` is off-board.
    func applyingTap(at c: DMHexCoord) -> DMHearth? {
        guard let cur = levels[c] else { return nil }
        var next = self
        if cur < DMHearth.maxLevel {
            next.levels[c] = cur + 1
        } else {
            next.levels[c] = 0
            for nb in neighbors(of: c) {
                let nv = next.levels[nb]!
                if nv < DMHearth.maxLevel {
                    next.levels[nb] = nv + 1
                }
            }
        }
        return next
    }

    // MARK: - Reverse moves (generator only)

    /// Undo a Kindle (X was < 3, then +1). Legal if levels[c] in 1...3.
    func applyingReverseKindle(at c: DMHexCoord) -> DMHearth? {
        guard let cur = levels[c], cur >= 1 else { return nil }
        var next = self
        next.levels[c] = cur - 1
        return next
    }

    /// Undo a Burst (X was = 3, then 0, each in-board neighbor +1 if it was < 3).
    /// We only allow reversing when every in-board neighbor is now >= 1 AND
    /// none of them is at maxLevel (so before the burst it was < 3).
    /// Also require levels[c] == 0.
    func applyingReverseBurst(at c: DMHexCoord) -> DMHearth? {
        guard let cur = levels[c], cur == 0 else { return nil }
        let nbs = neighbors(of: c)
        guard !nbs.isEmpty else { return nil }
        for nb in nbs {
            let nv = levels[nb] ?? 0
            if nv < 1 { return nil }
        }
        var next = self
        next.levels[c] = DMHearth.maxLevel
        for nb in nbs {
            next.levels[nb] = (next.levels[nb] ?? 0) - 1
        }
        return next
    }

    /// Stable key for hash/eq in visited sets.
    func canonicalKey() -> String {
        let sorted = levels.keys.sorted { a, b in a.q == b.q ? a.r < b.r : a.q < b.q }
        var out = ""
        out.reserveCapacity(sorted.count)
        for c in sorted { out.append(Character(String(levels[c] ?? 0))) }
        return out
    }
}
