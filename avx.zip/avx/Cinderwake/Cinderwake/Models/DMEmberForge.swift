import Foundation

/// Puzzle factory: builds a target board, walks a reverse chain of legal
/// inverse moves, and packages everything into a `DMPuzzle`.
enum DMEmberForge {
    static func forge(mode: DMMode, difficulty: DMDifficulty, seed: UInt64) -> DMPuzzle {
        var attempt: UInt64 = seed
        for _ in 0..<24 {
            if let p = tryForge(mode: mode, difficulty: difficulty, seed: attempt) {
                return p
            }
            attempt = attempt &+ 0x1F1F_1F1F_1F1F_1F1F
        }
        // Degenerate fallback — always solvable but small.
        return trivialFallback(mode: mode, difficulty: difficulty, seed: seed)
    }

    private static func tryForge(mode: DMMode, difficulty: DMDifficulty, seed: UInt64) -> DMPuzzle? {
        var rng = DMSeeded(state: seed &+ 0xA5A5_A5A5_A5A5_A5A5)
        let radius = difficulty.boardRadius
        let target = pickTarget(mode: mode, radius: radius, rng: &rng)
        let plannedN = Int.random(in: difficulty.reverseMoveRange, using: &rng)

        let ring = DMChillRune.perimeter(radius: radius)
        let step = difficulty.chillStep
        let ringSize = ring.count

        var board = target
        var revChoices: [DMHexCoord] = []
        var guardCounter = 0

        // We need to hit exactly `plannedN` reverse moves so that the forward
        // Chill schedule (Chill at player step i = ring[(i * step) % ringSize])
        // never lands on a chosen tap. Break out on failure and let the caller retry.
        while revChoices.count < plannedN && guardCounter < plannedN * 100 {
            guardCounter += 1
            let jNow = revChoices.count
            let iAtPlayer = plannedN - 1 - jNow
            let chillAtI: DMHexCoord? = (step > 0 && ringSize > 0)
                ? ring[(iAtPlayer * step) % ringSize] : nil

            let shuffled = board.cells.shuffled(using: &rng)
            var applied = false
            for coord in shuffled {
                if let ch = chillAtI, ch == coord { continue }
                let burstFirst = Bool.random(using: &rng)
                let ops: [(DMHexCoord) -> DMHearth?] = burstFirst
                    ? [board.applyingReverseBurst, board.applyingReverseKindle]
                    : [board.applyingReverseKindle, board.applyingReverseBurst]
                for op in ops {
                    if let next = op(coord) {
                        board = next
                        revChoices.append(coord)
                        applied = true
                        break
                    }
                }
                if applied { break }
            }
            if !applied { return nil }
        }

        // Must produce exactly `plannedN` reverse moves; otherwise the chill
        // mapping is off and playback will trip. Reject and let caller retry.
        if revChoices.count != plannedN { return nil }
        let solution = Array(revChoices.reversed())
        if board == target { return nil }

        let rune = DMChillRune.make(radius: radius, step: step, startIndex: 0)
        let puzzle = DMPuzzle(
            mode: mode,
            difficulty: difficulty,
            seed: seed,
            target: target,
            initialBoard: board,
            initialSolution: solution,
            plannedLength: solution.count,
            initialRune: rune,
            board: board,
            rune: rune,
            moveCount: 0,
            undosLeft: difficulty.maxUndo,
            hintsLeft: difficulty.maxHints,
            history: []
        )
        return puzzle
    }

    private static func trivialFallback(mode: DMMode, difficulty: DMDifficulty, seed: UInt64) -> DMPuzzle {
        var rng = DMSeeded(state: seed)
        let radius = difficulty.boardRadius
        var target = DMHearth.empty(radius: radius)
        if mode == .match {
            for c in target.cells { target.setLevel(Int.random(in: 0...1, using: &rng), at: c) }
        } else {
            for c in target.cells { target.setLevel(1, at: c) }
        }
        var board = target
        var chain: [DMHexCoord] = []
        let cells = target.cells
        for _ in 0..<3 {
            let pick = cells.randomElement(using: &rng)!
            if let n = board.applyingReverseKindle(at: pick) {
                board = n
                chain.append(pick)
            }
        }
        let rune = DMChillRune.make(radius: radius, step: difficulty.chillStep, startIndex: 0)
        return DMPuzzle(
            mode: mode, difficulty: difficulty, seed: seed,
            target: target, initialBoard: board,
            initialSolution: Array(chain.reversed()),
            plannedLength: chain.count, initialRune: rune,
            board: board, rune: rune, moveCount: 0,
            undosLeft: difficulty.maxUndo, hintsLeft: difficulty.maxHints,
            history: []
        )
    }

    private static func pickTarget(mode: DMMode, radius: Int, rng: inout DMSeeded) -> DMHearth {
        var hearth = DMHearth.empty(radius: radius)
        switch mode {
        case .beacon:
            // Every cell settled at glow 1 — an even, calm beacon.
            for c in hearth.cells { hearth.setLevel(1, at: c) }
            return hearth
        case .match:
            for c in hearth.cells {
                let roll = Int.random(in: 0...9, using: &rng)
                let value: Int
                switch roll {
                case 0...3: value = 0
                case 4...6: value = 1
                case 7...8: value = 2
                default:    value = 3
                }
                hearth.setLevel(value, at: c)
            }
            return hearth
        }
    }
}
