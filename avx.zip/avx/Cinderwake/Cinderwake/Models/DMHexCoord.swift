import Foundation

struct DMHexCoord: Hashable, Codable {
    let q: Int
    let r: Int

    static let neighborOffsets: [(Int, Int)] = [
        (+1,  0), (+1, -1), (0, -1),
        (-1,  0), (-1, +1), (0, +1)
    ]

    func neighbors() -> [DMHexCoord] {
        DMHexCoord.neighborOffsets.map { DMHexCoord(q: q + $0.0, r: r + $0.1) }
    }

    static func hexagon(radius: Int) -> [DMHexCoord] {
        guard radius >= 0 else { return [] }
        var out: [DMHexCoord] = []
        for q in -radius...radius {
            let rLo = max(-radius, -q - radius)
            let rHi = min( radius, -q + radius)
            for r in rLo...rHi { out.append(DMHexCoord(q: q, r: r)) }
        }
        return out
    }

    /// Cube distance from origin.
    func distanceFromCenter() -> Int {
        (abs(q) + abs(q + r) + abs(r)) / 2
    }

    /// Pointy-top pixel offset from center; used for ordering the outer ring by angle.
    var angleAroundCenter: Double {
        let x = sqrt(3.0) * (Double(q) + Double(r) / 2.0)
        let y = 1.5 * Double(r)
        return atan2(y, x)
    }

    /// Pointy-top pixel center at a given cell size.
    func pixel(cellSize: Double) -> (x: Double, y: Double) {
        let x = cellSize * sqrt(3.0) * (Double(q) + Double(r) / 2.0)
        let y = cellSize * 1.5 * Double(r)
        return (x, y)
    }
}
