import Foundation

/// The Chill rune walks the outer ring of the board. The cell it occupies at any
/// given tick cannot be tapped that turn. It advances by `stepPerMove` cells
/// after every legal player move.
struct DMChillRune: Codable {
    let ringCells: [DMHexCoord]
    private(set) var cursor: Int   // Index into ringCells, or -1 when disabled.
    let stepPerMove: Int

    static func perimeter(radius: Int) -> [DMHexCoord] {
        guard radius > 0 else { return [] }
        let ring = DMHexCoord.hexagon(radius: radius).filter { $0.distanceFromCenter() == radius }
        return ring.sorted { $0.angleAroundCenter < $1.angleAroundCenter }
    }

    static func make(radius: Int, step: Int, startIndex: Int = 0) -> DMChillRune {
        let ring = perimeter(radius: radius)
        if ring.isEmpty || step == 0 {
            return DMChillRune(ringCells: ring, cursor: -1, stepPerMove: 0)
        }
        let idx = ring.isEmpty ? -1 : ((startIndex % ring.count) + ring.count) % ring.count
        return DMChillRune(ringCells: ring, cursor: idx, stepPerMove: step)
    }

    var current: DMHexCoord? {
        guard cursor >= 0, !ringCells.isEmpty else { return nil }
        return ringCells[cursor]
    }

    var isActive: Bool { cursor >= 0 && !ringCells.isEmpty && stepPerMove > 0 }

    mutating func advance() {
        guard isActive else { return }
        cursor = (cursor + stepPerMove) % ringCells.count
    }

    /// Where the chill will be after `k` extra moves, without mutating.
    func peek(afterMoves k: Int) -> DMHexCoord? {
        guard isActive, k >= 0 else { return current }
        let idx = (cursor + stepPerMove * k) % ringCells.count
        return ringCells[idx]
    }
}
