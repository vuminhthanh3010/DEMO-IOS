import Foundation

enum DMSolver {

    /// Playback-based hint. Simulates the recorded chain from the current board.
    /// If the chain still lands on the target, the first step of the chain is
    /// the next hint. If it does not (player diverged), nil is returned and the
    /// caller must fall back to `shallowSolve` or ask the player to Undo.
    static func nextHint(from board: DMHearth, to target: DMHearth,
                          along chain: [DMHexCoord], rune: DMChillRune) -> DMHexCoord? {
        guard !chain.isEmpty else { return nil }
        var b = board
        var rn = rune
        for step in chain {
            if rn.current == step { return nil }
            guard let next = b.applyingTap(at: step) else { return nil }
            b = next
            rn.advance()
        }
        return b == target ? chain.first : nil
    }

    /// Bounded BFS used only when the recorded chain no longer applies.
    /// Depth cap keeps the search tractable on 7 / 19 cell boards.
    static func shallowSolve(from board: DMHearth, to target: DMHearth,
                              rune: DMChillRune, maxDepth: Int) -> [DMHexCoord]? {
        if board == target { return [] }
        struct Node { let board: DMHearth; let rune: DMChillRune; let path: [DMHexCoord] }
        var frontier: [Node] = [Node(board: board, rune: rune, path: [])]
        var seen: Set<String> = [key(board, rune)]
        for _ in 0..<maxDepth {
            var next: [Node] = []
            for n in frontier {
                if n.rune.isActive == false && n.rune.ringCells.isEmpty {
                    // No chill: still explore every cell.
                }
                for c in n.board.cells {
                    if n.rune.current == c { continue }
                    guard let nb = n.board.applyingTap(at: c) else { continue }
                    var nr = n.rune
                    nr.advance()
                    let k = key(nb, nr)
                    if seen.contains(k) { continue }
                    seen.insert(k)
                    let newPath = n.path + [c]
                    if nb == target { return newPath }
                    next.append(Node(board: nb, rune: nr, path: newPath))
                    if seen.count > 60_000 { return nil }
                }
            }
            frontier = next
            if frontier.isEmpty { return nil }
        }
        return nil
    }

    private static func key(_ b: DMHearth, _ r: DMChillRune) -> String {
        if let c = r.current { return b.canonicalKey() + "|" + String(c.q) + "," + String(c.r) }
        return b.canonicalKey() + "|-"
    }

    /// Simulate applying a chain from a starting state. Returns the resulting board
    /// (and remaining chain steps that did apply), for use in autopilot / harness.
    static func playback(chain: [DMHexCoord], on start: DMHearth, rune: DMChillRune)
        -> (board: DMHearth, rune: DMChillRune, applied: [DMHexCoord])?
    {
        var b = start
        var rn = rune
        var applied: [DMHexCoord] = []
        for step in chain {
            if rn.current == step { return nil }
            guard let nb = b.applyingTap(at: step) else { return nil }
            b = nb
            rn.advance()
            applied.append(step)
        }
        return (b, rn, applied)
    }
}
