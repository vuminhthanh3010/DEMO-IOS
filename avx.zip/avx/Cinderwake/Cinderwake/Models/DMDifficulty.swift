import Foundation

enum DMDifficulty: Int, CaseIterable, Codable {
    case ember = 0
    case coal  = 1
    case blaze = 2

    var boardRadius: Int {
        switch self {
        case .ember: return 1
        case .coal:  return 2
        case .blaze: return 2
        }
    }

    var reverseMoveRange: ClosedRange<Int> {
        switch self {
        case .ember: return 4...6
        case .coal:  return 8...11
        case .blaze: return 14...18
        }
    }

    var chillStep: Int {
        switch self {
        case .ember: return 0
        case .coal:  return 1
        case .blaze: return 2
        }
    }

    var maxHints: Int {
        switch self { case .ember: return 3; case .coal: return 2; case .blaze: return 1 }
    }

    var maxUndo: Int { 5 }

    var title: String {
        switch self { case .ember: return "Ember"; case .coal: return "Coal"; case .blaze: return "Blaze" }
    }

    var tagline: String {
        switch self {
        case .ember: return "Small hearth, no chill drift"
        case .coal:  return "Wider hearth, chill drifts one step"
        case .blaze: return "Full ring, chill leaps two steps"
        }
    }
}

enum DMMode: Int, CaseIterable, Codable {
    case match  = 0
    case beacon = 1

    var title: String { self == .match ? "Match" : "Beacon" }

    var summary: String {
        self == .match
            ? "Reach the mirrored heat pattern"
            : "Settle every ember evenly at one glow"
    }
}
