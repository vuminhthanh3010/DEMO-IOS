import SwiftUI
import Combine
import Foundation

/// Central game view-model. Owns the puzzle, timer, hint chain, undo stack.
final class DMHearthConductor: ObservableObject {

    // MARK: Public state
    @Published private(set) var puzzle: DMPuzzle
    @Published private(set) var elapsedSeconds: Int = 0
    @Published var isPaused: Bool = false
    @Published private(set) var isFinished: Bool = false
    @Published private(set) var wobbleAt: DMHexCoord? = nil       // For invalid-tap shake
    @Published private(set) var pulseAt: DMHexCoord? = nil        // For hint highlight
    @Published private(set) var lastResultAtPar: Bool = false
    @Published private(set) var lastResultFlawless: Bool = true

    // MARK: Config injected from Vault
    let mode: DMMode
    let difficulty: DMDifficulty
    let hintsEnabled: Bool
    private let vault: DMVault
    private var timer: Timer?

    init(mode: DMMode, difficulty: DMDifficulty, hintsEnabled: Bool, vault: DMVault,
         seed: UInt64? = nil, existing: DMPuzzle? = nil) {
        self.mode = mode
        self.difficulty = difficulty
        self.hintsEnabled = hintsEnabled
        self.vault = vault
        if let existing {
            self.puzzle = existing
        } else {
            let s = seed ?? UInt64.random(in: 1...UInt64.max)
            self.puzzle = DMEmberForge.forge(mode: mode, difficulty: difficulty, seed: s)
        }
        DMTrace.reveal(self.puzzle.initialSolution.map { "(\($0.q),\($0.r))" })
        startTimer()
    }

    deinit { timer?.invalidate() }

    // MARK: - Ticker

    func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            guard let self else { return }
            if !self.isPaused && !self.isFinished { self.elapsedSeconds += 1 }
        }
    }

    func stopTimer() { timer?.invalidate(); timer = nil }

    // MARK: - Player actions

    func tap(_ c: DMHexCoord) {
        guard !isFinished, !isPaused else { return }
        if puzzle.rune.current == c {
            DMHaptics.shared.fire(.error)
            wobbleAt = c
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in self?.wobbleAt = nil }
            return
        }
        guard let nb = puzzle.board.applyingTap(at: c) else { return }
        // Save history for undo
        let snap = DMHearthSnapshot(board: puzzle.board, rune: puzzle.rune, moveCount: puzzle.moveCount)
        puzzle.history.append(snap)
        if puzzle.history.count > puzzle.difficulty.maxUndo * 4 { puzzle.history.removeFirst() }
        puzzle.board = nb
        puzzle.rune.advance()
        puzzle.moveCount += 1
        DMHaptics.shared.fire(.light)
        if puzzle.isSolved {
            isFinished = true
            lastResultFlawless = puzzle.hintsLeft == puzzle.difficulty.maxHints
            lastResultAtPar = puzzle.moveCount <= puzzle.plannedLength
            DMHaptics.shared.fire(.success)
            vault.stats.record(mode: mode, diff: difficulty,
                               moves: puzzle.moveCount,
                               seconds: elapsedSeconds,
                               won: true)
            vault.awardBadges(mode: mode, diff: difficulty,
                              moves: puzzle.moveCount,
                              plannedMoves: puzzle.plannedLength,
                              usedHints: !lastResultFlawless)
            vault.savedRun = nil
        } else {
            // Snapshot the run so a mid-game exit can resume.
            vault.savedRun = puzzle
        }
    }

    func undo() {
        guard !isFinished else { return }
        guard puzzle.undosLeft > 0, let last = puzzle.history.popLast() else {
            DMHaptics.shared.fire(.warn); return
        }
        puzzle.board = last.board
        puzzle.rune = last.rune
        puzzle.moveCount = last.moveCount
        puzzle.undosLeft -= 1
        DMHaptics.shared.fire(.medium)
        vault.savedRun = puzzle.moveCount == 0 ? nil : puzzle
    }

    func requestHint() -> DMHexCoord? {
        guard hintsEnabled, puzzle.hintsLeft > 0, !isFinished else {
            DMHaptics.shared.fire(.warn); return nil
        }
        // Try the recorded chain first.
        if let c = DMSolver.nextHint(from: puzzle.board,
                                       to: puzzle.target,
                                       along: puzzle.initialSolution,
                                       rune: puzzle.rune) {
            puzzle.hintsLeft -= 1
            pulseHighlight(c)
            return c
        }
        // Fallback: shallow BFS.
        if let path = DMSolver.shallowSolve(from: puzzle.board,
                                              to: puzzle.target,
                                              rune: puzzle.rune,
                                              maxDepth: 7),
           let first = path.first {
            puzzle.hintsLeft -= 1
            pulseHighlight(first)
            return first
        }
        DMHaptics.shared.fire(.warn)
        return nil
    }

    private func pulseHighlight(_ c: DMHexCoord) {
        pulseAt = c
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { [weak self] in
            if self?.pulseAt == c { self?.pulseAt = nil }
        }
    }

    func resetSameSeed() {
        puzzle.board = puzzle.initialBoard
        puzzle.rune = puzzle.initialRune
        puzzle.moveCount = 0
        puzzle.undosLeft = puzzle.difficulty.maxUndo
        puzzle.hintsLeft = puzzle.difficulty.maxHints
        puzzle.history = []
        elapsedSeconds = 0
        isFinished = false
        vault.savedRun = nil
    }

    func reforge() {
        let seed = UInt64.random(in: 1...UInt64.max)
        puzzle = DMEmberForge.forge(mode: mode, difficulty: difficulty, seed: seed)
        elapsedSeconds = 0
        isFinished = false
        vault.savedRun = nil
        DMTrace.reveal(puzzle.initialSolution.map { "(\($0.q),\($0.r))" })
    }

    // MARK: - Progress percent (used by the progress arc)

    var completionPercent: Double {
        let cells = puzzle.board.cells
        guard !cells.isEmpty else { return 0 }
        var matched = 0
        for c in cells where puzzle.board.level(at: c) == puzzle.target.level(at: c) { matched += 1 }
        return Double(matched) / Double(cells.count)
    }

    var moveOverPar: Int { max(0, puzzle.moveCount - puzzle.plannedLength) }

    var elapsedString: String {
        let m = elapsedSeconds / 60
        let s = elapsedSeconds % 60
        return String(format: "%d:%02d", m, s)
    }
}
