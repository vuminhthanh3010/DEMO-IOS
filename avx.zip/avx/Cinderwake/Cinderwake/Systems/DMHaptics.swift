import UIKit

enum DMHapticKind { case light, medium, success, warn, error }

final class DMHaptics {
    static let shared = DMHaptics()

    var enabled: Bool = true

    private lazy var lightGen: UIImpactFeedbackGenerator = { UIImpactFeedbackGenerator(style: .light) }()
    private lazy var mediumGen: UIImpactFeedbackGenerator = { UIImpactFeedbackGenerator(style: .medium) }()
    private lazy var notifyGen: UINotificationFeedbackGenerator = { UINotificationFeedbackGenerator() }()

    func fire(_ kind: DMHapticKind) {
        guard enabled else { return }
        switch kind {
        case .light:   lightGen.impactOccurred()
        case .medium:  mediumGen.impactOccurred()
        case .success: notifyGen.notificationOccurred(.success)
        case .warn:    notifyGen.notificationOccurred(.warning)
        case .error:   notifyGen.notificationOccurred(.error)
        }
    }
}
