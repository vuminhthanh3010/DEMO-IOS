import SwiftUI
import UIKit

/// Share sheet wrapper (Cinderwake calls this a "relay card" — a small tin plate
/// you hand off to a friend).
struct DMRelayCard: UIViewControllerRepresentable {
    let payload: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: payload, applicationActivities: nil)
    }

    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}
