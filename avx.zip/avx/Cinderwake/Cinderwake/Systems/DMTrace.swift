import Foundation

/// Neutral logging for solutions and autopilot events. Keeps out of production
/// via `#if DEBUG`.
enum DMTrace {
    static func reveal(_ items: [String]) {
        #if DEBUG
        print("[hearth] solution: " + items.joined(separator: " → "))
        #endif
    }

    static func note(_ message: String) {
        #if DEBUG
        print("[hearth] " + message)
        #endif
    }

    static func autoplay(_ message: String) {
        // Autoplay log lines are read by the QA harness, so they always print.
        print("[autoplay] " + message)
    }
}
