import SwiftUI

// MARK: - Stage Tone

enum DMStageTone {
    case entry
    case forge
    case hearth
    case tally
    case bellows
    case primer
}

enum DMPaletteName: String, CaseIterable, Codable {
    case ember  = "Ember"
    case ash    = "Ash"
    case copper = "Copper"
}

// MARK: - Night Crystal Palette

enum DMPalette {

    // MARK: Background gradients per screen
    static func gradient(tone: DMStageTone, name: DMPaletteName, scheme: ColorScheme) -> [Color] {
        switch (name, tone) {
        // ── Ember variant ────────────────────────────────────────────────────
        case (.ember, .entry):
            return [NC.deepVoid, NC.indigoDeep, NC.purpleMid]
        case (.ember, .forge):
            return [NC.deepVoid, NC.indigoDeep]
        case (.ember, .hearth):
            return [NC.deepVoid, Color(h: 255, s: 40, l: 9)]
        case (.ember, .tally):
            return [NC.deepVoid, NC.indigoDeep, NC.purpleMid]
        case (.ember, .bellows):
            return [NC.deepVoid, Color(h: 240, s: 30, l: 10)]
        case (.ember, .primer):
            return [Color(h: 240, s: 35, l: 7), NC.indigoDeep]

        // ── Ash variant (cooler, more blue-grey) ─────────────────────────────
        case (.ash, .entry):
            return [Color(h: 230, s: 30, l: 6), Color(h: 220, s: 40, l: 14)]
        case (.ash, .forge):
            return [Color(h: 225, s: 28, l: 8), Color(h: 215, s: 35, l: 18)]
        case (.ash, .hearth):
            return [Color(h: 220, s: 25, l: 7), Color(h: 210, s: 32, l: 15)]
        case (.ash, .tally):
            return [Color(h: 225, s: 30, l: 8), Color(h: 215, s: 40, l: 16)]
        case (.ash, .bellows):
            return [Color(h: 220, s: 22, l: 9), Color(h: 215, s: 28, l: 16)]
        case (.ash, .primer):
            return [Color(h: 220, s: 25, l: 8), Color(h: 210, s: 30, l: 16)]

        // ── Copper variant (warmer teal-orange contrast) ──────────────────────
        case (.copper, .entry):
            return [Color(h: 200, s: 55, l: 6), Color(h: 190, s: 60, l: 14)]
        case (.copper, .forge):
            return [Color(h: 195, s: 50, l: 7), Color(h: 185, s: 55, l: 16)]
        case (.copper, .hearth):
            return [Color(h: 190, s: 45, l: 6), Color(h: 180, s: 50, l: 14)]
        case (.copper, .tally):
            return [Color(h: 200, s: 52, l: 8), Color(h: 190, s: 58, l: 18)]
        case (.copper, .bellows):
            return [Color(h: 195, s: 40, l: 8), Color(h: 185, s: 45, l: 16)]
        case (.copper, .primer):
            return [Color(h: 195, s: 42, l: 7), Color(h: 180, s: 48, l: 15)]
        }
    }

    // MARK: Crystal accent colours per palette
    static func crystalAccent(_ name: DMPaletteName) -> Color {
        switch name {
        case .ember:  return NC.tealGlow
        case .ash:    return Color(h: 195, s: 70, l: 62)
        case .copper: return Color(h: 170, s: 72, l: 56)
        }
    }

    static func crystalSecondary(_ name: DMPaletteName) -> Color {
        switch name {
        case .ember:  return NC.purpleGlow
        case .ash:    return Color(h: 215, s: 55, l: 58)
        case .copper: return Color(h: 35, s: 78, l: 58)
        }
    }

    // MARK: Text
    static func onBackground(scheme: ColorScheme) -> Color {
        scheme == .dark
            ? Color(h: 230, s: 40, l: 92)
            : Color(h: 230, s: 30, l: 12)
    }

    static func onBackgroundMuted(scheme: ColorScheme) -> Color {
        scheme == .dark
            ? Color(h: 230, s: 25, l: 60)
            : Color(h: 230, s: 20, l: 38)
    }

    // MARK: Ember cell scale
    static func emberScale(level: Int, scheme: ColorScheme) -> Color {
        switch level {
        case 0: return scheme == .dark
                    ? Color(h: 250, s: 20, l: 16)
                    : Color(h: 250, s: 18, l: 72)
        case 1: return Color(h: 180, s: 72, l: 52)   // teal
        case 2: return Color(h: 270, s: 68, l: 62)   // violet
        default: return Color(h: 310, s: 80, l: 68)  // magenta-pink
        }
    }

    static func chillTint() -> Color { Color(h: 196, s: 80, l: 68) }
    static func targetTint() -> Color { NC.tealGlow }

    static func accent(scheme: ColorScheme) -> Color {
        scheme == .dark ? NC.tealGlow : Color(h: 180, s: 65, l: 38)
    }

    // MARK: Glass panel
    static func glassFill(scheme: ColorScheme) -> Color {
        scheme == .dark
            ? Color(h: 250, s: 35, l: 14).opacity(0.72)
            : Color(h: 240, s: 20, l: 94).opacity(0.72)
    }

    static func glassBorder(scheme: ColorScheme) -> Color {
        scheme == .dark
            ? Color.white.opacity(0.10)
            : Color.black.opacity(0.08)
    }
}

// MARK: - Night Crystal color tokens

enum NC {
    static let deepVoid    = Color(h: 248, s: 42, l: 5)
    static let indigoDeep  = Color(h: 255, s: 48, l: 12)
    static let purpleMid   = Color(h: 270, s: 52, l: 20)
    static let tealGlow    = Color(h: 178, s: 80, l: 58)
    static let purpleGlow  = Color(h: 280, s: 72, l: 68)
    static let crystalBlue = Color(h: 210, s: 80, l: 64)
    static let voidBlack   = Color(h: 250, s: 30, l: 4)
}

// MARK: - HSL color helper

extension Color {
    init(h: Double, s: Double, l: Double, alpha: Double = 1) {
        let hh = (h.truncatingRemainder(dividingBy: 360)) / 360.0
        let ss = max(0, min(1, s / 100.0))
        let ll = max(0, min(1, l / 100.0))
        let q = ll < 0.5 ? ll * (1 + ss) : ll + ss - ll * ss
        let p = 2 * ll - q
        func hue2rgb(_ p: Double, _ q: Double, _ t: Double) -> Double {
            var t = t
            if t < 0 { t += 1 }
            if t > 1 { t -= 1 }
            if t < 1/6 { return p + (q - p) * 6 * t }
            if t < 1/2 { return q }
            if t < 2/3 { return p + (q - p) * (2/3 - t) * 6 }
            return p
        }
        let r = hue2rgb(p, q, hh + 1/3)
        let g = hue2rgb(p, q, hh)
        let b = hue2rgb(p, q, hh - 1/3)
        self = Color(.sRGB, red: r, green: g, blue: b, opacity: alpha)
    }
}

// MARK: - Backdrop

struct DMBackdrop: View {
    let tone: DMStageTone
    let palette: DMPaletteName
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let cols = DMPalette.gradient(tone: tone, name: palette, scheme: scheme)
        ZStack {
            LinearGradient(
                colors: cols,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            // Crystal nebula blobs
            GeometryReader { geo in
                let w = geo.size.width
                let h = geo.size.height
                ZStack {
                    // Teal blob top-right
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [
                                    DMPalette.crystalAccent(palette).opacity(0.28),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: w * 0.5
                            )
                        )
                        .frame(width: w * 0.9, height: w * 0.9)
                        .blur(radius: 60)
                        .offset(x: w * 0.25, y: -h * 0.08)

                    // Purple blob bottom-left
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [
                                    DMPalette.crystalSecondary(palette).opacity(0.22),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: w * 0.45
                            )
                        )
                        .frame(width: w * 0.8, height: w * 0.8)
                        .blur(radius: 55)
                        .offset(x: -w * 0.22, y: h * 0.28)

                    // Subtle centre glow
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [
                                    NC.indigoDeep.opacity(0.35),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: w * 0.4
                            )
                        )
                        .frame(width: w * 0.7, height: w * 0.7)
                        .blur(radius: 40)
                        .offset(x: 0, y: h * 0.1)
                }
                .allowsHitTesting(false)
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - Glass card modifier

struct GlassCard: ViewModifier {
    var cornerRadius: CGFloat = 18
    var padding: CGFloat = 16
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .fill(DMPalette.glassFill(scheme: scheme))
                    .overlay(
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .strokeBorder(DMPalette.glassBorder(scheme: scheme), lineWidth: 1)
                    )
            )
    }
}

extension View {
    func glassCard(cornerRadius: CGFloat = 18, padding: CGFloat = 16) -> some View {
        self.modifier(GlassCard(cornerRadius: cornerRadius, padding: padding))
    }
}

// MARK: - Crystal pill button style

struct CrystalPillStyle: ButtonStyle {
    var tint: Color
    var filled: Bool = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 14, weight: .bold, design: .rounded))
            .foregroundColor(.white)
            .padding(.horizontal, 22)
            .padding(.vertical, 11)
            .background(
                Group {
                    if filled {
                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: [tint, tint.opacity(0.7)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    } else {
                        Capsule()
                            .strokeBorder(tint, lineWidth: 1.4)
                    }
                }
            )
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.easeInOut(duration: 0.12), value: configuration.isPressed)
    }
}

// MARK: - Scale button style

struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.easeInOut(duration: 0.12), value: configuration.isPressed)
    }
}

// MARK: - Arc track shape

struct DMArcTrack: Shape {
    let fraction: Double
    let radius: CGFloat
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let centre = CGPoint(x: rect.midX, y: rect.midY)
        let start = -CGFloat.pi / 2
        let end = start + CGFloat(fraction) * .pi * 2
        p.addArc(
            center: centre,
            radius: rect.width / 2,
            startAngle: .radians(Double(start)),
            endAngle: .radians(Double(end)),
            clockwise: false
        )
        return p
    }
}

// MARK: - Typography

enum DMType {
    static func display(_ side: CGFloat) -> Font {
        .system(size: max(28, side * 0.10), weight: .heavy, design: .rounded)
    }
    static func heading(_ side: CGFloat) -> Font {
        .system(size: max(20, side * 0.055), weight: .bold, design: .rounded)
    }
    static func label(_ side: CGFloat) -> Font {
        .system(size: max(14, side * 0.036), weight: .semibold, design: .rounded)
    }
    static func body(_ side: CGFloat) -> Font {
        .system(size: max(13, side * 0.032), weight: .regular, design: .rounded)
    }
    static func caption(_ side: CGFloat) -> Font {
        .system(size: max(11, side * 0.028), weight: .medium, design: .rounded)
    }
}
