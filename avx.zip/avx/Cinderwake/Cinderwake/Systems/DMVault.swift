import Foundation
import Combine
import SwiftUI

/// Persistence + user preferences. All non-Codable prefs live under @AppStorage
/// so they survive process restarts; complex saved puzzles/stats go through
/// the encoded blobs below.

struct DMStats: Codable, Equatable {
    var totalWins: Int = 0
    var currentStreak: Int = 0
    var bestStreak: Int = 0
    var bestMoves: [String: Int] = [:]       // "\(mode.rawValue).\(diff.rawValue)" → best move count
    var bestSeconds: [String: Int] = [:]

    static func key(_ mode: DMMode, _ diff: DMDifficulty) -> String {
        "\(mode.rawValue).\(diff.rawValue)"
    }

    mutating func record(mode: DMMode, diff: DMDifficulty, moves: Int, seconds: Int, won: Bool) {
        if won {
            totalWins += 1
            currentStreak += 1
            if currentStreak > bestStreak { bestStreak = currentStreak }
            let k = DMStats.key(mode, diff)
            if let cur = bestMoves[k] { if moves < cur { bestMoves[k] = moves } } else { bestMoves[k] = moves }
            if let cur = bestSeconds[k] { if seconds < cur { bestSeconds[k] = seconds } } else { bestSeconds[k] = seconds }
        } else {
            currentStreak = 0
        }
    }
}

/// Achievements tracked by the vault.
enum DMBadge: String, Codable, CaseIterable {
    case firstWin
    case flawlessSweep       // completed without any hint use
    case parScore            // solved in optimal move count
    case tenStreak
    case blazeConqueror
    case tricolor            // won at every difficulty

    var title: String {
        switch self {
        case .firstWin:        return "First Kindle"
        case .flawlessSweep:   return "Flawless Sweep"
        case .parScore:        return "On the Mark"
        case .tenStreak:       return "Ten Bright"
        case .blazeConqueror:  return "Blaze Tamed"
        case .tricolor:        return "Three-Coal Master"
        }
    }
    var caption: String {
        switch self {
        case .firstWin:        return "Finish one puzzle"
        case .flawlessSweep:   return "Win without spending a hint"
        case .parScore:        return "Match the optimal move count"
        case .tenStreak:       return "Ten wins in a row"
        case .blazeConqueror:  return "Beat any Blaze round"
        case .tricolor:        return "Win at Ember, Coal and Blaze"
        }
    }
}

final class DMVault: ObservableObject {
    static let shared = DMVault()

    // MARK: Prefs (AppStorage-backed on-disk mirror)
    @Published var hapticsOn: Bool {
        didSet {
            UserDefaults.standard.set(hapticsOn, forKey: Keys.haptics)
            DMHaptics.shared.enabled = hapticsOn
        }
    }
    @Published var hintsOn: Bool {
        didSet { UserDefaults.standard.set(hintsOn, forKey: Keys.hints) }
    }
    @Published var paletteName: DMPaletteName {
        didSet { UserDefaults.standard.set(paletteName.rawValue, forKey: Keys.palette) }
    }
    @Published var defaultDifficulty: DMDifficulty {
        didSet { UserDefaults.standard.set(defaultDifficulty.rawValue, forKey: Keys.diff) }
    }
    @Published var defaultMode: DMMode {
        didSet { UserDefaults.standard.set(defaultMode.rawValue, forKey: Keys.mode) }
    }

    // MARK: Stats / badges / saved run
    @Published var stats: DMStats {
        didSet { persistCodable(stats, key: Keys.stats) }
    }
    @Published var badges: Set<DMBadge> {
        didSet {
            let arr = Array(badges).map { $0.rawValue }
            UserDefaults.standard.set(arr, forKey: Keys.badges)
        }
    }
    @Published var savedRun: DMPuzzle? {
        didSet {
            if let p = savedRun { persistCodable(p, key: Keys.saved) }
            else { UserDefaults.standard.removeObject(forKey: Keys.saved) }
        }
    }

    private enum Keys {
        static let haptics = "dm.haptics"
        static let hints   = "dm.hints"
        static let palette = "dm.palette"
        static let diff    = "dm.diff"
        static let mode    = "dm.mode"
        static let stats   = "dm.stats"
        static let badges  = "dm.badges"
        static let saved   = "dm.saved"
    }

    private init() {
        let ud = UserDefaults.standard
        // Register defaults
        ud.register(defaults: [
            Keys.haptics: true,
            Keys.hints:   true,
            Keys.palette: DMPaletteName.ember.rawValue,
            Keys.diff:    DMDifficulty.ember.rawValue,
            Keys.mode:    DMMode.match.rawValue,
        ])
        self.hapticsOn = ud.bool(forKey: Keys.haptics)
        self.hintsOn = ud.bool(forKey: Keys.hints)
        self.paletteName = DMPaletteName(rawValue: ud.string(forKey: Keys.palette) ?? "") ?? .ember
        self.defaultDifficulty = DMDifficulty(rawValue: ud.integer(forKey: Keys.diff)) ?? .ember
        self.defaultMode = DMMode(rawValue: ud.integer(forKey: Keys.mode)) ?? .match
        self.stats = DMVault.loadCodable(DMStats.self, key: Keys.stats) ?? DMStats()
        let badgeStrings = (ud.array(forKey: Keys.badges) as? [String]) ?? []
        self.badges = Set(badgeStrings.compactMap { DMBadge(rawValue: $0) })
        self.savedRun = DMVault.loadCodable(DMPuzzle.self, key: Keys.saved)
        DMHaptics.shared.enabled = self.hapticsOn
    }

    func resetProgress() {
        stats = DMStats()
        badges = []
        savedRun = nil
    }

    func awardBadges(mode: DMMode, diff: DMDifficulty, moves: Int, plannedMoves: Int, usedHints: Bool) {
        badges.insert(.firstWin)
        if !usedHints { badges.insert(.flawlessSweep) }
        if moves <= plannedMoves { badges.insert(.parScore) }
        if stats.currentStreak >= 10 { badges.insert(.tenStreak) }
        if diff == .blaze { badges.insert(.blazeConqueror) }
        // Tricolor: check we have best entries for every difficulty on this mode.
        let allDiffs = DMDifficulty.allCases.map { DMStats.key(mode, $0) }
        if allDiffs.allSatisfy({ stats.bestMoves[$0] != nil }) {
            badges.insert(.tricolor)
        }
    }

    // MARK: - Codable helpers
    private static func loadCodable<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(T.self, from: data)
    }
    private func persistCodable<T: Encodable>(_ value: T, key: String) {
        if let data = try? JSONEncoder().encode(value) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
