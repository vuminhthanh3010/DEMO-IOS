import Foundation
import UIKit

/// Autopilot for J2. Reads command-line flags and drives the conductor tap by
/// tap through the recorded solution.
enum DMAutopilot {

    static func pickMode() -> (DMMode, DMDifficulty) {
        let args = CommandLine.arguments
        let mode: DMMode = args.contains("-DMMode") && args.firstIndex(of: "-DMMode").map({ $0 + 1 < args.count && args[$0 + 1] == "beacon" }) == true
            ? .beacon : .match
        // Prefer explicit -DMMode / -DMDifficulty pair
        var m: DMMode = .match
        var d: DMDifficulty = .ember
        if let i = args.firstIndex(of: "-DMMode"), i + 1 < args.count {
            m = args[i + 1].lowercased() == "beacon" ? .beacon : .match
        }
        if let i = args.firstIndex(of: "-DMDifficulty"), i + 1 < args.count {
            switch args[i + 1].lowercased() {
            case "coal":  d = .coal
            case "blaze": d = .blaze
            default:      d = .ember
            }
        }
        _ = mode
        return (m, d)
    }

    static func start(conductor: DMHearthConductor, onFinish: @escaping () -> Void) {
        DMTrace.autoplay("start mode=\(conductor.mode.title) difficulty=\(conductor.difficulty.title) planned=\(conductor.puzzle.plannedLength)")
        // Copy the recorded chain and consume it step by step.
        var chain = conductor.puzzle.initialSolution
        stepThrough(conductor: conductor, chain: &chain, onFinish: onFinish)
    }

    private static func stepThrough(conductor: DMHearthConductor,
                                    chain: inout [DMHexCoord],
                                    onFinish: @escaping () -> Void) {
        var chainCopy = chain
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.28) {
            if conductor.puzzle.isSolved {
                DMTrace.autoplay("moves=\(conductor.puzzle.moveCount)")
                DMTrace.autoplay("WIN")
                onFinish()
                return
            }
            let cell: DMHexCoord?
            if !chainCopy.isEmpty {
                cell = chainCopy.removeFirst()
            } else {
                cell = DMSolver.shallowSolve(from: conductor.puzzle.board,
                                              to: conductor.puzzle.target,
                                              rune: conductor.puzzle.rune,
                                              maxDepth: 8)?.first
            }
            guard let c = cell else {
                DMTrace.autoplay("LOSE — no path from current state")
                return
            }
            if conductor.puzzle.rune.current == c {
                DMTrace.autoplay("LOSE — chain step (\(c.q),\(c.r)) collides with chill")
                return
            }
            DMTrace.autoplay("tap (\(c.q),\(c.r))")
            let before = conductor.puzzle.moveCount
            conductor.tap(c)
            if conductor.puzzle.moveCount == before {
                DMTrace.autoplay("LOSE — tap was rejected")
                return
            }
            if conductor.puzzle.moveCount > conductor.puzzle.plannedLength + 30 {
                DMTrace.autoplay("LOSE — exceeded move budget")
                return
            }
            stepThrough(conductor: conductor, chain: &chainCopy, onFinish: onFinish)
        }
    }
}
