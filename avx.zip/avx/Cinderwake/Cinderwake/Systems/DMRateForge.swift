import Foundation
import UIKit
import StoreKit

enum DMConfig {
    /// App Store id, set once the app is registered. Placeholder is safe:
    /// `SKStoreReviewController.requestReview()` still fires without it.
    static let storeID: Int = 0000000000
    static var writeReviewURL: URL? {
        URL(string: "https://apps.apple.com/app/id\(storeID)?action=write-review")
    }
}

enum DMRateForge {
    static func request() {
        DispatchQueue.main.async {
            SKStoreReviewController.requestReview()
        }
    }

    static func openWriteReview() {
        guard let url = DMConfig.writeReviewURL else { return }
        UIApplication.shared.open(url)
    }
}
