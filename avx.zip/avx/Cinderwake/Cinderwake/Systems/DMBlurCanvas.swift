import SwiftUI
import UIKit

/// Real UIBlurEffect wrapped for SwiftUI — iOS 14 friendly (Material is 15+).
struct DMBlurCanvas: UIViewRepresentable {
    var style: UIBlurEffect.Style = .systemUltraThinMaterialDark

    func makeUIView(context: Context) -> UIVisualEffectView {
        UIVisualEffectView(effect: UIBlurEffect(style: style))
    }

    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        uiView.effect = UIBlurEffect(style: style)
    }
}
