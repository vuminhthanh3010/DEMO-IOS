import SwiftUI

@main
struct CinderwakeApp: App {
    @StateObject private var vault = DMVault.shared

    var body: some Scene {
        WindowGroup {
            DMRootGate()
                .environmentObject(vault)
        }
    }
}
