import SwiftUI

/// Settings screen — Night Crystal redesign.
/// Clean VStack list-style layout with glass cards, no honeycomb.
struct DMBellowsPanel: View {
    let onClose: () -> Void

    @EnvironmentObject var vault: DMVault
    @State private var confirmReset = false

    var body: some View {
        GeometryReader { geo in
            let safeTop    = geo.safeAreaInsets.top
            let safeBottom = geo.safeAreaInsets.bottom

            ZStack {
                DMBackdrop(tone: .bellows, palette: vault.paletteName)

                VStack(spacing: 0) {
                    // ── Header ───────────────────────────────────────────────
                    header(safeTop: safeTop)

                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 16) {
                            // ── Toggles ──────────────────────────────────────
                            sectionCard {
                                toggleRow(
                                    icon: "waveform",
                                    title: "Haptics",
                                    subtitle: "Vibration on tap and win",
                                    isOn: $vault.hapticsOn
                                )
                                divider
                                toggleRow(
                                    icon: "lightbulb.fill",
                                    title: "Show Hints",
                                    subtitle: "Hint button visible during play",
                                    isOn: $vault.hintsOn
                                )
                            }

                            // ── Palette ───────────────────────────────────────
                            sectionCard {
                                sectionTitle("COLOUR PALETTE")
                                    .padding(.bottom, 10)
                                HStack(spacing: 12) {
                                    ForEach(DMPaletteName.allCases, id: \.self) { p in
                                        paletteOption(p)
                                    }
                                }
                            }

                            // ── Default round ─────────────────────────────────
                            sectionCard {
                                sectionTitle("DEFAULT ROUND")
                                    .padding(.bottom, 10)
                                VStack(spacing: 10) {
                                    // Mode
                                    HStack(spacing: 0) {
                                        ForEach(DMMode.allCases, id: \.self) { m in
                                            segmentButton(
                                                title: m.title,
                                                selected: vault.defaultMode == m
                                            ) {
                                                vault.defaultMode = m
                                            }
                                        }
                                    }
                                    .background(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .fill(Color(h: 255, s: 28, l: 10).opacity(0.6))
                                    )
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

                                    // Difficulty
                                    HStack(spacing: 0) {
                                        ForEach(DMDifficulty.allCases, id: \.self) { d in
                                            segmentButton(
                                                title: d.title,
                                                selected: vault.defaultDifficulty == d
                                            ) {
                                                vault.defaultDifficulty = d
                                            }
                                        }
                                    }
                                    .background(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .fill(Color(h: 255, s: 28, l: 10).opacity(0.6))
                                    )
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                }
                            }

                            // ── Actions ───────────────────────────────────────
                            sectionCard {
                                actionRow(
                                    icon: "star.fill",
                                    title: "Rate Cinderwake",
                                    tint: Color(h: 50, s: 88, l: 58)
                                ) {
                                    DMRateForge.request()
                                }
                                divider
                                actionRow(
                                    icon: "square.and.pencil",
                                    title: "Write a Review",
                                    tint: NC.tealGlow
                                ) {
                                    DMRateForge.openWriteReview()
                                }
                                divider
                                actionRow(
                                    icon: "trash.fill",
                                    title: "Clear Hearth",
                                    tint: Color(h: 8, s: 80, l: 58),
                                    destructive: true
                                ) {
                                    confirmReset = true
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 8)
                        .padding(.bottom, safeBottom + 20)
                    }
                }
            }
            .alert(isPresented: $confirmReset) {
                Alert(
                    title: Text("Clear the hearth?"),
                    message: Text("Stats, badges and any saved run will be lost."),
                    primaryButton: .destructive(Text("Clear")) { vault.resetProgress() },
                    secondaryButton: .cancel()
                )
            }
        }
    }

    // MARK: - Header

    private func header(safeTop: CGFloat) -> some View {
        HStack {
            Button(action: {
                DMHaptics.shared.fire(.light)
                onClose()
            }) {
                Image(systemName: "xmark")
                    .font(.system(size: 14, weight: .heavy))
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
                    .background(
                        Circle()
                            .fill(Color(h: 255, s: 35, l: 18).opacity(0.7))
                            .overlay(Circle().strokeBorder(Color.white.opacity(0.10), lineWidth: 1))
                    )
            }
            .buttonStyle(PlainButtonStyle())
            .accessibilityIdentifier("settings.close")

            Spacer()

            Text("SETTINGS")
                .font(.system(size: 13, weight: .heavy, design: .rounded))
                .tracking(4)
                .foregroundColor(Color.white.opacity(0.75))

            Spacer()

            // Balance spacer
            Color.clear.frame(width: 36, height: 36)
        }
        .padding(.horizontal, 20)
        .padding(.top, safeTop + 12)
        .padding(.bottom, 10)
    }

    // MARK: - Section card

    private func sectionCard<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(spacing: 0) {
            content()
        }
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color(h: 255, s: 32, l: 13).opacity(0.68))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.07), lineWidth: 1)
                )
        )
    }

    private var divider: some View {
        Rectangle()
            .fill(Color.white.opacity(0.06))
            .frame(height: 1)
            .padding(.horizontal, 16)
    }

    private func sectionTitle(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .heavy, design: .rounded))
            .tracking(3)
            .foregroundColor(Color.white.opacity(0.35))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 16)
            .padding(.top, 14)
    }

    // MARK: - Toggle row

    private func toggleRow(icon: String, title: String, subtitle: String,
                            isOn: Binding<Bool>) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(isOn.wrappedValue ? NC.tealGlow : Color.white.opacity(0.35))
                .frame(width: 36, height: 36)
                .background(
                    Circle()
                        .fill(isOn.wrappedValue
                              ? NC.tealGlow.opacity(0.14)
                              : Color.white.opacity(0.05))
                )

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.system(size: 12, weight: .regular, design: .rounded))
                    .foregroundColor(Color.white.opacity(0.38))
            }

            Spacer()

            Toggle("", isOn: isOn)
                .labelsHidden()
                .accentColor(NC.tealGlow)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    // MARK: - Palette option

    private func paletteOption(_ p: DMPaletteName) -> some View {
        let selected = vault.paletteName == p
        return Button {
            vault.paletteName = p
        } label: {
            VStack(spacing: 6) {
                ZStack {
                    Circle()
                        .fill(paletteColor(p))
                        .frame(width: 36, height: 36)
                    if selected {
                        Circle()
                            .strokeBorder(Color.white, lineWidth: 2.5)
                            .frame(width: 36, height: 36)
                        Image(systemName: "checkmark")
                            .font(.system(size: 10, weight: .black))
                            .foregroundColor(.white)
                    }
                }
                Text(p.rawValue)
                    .font(.system(size: 11, weight: selected ? .heavy : .regular, design: .rounded))
                    .foregroundColor(selected ? .white : Color.white.opacity(0.45))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(selected
                          ? paletteColor(p).opacity(0.18)
                          : Color.clear)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .strokeBorder(selected ? paletteColor(p).opacity(0.45) : Color.clear, lineWidth: 1)
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }

    private func paletteColor(_ p: DMPaletteName) -> Color {
        switch p {
        case .ember:  return Color(h: 270, s: 55, l: 52)
        case .ash:    return Color(h: 215, s: 30, l: 58)
        case .copper: return Color(h: 178, s: 60, l: 48)
        }
    }

    // MARK: - Segment button

    private func segmentButton(title: String, selected: Bool,
                                action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13, weight: selected ? .heavy : .regular, design: .rounded))
                .foregroundColor(selected ? .white : Color.white.opacity(0.40))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 9)
                .background(
                    Group {
                        if selected {
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .fill(
                                    LinearGradient(
                                        colors: [NC.tealGlow.opacity(0.7), NC.purpleGlow.opacity(0.5)],
                                        startPoint: .topLeading, endPoint: .bottomTrailing
                                    )
                                )
                        } else {
                            Color.clear
                        }
                    }
                )
                .animation(.easeInOut(duration: 0.18), value: selected)
        }
        .buttonStyle(PlainButtonStyle())
    }

    // MARK: - Action row

    private func actionRow(icon: String, title: String, tint: Color,
                            destructive: Bool = false,
                            action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(tint)
                    .frame(width: 36, height: 36)
                    .background(
                        Circle()
                            .fill(tint.opacity(0.12))
                    )

                Text(title)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundColor(destructive ? tint : .white)

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(Color.white.opacity(0.22))
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .buttonStyle(PlainButtonStyle())
    }
}
