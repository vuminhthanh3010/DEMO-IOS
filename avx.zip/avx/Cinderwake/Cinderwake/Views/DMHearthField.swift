import SwiftUI

/// A compact ember-reactor: game data moves on a telemetry rail while the
/// board remains the dominant, tactile object in the screen.
struct DMHearthField: View {
    let mode: DMMode
    let difficulty: DMDifficulty
    let existing: DMPuzzle?
    @ObservedObject var holder: DMConductorHolder
    let onExit: () -> Void
    let onWin: () -> Void

    @EnvironmentObject var vault: DMVault
    @State private var showExitConfirm = false
    @State private var targetExpanded = false

    var body: some View {
        let conductor = holder.ensure(mode: mode, difficulty: difficulty,
                                      existing: existing, vault: vault,
                                      hintsEnabled: vault.hintsOn)
        GeometryReader { geo in
            let width = geo.size.width
            let height = geo.size.height
            let top = geo.safeAreaInsets.top
            let bottom = geo.safeAreaInsets.bottom
            let reactorSize = min(width - 28, height * 0.585)
            let center = CGPoint(x: width / 2, y: top + 45 + reactorSize / 2)

            ZStack {
                DMBackdrop(tone: .hearth, palette: vault.paletteName)
                telemetryRail(conductor, width: width, top: top)
                reactor(conductor, size: reactorSize).position(center)
                targetWafer(conductor, center: center, size: reactorSize)
                actionOrbit(conductor, width: width, center: center,
                            size: reactorSize)
                lowerMeta(conductor, width: width, height: height, bottom: bottom)
                if conductor.isPaused { pauseOverlay(conductor) }
            }
        }
        .onAppear {
            #if DEBUG
            if CommandLine.arguments.contains("-DMUnattended") {
                DMAutopilot.start(conductor: conductor) { onWin() }
            }
            #endif
        }
        .onChange(of: conductor.isFinished) { finished in
            if finished { DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { onWin() } }
        }
        .alert(isPresented: $showExitConfirm) {
            Alert(title: Text("Leave hearth?"),
                  message: Text("Your progress is saved — you can resume from Home."),
                  primaryButton: .destructive(Text("Leave")) { conductor.stopTimer(); onExit() },
                  secondaryButton: .cancel())
        }
    }

    // MARK: Telemetry rail

    private func telemetryRail(_ c: DMHearthConductor, width: CGFloat, top: CGFloat) -> some View {
        HStack(spacing: 7) {
            Button { showExitConfirm = true } label: {
                Image(systemName: "arrow.left").font(.system(size: 13, weight: .bold))
                    .foregroundColor(.white).frame(width: 36, height: 36)
                    .background(Circle().fill(Color.black.opacity(0.28)))
                    .overlay(Circle().strokeBorder(Color.white.opacity(0.13), lineWidth: 1))
            }
            .buttonStyle(PlainButtonStyle()).accessibilityIdentifier("game.exit")
            telemetryCell("MOVES", "\(c.puzzle.moveCount)/\(c.puzzle.plannedLength)", "circle.hexagongrid.fill")
            telemetryCell("HEAT", "\(Int(c.completionPercent * 100))%", "waveform.path.ecg")
            telemetryCell("TIME", c.elapsedString, "timer")
            Spacer(minLength: 0)
            Text(mode == .match ? "MATCH" : "BEACON")
                .font(.system(size: 9, weight: .heavy, design: .rounded)).tracking(1.4)
                .foregroundColor(NC.tealGlow).padding(.horizontal, 8).padding(.vertical, 6)
                .background(Capsule().fill(NC.tealGlow.opacity(0.12)))
                .overlay(Capsule().strokeBorder(NC.tealGlow.opacity(0.22), lineWidth: 1))
        }
        .padding(.horizontal, 14).frame(width: width).position(x: width / 2, y: top + 24)
    }

    private func telemetryCell(_ caption: String, _ value: String, _ icon: String) -> some View {
        VStack(alignment: .leading, spacing: 1) {
            HStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 8, weight: .bold))
                Text(caption).font(.system(size: 7, weight: .heavy, design: .rounded)).tracking(0.8)
            }.foregroundColor(Color.white.opacity(0.38))
            Text(value).font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundColor(.white.opacity(0.92)).lineLimit(1)
        }
        .padding(.horizontal, 7).padding(.vertical, 5)
        .background(RoundedRectangle(cornerRadius: 8, style: .continuous).fill(Color.black.opacity(0.23)))
    }

    // MARK: Reactor

    private func reactor(_ c: DMHearthConductor, size: CGFloat) -> some View {
        ZStack {
            Circle().stroke(AngularGradient(colors: [NC.tealGlow.opacity(0.08), NC.purpleGlow.opacity(0.55), NC.tealGlow.opacity(0.08)], center: .center),
                            style: StrokeStyle(lineWidth: 1, dash: [3, 7]))
                .frame(width: size * 1.04, height: size * 1.04)
            Circle().stroke(NC.tealGlow.opacity(0.12), lineWidth: 7)
                .frame(width: size * 0.93, height: size * 0.93).blur(radius: 3)
            Circle().fill(RadialGradient(colors: [NC.purpleGlow.opacity(0.24), Color.black.opacity(0.20), .clear], center: .center, startRadius: 0, endRadius: size * 0.53))
                .frame(width: size * 1.14, height: size * 1.14)
            DMHexBoardCanvas(board: c.puzzle.board, target: c.puzzle.target,
                             chill: c.puzzle.rune.current, pulse: c.pulseAt,
                             wobble: c.wobbleAt, showTargetOutline: true,
                             onTap: { c.tap($0) })
                .frame(width: size * 0.87, height: size * 0.87)
            Circle().trim(from: 0, to: CGFloat(c.completionPercent))
                .stroke(LinearGradient(colors: [NC.tealGlow, NC.purpleGlow], startPoint: .leading, endPoint: .trailing),
                        style: StrokeStyle(lineWidth: 4, lineCap: .round))
                .rotationEffect(.degrees(-90)).frame(width: size, height: size)
                .shadow(color: NC.tealGlow.opacity(0.55), radius: 6)
        }.frame(width: size, height: size)
    }

    // MARK: Target wafer

    private func targetWafer(_ c: DMHearthConductor, center: CGPoint, size: CGFloat) -> some View {
        let point = CGPoint(x: center.x + size * 0.31, y: center.y - size * 0.34)
        return Group {
            if targetExpanded {
                DMTargetChip(target: c.puzzle.target, boardMatch: c.puzzle.board, side: size)
                    .onTapGesture { withAnimation(.spring(response: 0.32, dampingFraction: 0.75)) { targetExpanded = false } }
                    .position(point).transition(.scale.combined(with: .opacity))
            } else {
                Button { withAnimation(.spring(response: 0.32, dampingFraction: 0.75)) { targetExpanded = true } } label: {
                    ZStack {
                        Circle().fill(Color.black.opacity(0.48))
                        Circle().strokeBorder(NC.tealGlow.opacity(0.48), lineWidth: 1)
                        Image(systemName: "scope").font(.system(size: 13, weight: .bold)).foregroundColor(NC.tealGlow)
                    }.frame(width: 34, height: 34)
                }
                .buttonStyle(PlainButtonStyle()).position(point).accessibilityIdentifier("game.target")
            }
        }
    }

    // MARK: Action orbit

    private func actionOrbit(_ c: DMHearthConductor, width: CGFloat, center: CGPoint, size: CGFloat) -> some View {
        let y = center.y + size * 0.57
        return ZStack {
            orbitalButton("lightbulb.fill", "HINT", "\(c.puzzle.hintsLeft)", Color(h: 54, s: 87, l: 61), vault.hintsOn) { _ = c.requestHint() }
                .position(x: width * 0.23, y: y).accessibilityIdentifier("game.hint")
            Button { withAnimation(.spring(response: 0.28, dampingFraction: 0.7)) { c.isPaused.toggle() } } label: {
                ZStack {
                    Circle().fill(LinearGradient(colors: [NC.tealGlow, NC.purpleGlow], startPoint: .topLeading, endPoint: .bottomTrailing))
                    Circle().strokeBorder(Color.white.opacity(0.27), lineWidth: 1)
                    Image(systemName: c.isPaused ? "play.fill" : "pause.fill").font(.system(size: 20, weight: .heavy)).foregroundColor(.white)
                }.frame(width: 62, height: 62).shadow(color: NC.tealGlow.opacity(0.48), radius: 14, x: 0, y: 6)
            }
            .buttonStyle(ScaleButtonStyle()).position(x: width * 0.5, y: y - 5).accessibilityIdentifier("game.pause")
            orbitalButton("arrow.uturn.backward", "UNDO", "\(c.puzzle.undosLeft)", Color(h: 262, s: 68, l: 68), true) { c.undo() }
                .position(x: width * 0.77, y: y).accessibilityIdentifier("game.undo")
        }
    }

    private func orbitalButton(_ icon: String, _ caption: String, _ badge: String, _ tint: Color, _ enabled: Bool, action: @escaping () -> Void) -> some View {
        Button { guard enabled else { return }; DMHaptics.shared.fire(.light); action() } label: {
            VStack(spacing: 4) {
                ZStack(alignment: .topTrailing) {
                    Circle().fill(tint.opacity(enabled ? 0.17 : 0.06))
                        .overlay(Circle().strokeBorder(tint.opacity(enabled ? 0.52 : 0.16), lineWidth: 1)).frame(width: 48, height: 48)
                    Image(systemName: icon).font(.system(size: 17, weight: .semibold)).foregroundColor(tint.opacity(enabled ? 1 : 0.28)).frame(width: 48, height: 48)
                    Text(badge).font(.system(size: 9, weight: .black, design: .rounded)).foregroundColor(.white)
                        .padding(.horizontal, 5).padding(.vertical, 2).background(Capsule().fill(tint.opacity(enabled ? 1 : 0.35))).offset(x: 8, y: -5)
                }
                Text(caption).font(.system(size: 8, weight: .heavy, design: .rounded)).tracking(1.2).foregroundColor(Color.white.opacity(enabled ? 0.52 : 0.22))
            }
        }.buttonStyle(PlainButtonStyle()).disabled(!enabled)
    }

    private func lowerMeta(_ c: DMHearthConductor, width: CGFloat, height: CGFloat, bottom: CGFloat) -> some View {
        HStack(spacing: 12) {
            metaButton("arrow.counterclockwise", "REPLAY") { DMHaptics.shared.fire(.warn); c.resetSameSeed() }
            Circle().fill(Color.white.opacity(0.12)).frame(width: 3, height: 3)
            metaButton("flame.fill", "NEW HEARTH") { DMHaptics.shared.fire(.medium); c.reforge() }
            Spacer()
            Text(bestLabel).font(.system(size: 9, weight: .heavy, design: .rounded)).tracking(1.1).foregroundColor(Color.white.opacity(0.32))
        }.padding(.horizontal, 22).frame(width: width).position(x: width / 2, y: height - max(18, bottom * 0.55))
    }

    private var bestLabel: String {
        let key = DMStats.key(mode, difficulty)
        return vault.stats.bestMoves[key].map { "BEST \($0)" } ?? "NO BEST"
    }

    private func metaButton(_ icon: String, _ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 10, weight: .bold))
                Text(title).font(.system(size: 9, weight: .heavy, design: .rounded)).tracking(1.1)
            }.foregroundColor(Color.white.opacity(0.44))
        }.buttonStyle(PlainButtonStyle())
    }

    private func pauseOverlay(_ c: DMHearthConductor) -> some View {
        ZStack {
            DMBlurCanvas(style: .systemUltraThinMaterialDark).ignoresSafeArea()
            VStack(spacing: 22) {
                Circle().fill(NC.tealGlow.opacity(0.14)).frame(width: 96, height: 96)
                    .overlay(Image(systemName: "pause.fill").font(.system(size: 28, weight: .heavy)).foregroundColor(NC.tealGlow))
                    .overlay(Circle().strokeBorder(NC.tealGlow.opacity(0.55), lineWidth: 1))
                Text("REACTOR PAUSED").font(.system(size: 16, weight: .heavy, design: .rounded)).tracking(3).foregroundColor(.white)
                Button { withAnimation(.spring()) { c.isPaused = false } } label: {
                    Text("RESUME FLOW").font(.system(size: 13, weight: .heavy, design: .rounded)).tracking(1.8)
                }.buttonStyle(CrystalPillStyle(tint: NC.tealGlow))
            }
        }
    }
}
