import SwiftUI

/// Home screen — Night Crystal redesign.
/// Layout: VStack chuẩn, không dùng radial/position tuyệt đối.
/// Top: title + stats pill
/// Middle: Mode selector (2 cards) + Difficulty selector (3 pills)
/// Centre: Big PLAY button
/// Bottom: Palette switcher + badge dots + share
struct DMForgeGate: View {
    let onPlay: (DMMode, DMDifficulty, DMPuzzle?) -> Void
    let onOpenSettings: () -> Void
    let onOpenGuide: () -> Void

    @EnvironmentObject var vault: DMVault
    @State private var selectedMode: DMMode = .match
    @State private var selectedDiff: DMDifficulty = .ember
    @State private var showingRelay: Bool = false

    var body: some View {
        GeometryReader { geo in
            let W = geo.size.width
            let safeTop = geo.safeAreaInsets.top
            let safeBottom = geo.safeAreaInsets.bottom

            ZStack {
                DMBackdrop(tone: .forge, palette: vault.paletteName)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        // ── Top bar ──────────────────────────────────────────
                        topBar(W: W, safeTop: safeTop)

                        // ── Stats pill ───────────────────────────────────────
                        statsPill
                            .padding(.top, 12)
                            .padding(.horizontal, 24)

                        // ── Mode selector ────────────────────────────────────
                        VStack(alignment: .leading, spacing: 8) {
                            sectionLabel("MODE")
                            modeSelector
                        }
                        .padding(.top, 24)
                        .padding(.horizontal, 20)

                        // ── Difficulty selector ──────────────────────────────
                        VStack(alignment: .leading, spacing: 8) {
                            sectionLabel("DIFFICULTY")
                            diffSelector
                        }
                        .padding(.top, 20)
                        .padding(.horizontal, 20)

                        // ── Play button ──────────────────────────────────────
                        playButton
                            .padding(.top, 28)
                            .padding(.horizontal, 20)

                        // ── Saved run discard ────────────────────────────────
                        if vault.savedRun != nil {
                            discardSaved
                                .padding(.top, 10)
                        }

                        // ── Bottom strip ─────────────────────────────────────
                        bottomStrip
                            .padding(.top, 28)
                            .padding(.horizontal, 20)
                            .padding(.bottom, safeBottom + 16)
                    }
                }
            }
            .sheet(isPresented: $showingRelay) {
                DMRelayCard(payload: [
                    "Cinderwake — a hex hearth puzzle. \(vault.stats.totalWins) wins so far."
                ])
            }
            .onAppear {
                selectedMode = vault.defaultMode
                selectedDiff = vault.defaultDifficulty
            }
        }
    }

    // MARK: - Top bar

    private func topBar(W: CGFloat, safeTop: CGFloat) -> some View {
        HStack(alignment: .center) {
            // Title
            VStack(alignment: .leading, spacing: 2) {
                Text("CINDERWAKE")
                    .font(.system(size: 22, weight: .heavy, design: .rounded))
                    .tracking(4)
                    .foregroundColor(NC.tealGlow)
                Text("HEX HEARTH PUZZLE")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(3)
                    .foregroundColor(NC.tealGlow.opacity(0.75))
            }

            Spacer()

            // Guide + Settings
            HStack(spacing: 10) {
                iconButton(icon: "book.closed.fill", id: "home.guide", action: onOpenGuide)
                iconButton(icon: "slider.horizontal.3", id: "home.settings", action: onOpenSettings)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, safeTop + 14)
        .padding(.bottom, 4)
    }

    private func iconButton(icon: String, id: String, action: @escaping () -> Void) -> some View {
        Button(action: {
            DMHaptics.shared.fire(.light)
            action()
        }) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white.opacity(0.85))
                .frame(width: 40, height: 40)
                .background(
                    Circle()
                        .fill(Color(h: 255, s: 35, l: 18).opacity(0.7))
                        .overlay(Circle().strokeBorder(Color.white.opacity(0.10), lineWidth: 1))
                )
        }
        .buttonStyle(PlainButtonStyle())
        .accessibilityIdentifier(id)
    }

    // MARK: - Stats pill

    private var statsPill: some View {
        HStack(spacing: 14) {
            Label("\(vault.stats.currentStreak) streak", systemImage: "flame.fill")
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .foregroundColor(NC.tealGlow)

            Rectangle()
                .fill(Color.white.opacity(0.12))
                .frame(width: 1, height: 14)

            Label("\(vault.stats.totalWins) wins", systemImage: "trophy.fill")
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .foregroundColor(NC.purpleGlow)

            Spacer()

            // Badge dots
            HStack(spacing: 5) {
                ForEach(DMBadge.allCases, id: \.self) { b in
                    Circle()
                        .fill(vault.badges.contains(b)
                              ? NC.tealGlow
                              : Color.white.opacity(0.14))
                        .frame(width: 6, height: 6)
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(h: 255, s: 35, l: 14).opacity(0.65))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.08), lineWidth: 1)
                )
        )
    }

    // MARK: - Section label

    private func sectionLabel(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 10, weight: .heavy, design: .rounded))
            .tracking(3)
            .foregroundColor(Color.white.opacity(0.40))
    }

    // MARK: - Mode selector (2 equal cards)

    private var modeSelector: some View {
        HStack(spacing: 12) {
            ForEach(DMMode.allCases, id: \.self) { mode in
                modeCard(mode)
            }
        }
    }

    private func modeCard(_ mode: DMMode) -> some View {
        let selected = selectedMode == mode
        return Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                selectedMode = mode
            }
            DMHaptics.shared.fire(.light)
        } label: {
            VStack(spacing: 8) {
                ZStack {
                    Circle()
                        .fill(selected ? NC.tealGlow.opacity(0.18) : Color.clear)
                        .frame(width: 44, height: 44)
                    Image(systemName: mode == .match ? "square.grid.3x3.fill" : "sun.max.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(selected ? NC.tealGlow : Color.white.opacity(0.45))
                }

                Text(mode.title.uppercased())
                    .font(.system(size: 13, weight: .heavy, design: .rounded))
                    .tracking(1.5)
                    .foregroundColor(selected ? .white : Color.white.opacity(0.45))

                Text(mode.summary)
                    .font(.system(size: 11, weight: .regular, design: .rounded))
                    .foregroundColor(selected ? Color.white.opacity(0.72) : Color.white.opacity(0.28))
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .padding(.horizontal, 10)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(
                        selected
                        ? LinearGradient(
                            colors: [
                                Color(h: 255, s: 40, l: 20).opacity(0.85),
                                Color(h: 270, s: 45, l: 14).opacity(0.85)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                          )
                        : LinearGradient(
                            colors: [Color(h: 255, s: 28, l: 12).opacity(0.6),
                                     Color(h: 260, s: 25, l: 9).opacity(0.6)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                          )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .strokeBorder(
                                selected
                                    ? LinearGradient(colors: [NC.tealGlow.opacity(0.55), NC.purpleGlow.opacity(0.35)],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing)
                                    : LinearGradient(colors: [Color.white.opacity(0.08), Color.white.opacity(0.04)],
                                                     startPoint: .top, endPoint: .bottom),
                                lineWidth: 1.2
                            )
                    )
            )
            .shadow(color: selected ? NC.tealGlow.opacity(0.20) : .clear, radius: 10, x: 0, y: 4)
        }
        .buttonStyle(PlainButtonStyle())
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: selected)
    }

    // MARK: - Difficulty selector (3 pills)

    private var diffSelector: some View {
        HStack(spacing: 10) {
            ForEach(DMDifficulty.allCases, id: \.self) { diff in
                diffPill(diff)
            }
        }
    }

    private func diffPill(_ diff: DMDifficulty) -> some View {
        let selected = selectedDiff == diff
        return Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                selectedDiff = diff
            }
            DMHaptics.shared.fire(.light)
        } label: {
            VStack(spacing: 5) {
                // Glow dots
                HStack(spacing: 4) {
                    ForEach(0..<3, id: \.self) { i in
                        Circle()
                            .fill(i <= diff.rawValue
                                  ? (selected ? NC.tealGlow : Color.white.opacity(0.55))
                                  : Color.white.opacity(0.15))
                            .frame(width: 6, height: 6)
                    }
                }
                Text(diff.title.uppercased())
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .tracking(1.2)
                    .foregroundColor(selected ? .white : Color.white.opacity(0.45))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(
                        selected
                        ? LinearGradient(
                            colors: [Color(h: 255, s: 40, l: 20).opacity(0.85),
                                     Color(h: 270, s: 45, l: 14).opacity(0.85)],
                            startPoint: .top, endPoint: .bottom
                          )
                        : LinearGradient(
                            colors: [Color(h: 255, s: 28, l: 12).opacity(0.55),
                                     Color(h: 260, s: 25, l: 9).opacity(0.55)],
                            startPoint: .top, endPoint: .bottom
                          )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .strokeBorder(
                                selected ? NC.tealGlow.opacity(0.50) : Color.white.opacity(0.07),
                                lineWidth: 1.2
                            )
                    )
            )
            .shadow(color: selected ? NC.tealGlow.opacity(0.22) : .clear, radius: 8, x: 0, y: 3)
        }
        .buttonStyle(PlainButtonStyle())
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: selected)
    }

    // MARK: - Play button

    private var playButton: some View {
        playButtonContent
    }

    @ViewBuilder
    private var playButtonContent: some View {
        let hasSaved = vault.savedRun != nil
        let label = hasSaved ? "RESUME" : "REKINDLE"
        let sub = hasSaved
            ? "\(vault.savedRun!.mode.title) · \(vault.savedRun!.difficulty.title)"
            : "\(selectedMode.title) · \(selectedDiff.title)"

        Button {
            DMHaptics.shared.fire(.medium)
            if hasSaved, let saved = vault.savedRun {
                onPlay(saved.mode, saved.difficulty, saved)
            } else {
                onPlay(selectedMode, selectedDiff, nil)
            }
        } label: {
            HStack(spacing: 14) {
                Image(systemName: hasSaved ? "arrow.clockwise.circle.fill" : "flame.fill")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)

                VStack(alignment: .leading, spacing: 2) {
                    Text(label)
                        .font(.system(size: 20, weight: .heavy, design: .rounded))
                        .tracking(2.5)
                        .foregroundColor(.white)
                    Text(sub)
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundColor(Color.white.opacity(0.70))
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color.white.opacity(0.55))
            }
            .padding(.horizontal, 22)
            .padding(.vertical, 18)
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(
                            LinearGradient(
                                colors: [NC.tealGlow, NC.purpleGlow.opacity(0.85)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.20), lineWidth: 1)
                }
            )
            .shadow(color: NC.tealGlow.opacity(0.45), radius: 16, x: 0, y: 6)
        }
        .buttonStyle(ScaleButtonStyle())
        .accessibilityIdentifier("home.play")
    }

    // MARK: - Discard saved

    private var discardSaved: some View {
        Button {
            vault.savedRun = nil
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "xmark.circle")
                    .font(.system(size: 12, weight: .medium))
                Text("discard saved · start fresh")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
            }
            .foregroundColor(Color.white.opacity(0.38))
        }
        .buttonStyle(PlainButtonStyle())
        .frame(maxWidth: .infinity)
    }

    // MARK: - Bottom strip

    private var bottomStrip: some View {
        HStack(alignment: .center) {
            // Palette switcher
            HStack(spacing: 8) {
                ForEach(DMPaletteName.allCases, id: \.self) { p in
                    Button {
                        vault.paletteName = p
                    } label: {
                        ZStack {
                            Circle()
                                .fill(paletteDotColor(p))
                                .frame(width: 22, height: 22)
                            if vault.paletteName == p {
                                Circle()
                                    .strokeBorder(Color.white, lineWidth: 2)
                                    .frame(width: 22, height: 22)
                            }
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }

            Spacer()

            // Share
            Button {
                showingRelay = true
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Color.white.opacity(0.65))
                    .frame(width: 38, height: 38)
                    .background(
                        Circle()
                            .fill(Color(h: 255, s: 30, l: 16).opacity(0.65))
                            .overlay(Circle().strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
                    )
            }
            .buttonStyle(PlainButtonStyle())
            .accessibilityIdentifier("home.share")
        }
    }

    private func paletteDotColor(_ p: DMPaletteName) -> Color {
        switch p {
        case .ember:  return Color(h: 270, s: 55, l: 52)
        case .ash:    return Color(h: 215, s: 30, l: 58)
        case .copper: return Color(h: 178, s: 60, l: 48)
        }
    }
}

// Small brass rivet decoration — kept for compatibility
struct RivetDot: View {
    var body: some View {
        Circle()
            .fill(NC.tealGlow.opacity(0.5))
    }
}
