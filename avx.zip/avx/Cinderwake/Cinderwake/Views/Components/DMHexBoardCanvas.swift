import SwiftUI

/// Renders the hexagonal board and dispatches taps back to the conductor.
struct DMHexBoardCanvas: View {
    let board: DMHearth
    let target: DMHearth
    let chill: DMHexCoord?
    let pulse: DMHexCoord?
    let wobble: DMHexCoord?
    let showTargetOutline: Bool
    let onTap: (DMHexCoord) -> Void

    var body: some View {
        GeometryReader { geo in
            let bounds = min(geo.size.width, geo.size.height)
            let radius = board.radius
            let cellSize = boardCellSize(bounds: bounds, radius: radius)
            let hexW = cellSize * sqrt(3.0)
            let hexH = cellSize * 2

            ZStack {
                ForEach(board.cells, id: \.self) { c in
                    let px = c.pixel(cellSize: Double(cellSize))
                    let matched = board.level(at: c) == target.level(at: c)
                    DMHexFace(
                        level: board.level(at: c),
                        side: cellSize,
                        isChill: chill == c,
                        isTarget: showTargetOutline && matched,
                        pulse: pulse == c
                    )
                    .frame(width: hexW, height: hexH)
                    .position(
                        x: geo.size.width  / 2 + CGFloat(px.x),
                        y: geo.size.height / 2 + CGFloat(px.y)
                    )
                    .modifier(DMWobbleModifier(active: wobble == c))
                    .contentShape(DMHexShape())
                    .onTapGesture { onTap(c) }
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
    }

    private func boardCellSize(bounds: CGFloat, radius: Int) -> CGFloat {
        let widthFit  = bounds / (sqrt(3.0) * CGFloat(2 * radius + 1) + 0.4)
        let heightFit = bounds / (CGFloat(2 * radius) * 1.5 + 2)
        return max(6, min(widthFit, heightFit))
    }
}
