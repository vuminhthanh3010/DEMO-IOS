import SwiftUI

/// Miniature target board — glass card, Night Crystal style.
struct DMTargetChip: View {
    let target: DMHearth
    let boardMatch: DMHearth
    let side: CGFloat

    var body: some View {
        let chipW: CGFloat = min(side * 0.30, 112)
        let chipH: CGFloat = chipW * 1.05
        let cellSize: CGFloat = chipW * 0.092

        ZStack {
            // Glass background
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            Color(h: 255, s: 35, l: 16).opacity(0.88),
                            Color(h: 260, s: 30, l: 11).opacity(0.88)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(
                            LinearGradient(
                                colors: [
                                    NC.tealGlow.opacity(0.45),
                                    NC.purpleGlow.opacity(0.25)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1.2
                        )
                )
                .shadow(color: NC.tealGlow.opacity(0.15), radius: 8, x: 0, y: 4)

            VStack(spacing: 4) {
                // "TARGET" label
                Text("TARGET")
                    .font(.system(size: 8, weight: .heavy, design: .rounded))
                    .tracking(2)
                    .foregroundColor(NC.tealGlow)

                // Mini board
                ZStack {
                    ForEach(target.cells, id: \.self) { c in
                        let px = c.pixel(cellSize: Double(cellSize))
                        let matched = boardMatch.level(at: c) == target.level(at: c)
                        DMHexFace(
                            level: target.level(at: c),
                            side: cellSize,
                            isChill: false,
                            isTarget: false,
                            pulse: false
                        )
                        .frame(width: cellSize * sqrt(3), height: cellSize * 2)
                        .position(
                            x: chipW / 2 + CGFloat(px.x),
                            y: (chipH - 20) / 2 + CGFloat(px.y) + 4
                        )
                        .opacity(matched ? 1.0 : 0.45)
                    }
                }
                .frame(width: chipW, height: chipH - 20)
            }
            .padding(.top, 6)
        }
        .frame(width: chipW, height: chipH)
    }
}
