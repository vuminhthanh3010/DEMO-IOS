import SwiftUI

// MARK: - Hex Shape

/// Pointy-top hexagon — conforms to InsettableShape so .strokeBorder works.
struct DMHexShape: InsettableShape {
    var insetAmount: CGFloat = 0

    func path(in rect: CGRect) -> Path {
        let r = rect.insetBy(dx: insetAmount, dy: insetAmount)
        var p = Path()
        let w = r.width
        let h = r.height
        let x = r.midX
        let y = r.midY
        let dx = w / 2
        let dy = h / 2
        let quarter = dy / 2
        p.move(to: CGPoint(x: x,      y: y - dy))
        p.addLine(to: CGPoint(x: x + dx, y: y - quarter))
        p.addLine(to: CGPoint(x: x + dx, y: y + quarter))
        p.addLine(to: CGPoint(x: x,      y: y + dy))
        p.addLine(to: CGPoint(x: x - dx, y: y + quarter))
        p.addLine(to: CGPoint(x: x - dx, y: y - quarter))
        p.closeSubpath()
        return p
    }

    func inset(by amount: CGFloat) -> DMHexShape {
        DMHexShape(insetAmount: insetAmount + amount)
    }
}

// MARK: - Hex Face

/// Single hex cell — Night Crystal style: dark glass base + crystal glow rings.
struct DMHexFace: View {
    let level: Int
    let side: CGFloat
    var isChill: Bool = false
    var isTarget: Bool = false
    var pulse: Bool = false
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        ZStack {
            // Glass base
            DMHexShape()
                .fill(baseFill)
                .overlay(
                    DMHexShape()
                        .strokeBorder(borderGradient, lineWidth: max(1, side * 0.045))
                )

            // Crystal glow rings per level
            if level > 0 {
                ForEach(0..<level, id: \.self) { i in
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [crystalColor(i).opacity(0.65), .clear],
                                center: .center,
                                startRadius: 0,
                                endRadius: ringR(i)
                            )
                        )
                        .frame(width: ringR(i) * 2, height: ringR(i) * 2)
                        .blur(radius: side * 0.08)
                }
                // Central pip
                Circle()
                    .fill(pipColor)
                    .frame(width: side * 0.22, height: side * 0.22)
                    .shadow(color: pipColor.opacity(0.8), radius: side * 0.08)
            }

            // Level dots
            if level > 0 {
                HStack(spacing: side * 0.12) {
                    ForEach(0..<level, id: \.self) { _ in
                        Circle()
                            .fill(pipColor)
                            .frame(width: side * 0.10, height: side * 0.10)
                    }
                }
                .offset(y: side * 0.52)
            }

            // Chill overlay
            if isChill {
                DMChillOverlay(side: side)
            }

            // Target match outline
            if isTarget {
                DMHexShape()
                    .strokeBorder(
                        LinearGradient(
                            colors: [NC.tealGlow, NC.tealGlow.opacity(0.5)],
                            startPoint: .top,
                            endPoint: .bottom
                        ),
                        lineWidth: max(1.5, side * 0.07)
                    )
                    .overlay(
                        DMHexShape()
                            .fill(NC.tealGlow.opacity(0.06))
                    )
            }

            // Hint pulse
            if pulse {
                DMHexShape()
                    .strokeBorder(Color.white.opacity(0.9), lineWidth: max(2, side * 0.09))
                    .blur(radius: side * 0.04)
            }
        }
        .frame(width: hexW, height: hexH)
    }

    // MARK: Private helpers
    private var hexW: CGFloat { side * sqrt(3.0) }
    private var hexH: CGFloat { side * 2 }

    private var baseFill: LinearGradient {
        LinearGradient(
            colors: scheme == .dark
                ? [Color(h: 255, s: 30, l: 14), Color(h: 260, s: 25, l: 10)]
                : [Color(h: 250, s: 20, l: 82), Color(h: 255, s: 18, l: 74)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    private var borderGradient: LinearGradient {
        LinearGradient(
            colors: level > 0
                ? [crystalColor(0).opacity(0.55), crystalColor(0).opacity(0.18)]
                : [Color.white.opacity(scheme == .dark ? 0.10 : 0.40),
                   Color.white.opacity(0.04)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    private func crystalColor(_ i: Int) -> Color {
        DMPalette.emberScale(level: i + 1, scheme: scheme)
    }

    private var pipColor: Color {
        DMPalette.emberScale(level: min(level, DMHearth.maxLevel), scheme: scheme)
    }

    private func ringR(_ i: Int) -> CGFloat {
        side * (0.48 + CGFloat(i) * 0.20)
    }
}

// MARK: - Chill Overlay

struct DMChillOverlay: View {
    let side: CGFloat
    var body: some View {
        ZStack {
            DMHexShape()
                .fill(DMPalette.chillTint().opacity(0.25))
            DMHexShape()
                .strokeBorder(DMPalette.chillTint().opacity(0.8), lineWidth: max(1, side * 0.07))
            Image(systemName: "snowflake")
                .font(.system(size: side * 0.65, weight: .semibold))
                .foregroundColor(DMPalette.chillTint())
                .shadow(color: DMPalette.chillTint().opacity(0.7), radius: side * 0.1)
        }
    }
}

// MARK: - Wobble Modifier

struct DMWobbleModifier: ViewModifier {
    let active: Bool
    @State private var offset: CGFloat = 0

    func body(content: Content) -> some View {
        content
            .offset(x: offset)
            .onChange(of: active) { new in
                guard new else { return }
                withAnimation(.easeInOut(duration: 0.06).repeatCount(5, autoreverses: true)) {
                    offset = 4
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                    withAnimation { offset = 0 }
                }
            }
    }
}
