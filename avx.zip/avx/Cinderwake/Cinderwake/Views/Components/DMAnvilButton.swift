import SwiftUI

/// Crystal primary CTA — wide capsule with teal/purple gradient glow.
struct DMAnvilButton: View {
    let title: String
    let subtitle: String?
    let action: () -> Void
    @State private var pressed = false

    var body: some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Text(title)
                    .font(.system(size: 18, weight: .heavy, design: .rounded))
                    .tracking(2)
                    .foregroundColor(.white)
                if let s = subtitle {
                    Text(s)
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundColor(Color.white.opacity(0.72))
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                ZStack {
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [NC.tealGlow, NC.purpleGlow.opacity(0.8)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    Capsule()
                        .strokeBorder(Color.white.opacity(0.18), lineWidth: 1)
                }
            )
            .shadow(color: NC.tealGlow.opacity(0.45), radius: 14, x: 0, y: 6)
            .scaleEffect(pressed ? 0.97 : 1)
        }
        .buttonStyle(PlainButtonStyle())
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in withAnimation(.easeInOut(duration: 0.08)) { pressed = true  } }
                .onEnded   { _ in withAnimation(.easeInOut(duration: 0.15)) { pressed = false } }
        )
    }
}

// Legacy shape — kept so nothing breaks if referenced elsewhere
struct AnvilShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width; let h = rect.height
        p.move(to: CGPoint(x: 0, y: h * 0.28))
        p.addLine(to: CGPoint(x: w * 0.06, y: 0))
        p.addLine(to: CGPoint(x: w * 0.94, y: 0))
        p.addLine(to: CGPoint(x: w, y: h * 0.28))
        p.addLine(to: CGPoint(x: w * 0.68, y: h * 0.38))
        p.addLine(to: CGPoint(x: w * 0.62, y: h * 0.62))
        p.addLine(to: CGPoint(x: w * 0.88, y: h * 0.78))
        p.addLine(to: CGPoint(x: w * 0.96, y: h))
        p.addLine(to: CGPoint(x: w * 0.04, y: h))
        p.addLine(to: CGPoint(x: w * 0.12, y: h * 0.78))
        p.addLine(to: CGPoint(x: w * 0.38, y: h * 0.62))
        p.addLine(to: CGPoint(x: w * 0.32, y: h * 0.38))
        p.closeSubpath()
        return p
    }
}
