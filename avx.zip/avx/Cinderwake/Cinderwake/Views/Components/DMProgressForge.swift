import SwiftUI

/// Crystal progress bar — teal glow fill on dark glass track.
struct DMProgressForge: View {
    let percent: Double
    let height: CGFloat

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let filled = w * CGFloat(min(max(percent, 0), 1))

            ZStack(alignment: .leading) {
                // Track
                Capsule()
                    .fill(Color(h: 255, s: 28, l: 16).opacity(0.7))
                    .overlay(
                        Capsule()
                            .strokeBorder(Color.white.opacity(0.07), lineWidth: 1)
                    )

                // Fill
                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [NC.tealGlow, NC.purpleGlow],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: filled)
                    .shadow(color: NC.tealGlow.opacity(0.6), radius: 6, x: 0, y: 0)
            }
            .frame(width: w, height: height)
        }
        .frame(height: height)
    }
}
