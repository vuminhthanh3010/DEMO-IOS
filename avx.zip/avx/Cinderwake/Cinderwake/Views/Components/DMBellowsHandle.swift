import SwiftUI

/// Side icon-button — kept minimal, now a glass pill.
struct DMBellowsHandle: View {
    let side: Side
    let label: String
    let iconName: String
    let action: () -> Void

    enum Side { case leading, trailing }

    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: iconName)
                    .font(.system(size: 17, weight: .semibold))
                Text(label)
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .tracking(1.2)
            }
            .foregroundColor(.white)
            .padding(.vertical, 14)
            .padding(.horizontal, 10)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(h: 255, s: 35, l: 20).opacity(0.82),
                                Color(h: 260, s: 30, l: 14).opacity(0.82)
                            ],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .strokeBorder(Color.white.opacity(0.12), lineWidth: 1)
                    )
            )
            .shadow(color: .black.opacity(0.3), radius: 6, x: 0, y: 3)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// Legacy shape — kept for compatibility
struct BellowsShape: Shape {
    let side: DMBellowsHandle.Side
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width; let h = rect.height
        if side == .leading {
            p.move(to: CGPoint(x: 0, y: 0))
            p.addLine(to: CGPoint(x: w * 0.85, y: h * 0.18))
            p.addLine(to: CGPoint(x: w, y: h * 0.5))
            p.addLine(to: CGPoint(x: w * 0.85, y: h * 0.82))
            p.addLine(to: CGPoint(x: 0, y: h))
        } else {
            p.move(to: CGPoint(x: w, y: 0))
            p.addLine(to: CGPoint(x: w * 0.15, y: h * 0.18))
            p.addLine(to: CGPoint(x: 0, y: h * 0.5))
            p.addLine(to: CGPoint(x: w * 0.15, y: h * 0.82))
            p.addLine(to: CGPoint(x: w, y: h))
        }
        p.closeSubpath()
        return p
    }
}
