#if DEBUG
import SwiftUI

/// Rehearsal harness — Night Crystal reskin.
/// Renders any screen inside a fixed device frame for layout smoke-testing.
struct DMRehearsalStage: View {
    let onExit: () -> Void

    @EnvironmentObject var vault: DMVault
    @State private var frame:  DMRehearsalFrame  = .std
    @State private var screen: DMRehearsalScreen = .home
    @StateObject private var holder = DMConductorHolder()

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()

                VStack(spacing: 10) {
                    // ── Top bar ──────────────────────────────────────────────
                    HStack {
                        Button(action: onExit) {
                            HStack(spacing: 6) {
                                Image(systemName: "chevron.left.circle.fill")
                                    .font(.system(size: 16, weight: .semibold))
                                Text("EXIT")
                                    .font(.system(size: 13, weight: .heavy, design: .rounded))
                                    .tracking(1)
                            }
                            .foregroundColor(.white)
                        }
                        .buttonStyle(PlainButtonStyle())

                        Spacer()

                        Text("REHEARSAL")
                            .font(.system(size: 13, weight: .heavy, design: .rounded))
                            .tracking(3)
                            .foregroundColor(.white)

                        Spacer()

                        Text("\(Int(frame.size.width))×\(Int(frame.size.height))")
                            .font(.system(size: 11, weight: .semibold, design: .monospaced))
                            .foregroundColor(Color.white.opacity(0.5))
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, geo.safeAreaInsets.top + 8)

                    // ── Frame picker ─────────────────────────────────────────
                    HStack(spacing: 8) {
                        ForEach(DMRehearsalFrame.allCases, id: \.self) { f in
                            rehearsalPill(title: f.title, selected: frame == f) {
                                frame = f
                            }
                            .accessibilityIdentifier("rehearse.frame.\(f.rawValue)")
                        }
                    }
                    .padding(.horizontal, 16)

                    // ── Screen picker ────────────────────────────────────────
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(DMRehearsalScreen.allCases, id: \.self) { s in
                                rehearsalPill(title: s.title, selected: screen == s) {
                                    screen = s
                                }
                                .accessibilityIdentifier("rehearse.screen.\(s.rawValue)")
                            }
                        }
                        .padding(.horizontal, 16)
                    }

                    // ── Scaled frame ─────────────────────────────────────────
                    Spacer()

                    let target = frame.size
                    let avail  = CGSize(
                        width:  geo.size.width - 32,
                        height: geo.size.height - 220
                    )
                    let scale  = min(avail.width / target.width,
                                     avail.height / target.height,
                                     1.0)

                    ZStack {
                        RoundedRectangle(cornerRadius: 44 * scale, style: .continuous)
                            .strokeBorder(NC.tealGlow, lineWidth: 2)
                            .frame(width: target.width * scale,
                                   height: target.height * scale)

                        screenBody
                            .frame(width: target.width, height: target.height)
                            .clipShape(RoundedRectangle(cornerRadius: 44, style: .continuous))
                            .scaleEffect(scale)
                    }
                    .frame(width: target.width * scale,
                           height: target.height * scale)

                    Spacer()
                }
            }
        }
    }

    // MARK: - Screen body

    @ViewBuilder
    private var screenBody: some View {
        switch screen {
        case .splash:
            DMEmberGate(onFinish: {})
                .environmentObject(vault)

        case .home:
            DMForgeGate(
                onPlay: { _, _, _ in },
                onOpenSettings: {},
                onOpenGuide: {}
            )
            .environmentObject(vault)

        case .game:
            DMHearthField(
                mode: .match, difficulty: .coal, existing: nil,
                holder: holder, onExit: {}, onWin: {}
            )
            .environmentObject(vault)

        case .tally:
            DMTallyForge(
                conductor: holder.ensure(
                    mode: .match, difficulty: .coal,
                    existing: nil, vault: vault,
                    hintsEnabled: true
                ),
                onReforge: { _, _ in },
                onHome: {}
            )
            .environmentObject(vault)

        case .settings:
            DMBellowsPanel(onClose: {})
                .environmentObject(vault)

        case .guide:
            DMPrimerScroll(onClose: {})
                .environmentObject(vault)
        }
    }

    // MARK: - Pill helper

    private func rehearsalPill(title: String, selected: Bool,
                                action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 11, weight: .heavy, design: .rounded))
                .tracking(1)
                .foregroundColor(selected ? NC.deepVoid : Color.white.opacity(0.6))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(
                    Capsule()
                        .fill(selected ? NC.tealGlow : Color.white.opacity(0.10))
                )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Enums

enum DMRehearsalFrame: String, CaseIterable {
    case se, std, max

    var title: String {
        switch self {
        case .se:  return "SE"
        case .std: return "iPhone 17"
        case .max: return "Pro Max"
        }
    }

    var size: CGSize {
        switch self {
        case .se:  return CGSize(width: 375, height: 667)
        case .std: return CGSize(width: 393, height: 852)
        case .max: return CGSize(width: 440, height: 956)
        }
    }
}

enum DMRehearsalScreen: String, CaseIterable {
    case splash, home, game, tally, settings, guide

    var title: String {
        switch self {
        case .splash:   return "SPLASH"
        case .home:     return "HOME"
        case .game:     return "GAME"
        case .tally:    return "TALLY"
        case .settings: return "SETTINGS"
        case .guide:    return "GUIDE"
        }
    }
}
#endif
