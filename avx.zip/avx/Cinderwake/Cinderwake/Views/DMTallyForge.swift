import SwiftUI

/// Result / Tally screen — Night Crystal redesign.
/// Layout: VStack — hero section, stat grid, action buttons.
struct DMTallyForge: View {
    let conductor: DMHearthConductor?
    let onReforge: (DMMode, DMDifficulty) -> Void
    let onHome: () -> Void

    @EnvironmentObject var vault: DMVault
    @State private var showRelay = false
    @State private var appear   = false

    var body: some View {
        GeometryReader { geo in
            let W = geo.size.width
            let safeTop    = geo.safeAreaInsets.top
            let safeBottom = geo.safeAreaInsets.bottom

            ZStack {
                DMBackdrop(tone: .tally, palette: vault.paletteName)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        Spacer(minLength: safeTop + 20)

                        // ── Hero ─────────────────────────────────────────────
                        heroSection(W: W)

                        // ── Stats grid ───────────────────────────────────────
                        if let c = conductor {
                            statGrid(conductor: c)
                                .padding(.top, 28)
                                .padding(.horizontal, 24)
                        }

                        // ── Badges earned ────────────────────────────────────
                        badgeRow
                            .padding(.top, 24)
                            .padding(.horizontal, 24)

                        // ── Action buttons ────────────────────────────────────
                        actionButtons
                            .padding(.top, 32)
                            .padding(.horizontal, 24)
                            .padding(.bottom, safeBottom + 24)
                    }
                }
            }
            .onAppear {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.7).delay(0.1)) {
                    appear = true
                }
            }
            .sheet(isPresented: $showRelay) {
                if let c = conductor {
                    DMRelayCard(payload: [
                        "Cinderwake — \(c.mode.title) · \(c.difficulty.title) · \(c.puzzle.moveCount) moves in \(c.elapsedString)"
                    ])
                }
            }
        }
    }

    // MARK: - Hero

    @ViewBuilder
    private func heroSection(W: CGFloat) -> some View {
        let hexSize = min(W * 0.22, 90.0)
        VStack(spacing: 16) {
            ZStack {
                // Glow
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [NC.tealGlow.opacity(0.45), NC.purpleGlow.opacity(0.25), .clear],
                            center: .center,
                            startRadius: 0,
                            endRadius: hexSize * 1.8
                        )
                    )
                    .frame(width: hexSize * 3.6, height: hexSize * 3.6)
                    .blur(radius: 12)
                    .scaleEffect(appear ? 1.0 : 0.3)

                // Crystal hex
                DMHexShape()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(h: 255, s: 50, l: 24),
                                Color(h: 270, s: 55, l: 15)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: hexSize * sqrt(3), height: hexSize * 2)
                    .overlay(
                        DMHexShape()
                            .strokeBorder(
                                LinearGradient(
                                    colors: [NC.tealGlow.opacity(0.7), NC.purpleGlow.opacity(0.5)],
                                    startPoint: .top, endPoint: .bottom
                                ),
                                lineWidth: 1.8
                            )
                    )
                    .shadow(color: NC.tealGlow.opacity(0.5), radius: 20, x: 0, y: 0)
                    .scaleEffect(appear ? 1.0 : 0.4)

                // Trophy icon inside hex
                Image(systemName: "trophy.fill")
                    .font(.system(size: hexSize * 0.55, weight: .semibold))
                    .foregroundColor(NC.tealGlow)
                    .scaleEffect(appear ? 1.0 : 0.2)
            }

            VStack(spacing: 4) {
                Text("HEARTH SET")
                    .font(.system(size: 26, weight: .heavy, design: .rounded))
                    .tracking(5)
                    .foregroundColor(.white)
                    .opacity(appear ? 1 : 0)
                    .offset(y: appear ? 0 : 12)

                if let c = conductor {
                    Text("\(c.mode.title.uppercased()) · \(c.difficulty.title.uppercased())")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .tracking(3)
                        .foregroundColor(NC.tealGlow.opacity(0.8))
                        .opacity(appear ? 1 : 0)
                }
            }
        }
        .animation(.spring(response: 0.6, dampingFraction: 0.7), value: appear)
    }

    // MARK: - Stat grid

    @ViewBuilder
    private func statGrid(conductor c: DMHearthConductor) -> some View {
        let bestKey = DMStats.key(c.mode, c.difficulty)
        let items: [(String, String, String)] = buildStatItems(c, bestKey: bestKey)
        let cols = Array(repeating: GridItem(.flexible(), spacing: 12), count: 2)
        LazyVGrid(columns: cols, spacing: 12) {
            ForEach(0..<items.count, id: \.self) { i in
                statCell(icon: items[i].0, label: items[i].1, value: items[i].2)
            }
        }
    }

    private func buildStatItems(_ c: DMHearthConductor,
                                 bestKey: String) -> [(String, String, String)] {
        var items: [(String, String, String)] = [
            ("clock.fill",   "TIME",   c.elapsedString),
            ("hexagon.fill", "MOVES",  "\(c.puzzle.moveCount) / \(c.puzzle.plannedLength)"),
            ("flame.fill",   "STREAK", "\(vault.stats.currentStreak)"),
            ("trophy.fill",  "TOTAL",  "\(vault.stats.totalWins)"),
        ]
        if let b = vault.stats.bestMoves[bestKey] {
            items.append(("star.fill", "BEST", "\(b)"))
        }
        if c.lastResultAtPar {
            items.append(("checkmark.seal.fill", "PAR", "★"))
        }
        if c.lastResultFlawless {
            items.append(("sparkles", "HINTS", "0"))
        }
        return items
    }

    private func statCell(icon: String, label: String, value: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(NC.tealGlow)
                .frame(width: 32, height: 32)
                .background(
                    Circle()
                        .fill(NC.tealGlow.opacity(0.12))
                )

            VStack(alignment: .leading, spacing: 2) {
                Text(value)
                    .font(.system(size: 16, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                Text(label)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.5)
                    .foregroundColor(Color.white.opacity(0.40))
            }

            Spacer()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color(h: 255, s: 32, l: 14).opacity(0.65))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.07), lineWidth: 1)
                )
        )
    }

    // MARK: - Badge row

    private var badgeRow: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("ACHIEVEMENTS")
                .font(.system(size: 10, weight: .heavy, design: .rounded))
                .tracking(3)
                .foregroundColor(Color.white.opacity(0.35))

            HStack(spacing: 8) {
                ForEach(DMBadge.allCases, id: \.self) { b in
                    let got = vault.badges.contains(b)
                    VStack(spacing: 4) {
                        Circle()
                            .fill(got ? NC.tealGlow : Color.white.opacity(0.08))
                            .frame(width: 10, height: 10)
                            .shadow(color: got ? NC.tealGlow.opacity(0.7) : .clear, radius: 4)
                        Text(b.title)
                            .font(.system(size: 8, weight: .semibold, design: .rounded))
                            .foregroundColor(got ? NC.tealGlow : Color.white.opacity(0.22))
                            .multilineTextAlignment(.center)
                            .lineLimit(2)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color(h: 255, s: 30, l: 12).opacity(0.55))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.06), lineWidth: 1)
                )
        )
    }

    // MARK: - Action buttons

    private var actionButtons: some View {
        VStack(spacing: 12) {
            // Primary: New game
            if let c = conductor {
                Button {
                    DMHaptics.shared.fire(.medium)
                    onReforge(c.mode, c.difficulty)
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "flame.fill")
                            .font(.system(size: 18, weight: .bold))
                        Text("REKINDLE")
                            .font(.system(size: 16, weight: .heavy, design: .rounded))
                            .tracking(2)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        ZStack {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(
                                    LinearGradient(
                                        colors: [NC.tealGlow, NC.purpleGlow.opacity(0.8)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .strokeBorder(Color.white.opacity(0.18), lineWidth: 1)
                        }
                    )
                    .shadow(color: NC.tealGlow.opacity(0.4), radius: 14, x: 0, y: 5)
                }
                .buttonStyle(ScaleButtonStyle())
            }

            // Secondary row: Share + Home
            HStack(spacing: 12) {
                Button {
                    showRelay = true
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 14, weight: .semibold))
                        Text("SHARE")
                            .font(.system(size: 13, weight: .heavy, design: .rounded))
                            .tracking(1.5)
                    }
                    .foregroundColor(.white.opacity(0.85))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(Color(h: 255, s: 35, l: 18).opacity(0.65))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .strokeBorder(Color.white.opacity(0.10), lineWidth: 1)
                            )
                    )
                }
                .buttonStyle(ScaleButtonStyle())

                Button {
                    DMHaptics.shared.fire(.light)
                    onHome()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "house.fill")
                            .font(.system(size: 14, weight: .semibold))
                        Text("HOME")
                            .font(.system(size: 13, weight: .heavy, design: .rounded))
                            .tracking(1.5)
                    }
                    .foregroundColor(.white.opacity(0.85))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(Color(h: 255, s: 35, l: 18).opacity(0.65))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .strokeBorder(Color.white.opacity(0.10), lineWidth: 1)
                            )
                    )
                }
                .buttonStyle(ScaleButtonStyle())
            }
        }
    }
}
