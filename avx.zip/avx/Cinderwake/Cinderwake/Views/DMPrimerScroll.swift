import SwiftUI

/// Guide screen — Night Crystal redesign.
/// Horizontal swipe deck, each page has a crystal diorama + text.
struct DMPrimerScroll: View {
    let onClose: () -> Void

    @EnvironmentObject var vault: DMVault
    @State private var page: Int = 0

    private let pages: [PrimerPage] = [
        PrimerPage(kind: .board,
                   title: "THE HEARTH",
                   body: "A hex board of 7 cells at Ember, 19 at Coal and Blaze. Every cell holds an ember glowing at 0–3."),
        PrimerPage(kind: .kindle,
                   title: "KINDLE",
                   body: "Tap a cell below 3 — its glow rises by one crystal tier."),
        PrimerPage(kind: .burst,
                   title: "BURST",
                   body: "Tap a cell at 3 — it drops to 0 and every neighbour under 3 gains one glow."),
        PrimerPage(kind: .chill,
                   title: "CHILL RUNE",
                   body: "A blue snowflake walks the outer ring. The cell it stands on is off-limits that turn. Coal drifts one step, Blaze leaps two."),
        PrimerPage(kind: .target,
                   title: "THE TARGET",
                   body: "The corner chip shows the pattern you're chasing. Cells matching glow with a teal outline. Match them all to win."),
    ]

    var body: some View {
        GeometryReader { geo in
            let W  = geo.size.width
            let H  = geo.size.height
            let safeTop    = geo.safeAreaInsets.top
            let safeBottom = geo.safeAreaInsets.bottom

            ZStack {
                DMBackdrop(tone: .primer, palette: vault.paletteName)

                VStack(spacing: 0) {
                    // ── Header ───────────────────────────────────────────────
                    header(safeTop: safeTop, W: W)

                    // ── Page content ─────────────────────────────────────────
                    TabView(selection: $page) {
                        ForEach(0..<pages.count, id: \.self) { i in
                            pageView(pages[i], W: W, H: H)
                                .tag(i)
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    .animation(.spring(response: 0.38, dampingFraction: 0.82), value: page)

                    // ── Page dots + nav ──────────────────────────────────────
                    pageControls
                        .padding(.bottom, safeBottom + 16)
                        .padding(.top, 8)
                }
            }
        }
    }

    // MARK: - Header

    private func header(safeTop: CGFloat, W: CGFloat) -> some View {
        HStack {
            // Balance
            Color.clear.frame(width: 36, height: 36)

            Spacer()

            Text("GUIDE")
                .font(.system(size: 13, weight: .heavy, design: .rounded))
                .tracking(5)
                .foregroundColor(Color.white.opacity(0.72))

            Spacer()

            Button(action: {
                DMHaptics.shared.fire(.light)
                onClose()
            }) {
                Image(systemName: "xmark")
                    .font(.system(size: 14, weight: .heavy))
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
                    .background(
                        Circle()
                            .fill(Color(h: 255, s: 35, l: 18).opacity(0.7))
                            .overlay(Circle().strokeBorder(Color.white.opacity(0.10), lineWidth: 1))
                    )
            }
            .buttonStyle(PlainButtonStyle())
            .accessibilityIdentifier("guide.close")
        }
        .padding(.horizontal, 20)
        .padding(.top, safeTop + 12)
        .padding(.bottom, 8)
    }

    // MARK: - Page view

    private func pageView(_ p: PrimerPage, W: CGFloat, H: CGFloat) -> some View {
        VStack(spacing: 0) {
            // Diorama area
            ZStack {
                // Crystal card behind diorama
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(h: 255, s: 38, l: 14).opacity(0.82),
                                Color(h: 265, s: 42, l: 10).opacity(0.82)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .strokeBorder(
                                LinearGradient(
                                    colors: [NC.tealGlow.opacity(0.35), NC.purpleGlow.opacity(0.20)],
                                    startPoint: .topLeading, endPoint: .bottomTrailing
                                ),
                                lineWidth: 1.2
                            )
                    )
                    .shadow(color: NC.tealGlow.opacity(0.12), radius: 16, x: 0, y: 8)

                diorama(p.kind)
                    .padding(24)
            }
            .frame(height: min(H * 0.34, 240))
            .padding(.horizontal, 24)

            // Text content
            VStack(spacing: 12) {
                Text(p.title)
                    .font(.system(size: 24, weight: .heavy, design: .rounded))
                    .tracking(4)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)

                Text(p.body)
                    .font(.system(size: 14, weight: .regular, design: .rounded))
                    .foregroundColor(Color.white.opacity(0.70))
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 8)
            }
            .padding(.top, 28)
            .padding(.horizontal, 28)

            Spacer()
        }
        .padding(.top, 12)
    }

    // MARK: - Dioramas

    @ViewBuilder
    private func diorama(_ kind: PrimerPage.Kind) -> some View {
        switch kind {
        case .board:
            miniBoard(levels: [1, 0, 2, 0, 3, 0, 1])

        case .kindle:
            HStack(spacing: 20) {
                miniBoard(levels: [0, 1, 2, 0, 0, 0, 0], highlightIdx: 1)
                arrowIcon
                miniBoard(levels: [0, 2, 2, 0, 0, 0, 0], highlightIdx: 1)
            }

        case .burst:
            HStack(spacing: 20) {
                miniBoard(levels: [3, 1, 2, 0, 0, 1, 0], highlightIdx: 0)
                arrowIcon
                miniBoard(levels: [0, 2, 3, 1, 1, 2, 1], highlightIdx: 0)
            }

        case .chill:
            miniBoard(levels: [1, 0, 2, 0, 1, 0, 1], chillIdx: 3)

        case .target:
            HStack(spacing: 20) {
                miniBoard(levels: [1, 1, 1, 1, 1, 1, 1])
                Image(systemName: "arrow.right")
                    .font(.system(size: 18, weight: .heavy))
                    .foregroundColor(NC.tealGlow)
                miniBoard(levels: [1, 1, 1, 1, 1, 1, 1], targetOutline: true)
            }
        }
    }

    private var arrowIcon: some View {
        Image(systemName: "arrow.right")
            .font(.system(size: 18, weight: .heavy))
            .foregroundColor(NC.tealGlow)
    }

    private func miniBoard(
        levels: [Int],
        highlightIdx: Int? = nil,
        chillIdx: Int? = nil,
        targetOutline: Bool = false
    ) -> some View {
        ZStack {
            ForEach(0..<DMHexCoord.hexagon(radius: 1).count, id: \.self) { i in
                let cells = DMHexCoord.hexagon(radius: 1)
                let c  = cells[i]
                let px = c.pixel(cellSize: 20.0)
                DMHexFace(
                    level: levels[i % levels.count],
                    side: 20,
                    isChill: chillIdx == i,
                    isTarget: targetOutline,
                    pulse: highlightIdx == i
                )
                .frame(width: 20 * sqrt(3.0), height: 20 * 2)
                .position(x: 66 + CGFloat(px.x), y: 66 + CGFloat(px.y))
            }
        }
        .frame(width: 132, height: 132)
    }

    // MARK: - Page controls

    private var pageControls: some View {
        HStack(spacing: 0) {
            // Prev
            Button {
                if page > 0 {
                    withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) { page -= 1 }
                }
            } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 18, weight: .heavy))
                    .foregroundColor(page > 0 ? .white : Color.white.opacity(0.18))
                    .frame(width: 48, height: 48)
            }
            .buttonStyle(PlainButtonStyle())

            Spacer()

            // Dots
            HStack(spacing: 8) {
                ForEach(0..<pages.count, id: \.self) { i in
                    Capsule()
                        .fill(i == page ? NC.tealGlow : Color.white.opacity(0.20))
                        .frame(width: i == page ? 20 : 7, height: 7)
                        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: page)
                }
            }

            Spacer()

            // Next / Done
            Button {
                if page < pages.count - 1 {
                    withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) { page += 1 }
                } else {
                    DMHaptics.shared.fire(.light)
                    onClose()
                }
            } label: {
                Group {
                    if page < pages.count - 1 {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 18, weight: .heavy))
                            .foregroundColor(.white)
                    } else {
                        Text("DONE")
                            .font(.system(size: 12, weight: .heavy, design: .rounded))
                            .tracking(1.5)
                            .foregroundColor(NC.tealGlow)
                    }
                }
                .frame(width: 48, height: 48)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 20)
    }
}

// MARK: - Page model

private struct PrimerPage {
    enum Kind { case board, kindle, burst, chill, target }
    let kind: Kind
    let title: String
    let body: String
}
