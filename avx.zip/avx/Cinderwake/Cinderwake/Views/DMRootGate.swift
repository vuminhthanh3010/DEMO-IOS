import SwiftUI
import Combine

// MARK: - Stage enum

enum DMStage: Equatable {
    case splash
    case home
    case game(DMMode, DMDifficulty, DMPuzzle?)
    case tally
    case settings
    case guideScroll
    case rehearsal

    static func == (lhs: DMStage, rhs: DMStage) -> Bool {
        switch (lhs, rhs) {
        case (.splash, .splash), (.home, .home), (.tally, .tally),
             (.settings, .settings), (.guideScroll, .guideScroll),
             (.rehearsal, .rehearsal):
            return true
        case (.game(let m1, let d1, _), .game(let m2, let d2, _)):
            return m1 == m2 && d1 == d2
        default:
            return false
        }
    }
}

// MARK: - Root Gate

struct DMRootGate: View {
    @EnvironmentObject var vault: DMVault
    @State private var stage: DMStage = .splash
    @StateObject private var conductorHolder = DMConductorHolder()

    var body: some View {
        ZStack {
            // Persistent deep void base — prevents flash between transitions
            NC.deepVoid.ignoresSafeArea()

            switch stage {
            case .splash:
                DMEmberGate(onFinish: handleSplashFinish)
                    .transition(.opacity)
                    .zIndex(0)

            case .home:
                DMForgeGate(
                    onPlay: { mode, diff, existing in
                        stage = .game(mode, diff, existing)
                    },
                    onOpenSettings: { stage = .settings },
                    onOpenGuide:    { stage = .guideScroll }
                )
                .transition(pushTransition)
                .zIndex(1)

            case .game(let mode, let diff, let existing):
                DMHearthField(
                    mode: mode,
                    difficulty: diff,
                    existing: existing,
                    holder: conductorHolder,
                    onExit: { stage = .home },
                    onWin:  { stage = .tally }
                )
                .transition(pushTransition)
                .zIndex(2)

            case .tally:
                DMTallyForge(
                    conductor: conductorHolder.conductor,
                    onReforge: { mode, diff in
                        conductorHolder.reforgeNew(
                            mode: mode, difficulty: diff,
                            vault: vault, hintsEnabled: vault.hintsOn
                        )
                        stage = .game(mode, diff, nil)
                    },
                    onHome: { stage = .home }
                )
                .transition(pushTransition)
                .zIndex(2)

            case .settings:
                DMBellowsPanel(onClose: { stage = .home })
                    .transition(sheetTransition)
                    .zIndex(3)

            case .guideScroll:
                DMPrimerScroll(onClose: { stage = .home })
                    .transition(sheetTransition)
                    .zIndex(3)

            case .rehearsal:
                #if DEBUG
                DMRehearsalStage(onExit: { stage = .home })
                    .transition(pushTransition)
                    .zIndex(4)
                #else
                Color.clear
                #endif
            }
        }
        .animation(.easeInOut(duration: 0.30), value: stage)
    }

    // MARK: Transitions

    private var pushTransition: AnyTransition {
        .asymmetric(
            insertion: .scale(scale: 0.96).combined(with: .opacity),
            removal:   .opacity
        )
    }

    private var sheetTransition: AnyTransition {
        .asymmetric(
            insertion: .move(edge: .bottom).combined(with: .opacity),
            removal:   .move(edge: .bottom).combined(with: .opacity)
        )
    }

    // MARK: Splash finish

    private func handleSplashFinish() {
        if CommandLine.arguments.contains("-DMRehearse") {
            stage = .rehearsal
        } else if CommandLine.arguments.contains("-DMUnattended") {
            let (mode, diff) = DMAutopilot.pickMode()
            stage = .game(mode, diff, nil)
        } else {
            stage = .home
        }
    }
}

// MARK: - Conductor Holder

/// Keeps the game view-model alive across the Game → Tally transition.
final class DMConductorHolder: ObservableObject {
    @Published var conductor: DMHearthConductor?

    func ensure(mode: DMMode, difficulty: DMDifficulty,
                existing: DMPuzzle?, vault: DMVault,
                hintsEnabled: Bool) -> DMHearthConductor {
        if let c = conductor, c.mode == mode, c.difficulty == difficulty {
            return c
        }
        let c = DMHearthConductor(
            mode: mode, difficulty: difficulty,
            hintsEnabled: hintsEnabled, vault: vault,
            seed: nil, existing: existing
        )
        conductor = c
        return c
    }

    func reforgeNew(mode: DMMode, difficulty: DMDifficulty,
                    vault: DMVault, hintsEnabled: Bool) {
        let c = DMHearthConductor(
            mode: mode, difficulty: difficulty,
            hintsEnabled: hintsEnabled, vault: vault,
            seed: nil, existing: nil
        )
        conductor = c
    }
}
