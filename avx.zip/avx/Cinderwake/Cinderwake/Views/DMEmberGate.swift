import SwiftUI

/// Splash screen — Night Crystal style.
/// Central crystal hex + title text + expanding ring pulses.
struct DMEmberGate: View {
    let onFinish: () -> Void
    @EnvironmentObject var vault: DMVault

    @State private var coreScale: CGFloat  = 0.4
    @State private var coreOpacity: Double = 0
    @State private var titleOffset: CGFloat = 24
    @State private var titleOpacity: Double = 0
    @State private var rings: [CGFloat]    = [0, 0, 0]
    @State private var subtitleOpacity: Double = 0

    var body: some View {
        GeometryReader { geo in
            let W = geo.size.width
            let H = geo.size.height
            let side = min(W, H)
            let hexSize = side * 0.26

            ZStack {
                DMBackdrop(tone: .entry, palette: vault.paletteName)

                // Expanding crystal rings
                ForEach(0..<rings.count, id: \.self) { i in
                    Circle()
                        .strokeBorder(
                            LinearGradient(
                                colors: [
                                    NC.tealGlow.opacity(0.7),
                                    NC.purpleGlow.opacity(0.4)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: max(1.5, side * 0.005)
                        )
                        .opacity(1 - Double(rings[i]))
                        .scaleEffect(0.15 + rings[i] * 1.9)
                        .frame(width: side * 0.6, height: side * 0.6)
                        .position(x: W / 2, y: H * 0.40)
                }

                // Central hex crystal
                ZStack {
                    // Glow halo
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [NC.tealGlow.opacity(0.5), .clear],
                                center: .center,
                                startRadius: 0,
                                endRadius: hexSize * 1.2
                            )
                        )
                        .frame(width: hexSize * 2.4, height: hexSize * 2.4)
                        .blur(radius: 20)

                    DMHexShape()
                        .fill(
                            LinearGradient(
                                colors: [
                                    Color(h: 255, s: 45, l: 22),
                                    Color(h: 270, s: 50, l: 14)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: hexSize * sqrt(3), height: hexSize * 2)
                        .overlay(
                            DMHexShape()
                                .strokeBorder(
                                    LinearGradient(
                                        colors: [NC.tealGlow.opacity(0.7), NC.purpleGlow.opacity(0.5)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ),
                                    lineWidth: 1.6
                                )
                        )
                        .shadow(color: NC.tealGlow.opacity(0.55), radius: 24, x: 0, y: 0)

                    // Inner crystal facets
                    DMHexShape()
                        .strokeBorder(Color.white.opacity(0.12), lineWidth: 0.8)
                        .frame(
                            width: hexSize * sqrt(3) * 0.6,
                            height: hexSize * 2 * 0.6
                        )
                }
                .scaleEffect(coreScale)
                .opacity(coreOpacity)
                .position(x: W / 2, y: H * 0.40)

                // Title area
                VStack(spacing: 6) {
                    Text("CINDERWAKE")
                        .font(.system(size: max(22, side * 0.068),
                                      weight: .heavy, design: .rounded))
                        .tracking(8)
                        .foregroundColor(.white)
                        .offset(y: titleOffset)
                        .opacity(titleOpacity)

                    Text("HEX HEARTH PUZZLE")
                        .font(.system(size: max(11, side * 0.028),
                                      weight: .semibold, design: .rounded))
                        .tracking(4)
                        .foregroundColor(NC.tealGlow.opacity(0.8))
                        .opacity(subtitleOpacity)
                }
                .position(x: W / 2, y: H * 0.67)
            }
            .onAppear { animate() }
        }
    }

    private func animate() {
        // Core bloom
        withAnimation(.spring(response: 0.7, dampingFraction: 0.6)) {
            coreScale   = 1.0
            coreOpacity = 1.0
        }
        // Rings
        for i in 0..<rings.count {
            withAnimation(.easeOut(duration: 1.2).delay(Double(i) * 0.22)) {
                rings[i] = 1.0
            }
        }
        // Title slides up
        withAnimation(.easeOut(duration: 0.55).delay(0.30)) {
            titleOffset  = 0
            titleOpacity = 1.0
        }
        withAnimation(.easeOut(duration: 0.45).delay(0.55)) {
            subtitleOpacity = 1.0
        }
        // Navigate
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.55) {
            onFinish()
        }
    }
}
