# Cinderwake — hướng dẫn chơi

Cinderwake là một trò xếp than trên bàn hex. Bạn có một cụm ô lục giác, mỗi
ô có một cục than sáng ở mức 0 đến 3 chấm. Nhiệm vụ là đưa bàn về đúng mẫu
đích nằm ở góc phải trên màn hình.

## Luật cơ bản trong 2 câu

1. Chạm ô có than **dưới 3 chấm** → than trong ô đó tăng thêm 1.
2. Chạm ô đang có **đủ 3 chấm** → than tràn ra: ô về 0, mỗi ô láng giềng chưa
   đầy 3 nhận thêm 1.

## Ô Chill (băng)

Trên độ khó **Coal** và **Blaze** có thêm một dấu bông tuyết xanh chạy quanh
vành ngoài của bàn. Ô nào đang bị Chill che thì **không được chạm** ở lượt
đó. Sau mỗi nước đi hợp lệ, Chill dịch 1 ô (Coal) hoặc 2 ô (Blaze) theo
chiều kim đồng hồ dọc vành.

## Cách thắng

Bàn hiển thị mẫu đích ở tấm đồng nhỏ góc phải trên. Những ô đã trùng mẫu sẽ
có viền vàng. Khi mọi ô đều trùng thì thắng.

- **Match** — mẫu đích là một hình ngẫu nhiên do máy sinh, mỗi ván khác nhau.
- **Beacon** — mẫu đích luôn là "mọi ô đúng 1 chấm" — một hearth êm và đều.

## Độ khó

| Độ khó | Số ô | Chill | Số nước tối ưu |
|---|---|---|---|
| **Ember** | 7 | không | 4–6 |
| **Coal**  | 19 | 1 ô/lượt | 8–11 |
| **Blaze** | 19 | 2 ô/lượt | 14–18 |

Ô số nước tối ưu là số bước lý tưởng máy đã dùng để "gấp ngược" ván. Đánh
đúng số đó → đạt huy chương "On the Mark".

## Các nút trên màn chơi

- **Số ô ở góc trái trên**: số nước đã dùng / số nước tối ưu và đồng hồ.
- **Tấm đồng góc phải trên**: mẫu đích thu nhỏ.
- **Nút Pause ở giữa trên**: tạm dừng, đồng hồ đứng lại.
- **Đèn vàng (hint)**: gợi ý nước tiếp theo. Số lần hint có giới hạn theo
  độ khó.
- **Mũi tên ngược (undo)**: hoàn tác nước vừa rồi. Có giới hạn 5 lần/ván.
- **REPLAY**: chơi lại chính ván này (giữ cùng đề).
- **LEAVE**: rời màn về Home. Ván đang chơi được lưu, có thể quay lại từ
  nút Resume trên Home.
- **NEW HEARTH**: bỏ ván hiện tại, sinh ván mới cùng chế độ + độ khó.
- **Thanh cam bên dưới**: % ô đã khớp mẫu.

## Home

- Chạm **thẻ Match / Beacon** để chọn chế độ.
- Chạm **viên thuốc Ember / Coal / Blaze** để chọn độ khó.
- **REKINDLE** (hoặc **RESUME** khi có ván lưu): bắt đầu chơi.
- 3 vòng tròn màu ở dưới cùng: đổi bảng màu **Ember / Ash / Copper** ngay
  lập tức.
- **Tay cầm bellows hai cạnh bên**: cạnh trái mở Hướng dẫn (Guide), cạnh
  phải mở Cài đặt (Tune).

## Cài đặt (Tune)

- **Haptics** — bật/tắt rung khi tap, thắng, undo.
- **Show hint button** — ẩn hẳn nút hint nếu bạn muốn tự chơi.
- **Palette** — 3 bảng màu, đổi ngay toàn app.
- **Default round** — chế độ và độ khó mặc định.
- **Clear hearth** — xoá stats, huy chương và ván đã lưu.
- **Rate** — mở dialog đánh giá.

## Mẹo

- Bàn tổng số than **giảm 3** mỗi lần Burst mà không có láng giềng nào chưa
  đầy 3. Kindle thì tổng tăng 1.
- Với Beacon, đừng kindle thẳng đến 3 nếu láng giềng đang cần được nhận
  thêm — burst giúp phân bổ đều hơn.
- Chill đi tuần hoàn theo vành. Đếm bước trước, tính xem ô nào sẽ bị khoá
  ở lượt tới.
- Undo tốn 1 lượt undo, hint tốn 1 hint. Ván nào không dùng hint thì thắng
  sẽ được huy chương "Flawless Sweep".
